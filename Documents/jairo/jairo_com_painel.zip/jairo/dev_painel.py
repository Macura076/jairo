"""
Abre o Jairo de verdade, ja ligado ao painel.

    python dev_painel.py                 Jairo real: motor neste terminal (logs aqui)
                                         + janela do painel (logs tambem na tela)
    python dev_painel.py --simulado      so o painel de demonstracao, SEM o Jairo
    python dev_painel.py --simulado --demo   idem, com frases ficticias animando a esfera

O modo real e o mesmo que `python jairo.py --terminal`; precisa do jairo.py na mesma pasta.
O modo simulado nao executa nada no computador: so publica eventos de texto para a tela, e
usa contatos de exemplo numa pasta temporaria (seu C:\\09projec nao e tocado). Ctrl+C encerra.
"""

from __future__ import annotations

import argparse
import math
import random
import subprocess
import sys
import tempfile
import threading
import time
import webbrowser
from pathlib import Path

AQUI = Path(__file__).resolve().parent


def principal_real(argumentos: list[str]) -> int:
    """Jairo de verdade: roda o jairo.py --terminal (que ja abre a janela do painel)."""
    jairo = AQUI / "jairo.py"
    if not jairo.is_file():
        print(
            "Nao encontrei o jairo.py ao lado do dev_painel.py.\n"
            "Use a pasta completa (jairo.py, painel/, ui/) ou rode com --simulado.",
            file=sys.stderr,
        )
        return 1
    print("Iniciando o Jairo com o painel (Ctrl+C encerra)...", flush=True)
    try:
        return subprocess.call([sys.executable, str(jairo), "--terminal", *argumentos], cwd=str(AQUI))
    except KeyboardInterrupt:
        return 0


def principal_simulado(opcoes: argparse.Namespace) -> None:
    from painel import (
        Contexto, EditorContatos, EditorPermitidos, Hub, ServidorPainel, VERSAO_PAINEL, descoberta,
    )
    from tests.ref_agenda import analisar


    pasta = Path(tempfile.mkdtemp(prefix="chasame-dev-"))
    (pasta / "contatos.txt").write_text(
        "# Contatos de exemplo\nGustavo Silva:5511999998888:gu,guto\nMaria Souza:5511988887777\n"
        "!Pedro Antigo:5511977776666\n", encoding="utf-8")
    (pasta / "permitidos.txt").write_text("# nomes como no WhatsApp\nGustavo Silva\n", encoding="utf-8")

    hub = Hub()
    hub.definir_estado(pronto=True)

    def falar(texto: str, ms: int) -> None:
        hub.publicar("fala", {"texto": texto, "duracao_estimada_ms": ms, "muda": False})
        hub.definir_estado(atividade="falando")
        time.sleep(ms / 1000)
        hub.publicar("fala_fim")
        hub.definir_estado(atividade="nenhuma")

    def simular_comando(texto: str, origem: str = "texto") -> None:
        hub.definir_estado(atividade="processando")
        time.sleep(0.7)
        hub.publicar("transcricao", {"texto": texto, "origem": origem})
        if "xyz" in texto.lower():
            hub.registrar_comando(texto, "nao_reconhecido", origem)
            hub.definir_estado(atividade="nenhuma")
            return
        hub.registrar_comando(texto, "ok", origem)
        falar(f"Abrindo {texto.split()[-1]}.", 1800)

    def executar_acao(acao: str, dados: dict) -> dict:
        if acao == "standby":
            hub.definir_estado(modo="ouvindo" if hub.estado()["modo"] == "standby" else "standby")
        elif acao == "silencioso":
            hub.definir_estado(silencioso=not hub.estado()["silencioso"])
        return {}

    contexto = Contexto(
        nome="Chasame", versao=f"dev-{VERSAO_PAINEL}", dir_ui=AQUI / "ui",
        caminho_log=pasta / "chasame.log",
        editor_contatos=EditorContatos(pasta / "contatos.txt", analisar),
        editor_permitidos=EditorPermitidos(pasta / "permitidos.txt", lambda: ["Gustavo Silva", "Maria Souza"]),
        injetar_comando=lambda t: threading.Thread(target=simular_comando, args=(t,), daemon=True).start(),
        executar_acao=executar_acao,
        abrir_arquivo=lambda chave: print(f"[dev] abrir {chave}") or True,
    )
    servidor = ServidorPainel(contexto, hub)
    servidor.iniciar()
    url = descoberta.url_painel(servidor.dados_descoberta())
    print(f"Painel de demonstracao: {url}")
    if not opcoes.sem_navegador:
        webbrowser.open(url)

    def demo() -> None:
        """Ciclo: ouvindo -> voz (nivel variando) -> processando -> falando."""
        frases = ["abrir discord", "abrir call", "pausar musica", "abrir spotify"]
        while True:
            for _ in range(60):                       # ~6 s ouvindo, com ruido de fundo baixo
                hub.nivel(0.04 + 0.03 * random.random(), False)
                time.sleep(0.1)
            hub.definir_estado(atividade="voz")
            inicio = time.monotonic()
            while time.monotonic() - inicio < 1.6:    # fala do usuario
                hub.nivel(0.35 + 0.5 * abs(math.sin((time.monotonic() - inicio) * 9)) * random.random(), True)
                time.sleep(0.05)
            hub.definir_estado(atividade="nenhuma")
            simular_comando(random.choice(frases), "voz")

    if opcoes.demo:
        threading.Thread(target=demo, daemon=True).start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        servidor.encerrar()


def principal() -> None:
    argumentos = argparse.ArgumentParser(description="Abre o Jairo com o painel (ou so o painel simulado).")
    argumentos.add_argument("--simulado", action="store_true", help="painel de demonstracao, sem o Jairo")
    argumentos.add_argument("--demo", action="store_true", help="(simulado) anima a esfera com frases ficticias")
    argumentos.add_argument("--sem-navegador", action="store_true", help="(simulado) nao abre o navegador")
    opcoes, restantes = argumentos.parse_known_args()
    if opcoes.simulado or opcoes.demo:
        principal_simulado(opcoes)
    else:
        sys.exit(principal_real(restantes))


if __name__ == "__main__":
    principal()
