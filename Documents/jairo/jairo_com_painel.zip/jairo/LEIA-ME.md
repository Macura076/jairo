# Chasame Studio - backend do painel (passo 2 da Fase 2)

Pacote `painel/` (somente biblioteca padrao, nunca importa o jairo.py):

- `erros.py`      erros de dominio (409 / 422 / escrita)
- `arquivos.py`   escrita atomica + .bak, ETag, editores de contatos.txt e permitidos.txt
- `hub.py`        eventos, assinantes SSE, estado e historico (custo zero sem cliente)
- `logs.py`       cauda do log por seek e handler de log para a UI
- `apps.py`       Get-StartApps com cache
- `descoberta.py` painel.json em %LOCALAPPDATA%\Chasame
- `servidor.py`   HTTP local, token, Host/Origin, API JSON, SSE, estaticos

Testes (sem Windows, sem microfone, sem rede):

    python -m unittest discover -s tests -t . -v      # ou: pytest

`tests/ref_agenda.py` replica as regras de Agenda._carregar do jairo.py v2.0 e serve de
contrato para o parser que sera extraido da Agenda no proximo passo.

Ver a interface agora (sem o Chasame, sem Windows especifico, sem microfone):

    python dev_painel.py          # servidor + navegador; nada acontece sozinho
    python dev_painel.py --demo   # simula frases ficticias para ver a esfera animada

Pronto na UI: tema, estrutura, pagina Inicio (esfera, estados, historico, comando de texto,
"Log ao vivo") e pagina Logs (filtro de nivel, busca, pausar, seguir o fim, abrir arquivo).
Pagina Contatos pronta (tabela editavel, apelidos em chips, salvar com ETag/backup, teste de
nome falado, atualiza sozinha quando um apelido nasce por voz).
Pendente (uma de cada vez): Permitidos e Comandos; ComandosPersonalizados.

## Passo 3: ligado ao jairo.py (feito)

Estrutura (tudo na mesma pasta):

    jairo.py   painel/   ui/   tests/   dev_painel.py   requirements.txt

Como usar:

    python jairo.py               abre a janela do painel (inicia o motor se preciso);
                                  o terminal e liberado na hora; logs na tela
    python jairo.py --terminal    motor neste terminal (logs aqui) E janela com os logs na tela
    python dev_painel.py          o mesmo que --terminal (Jairo real); --simulado = so a demo
    iniciar_jairo.bat             duplo clique: Jairo + janela, sem terminal
    iniciar_jairo_terminal.bat    duplo clique: Jairo + janela, terminal aberto com logs
    python jairo.py --sem-painel  sem interface (comportamento anterior)
    python jairo.py --texto --com-painel   modo texto simulado + painel (desenvolvimento)

Papeis do jairo.py: o *motor* (`--motor`, sem console) roda microfone, voz, WhatsApp e o
servidor do painel; a *janela* (`--janela`) e um processo separado e leve que le o
painel.json, abre pywebview (se instalado) ou o navegador, e termina quando voce a fecha.
O motor continua rodando (bandeja: Abrir painel / Sair). Iniciado com o Windows
(`--autostart`) ele sobe sem janela; `JAIRO_JANELA_NO_INICIO=true` abre a janela tambem.

Variaveis do .env: `JAIRO_PAINEL=false` desliga o painel (volta ao terminal),
`JAIRO_JANELA_NO_INICIO=true|false`.

Ganchos ligados: estado (ouvindo/standby/ditado, silencioso, atividade), transcricao,
historico de comandos, fala (inclui duracao estimada), nivel do microfone (proxy do stream
so quando ha janela conectada), log ao vivo, comando digitado, botoes (standby, silencioso,
recarregar agenda, testar voz), abrir contatos/permitidos/log/pasta e `explicar_nome`.
Salvar contatos/permitidos pelo painel recarrega a agenda sem reiniciar.

## Apelidos por voz

    "Jairo, chame Joao Silva de Joaozinho"      (tambem: "como", "pelo apelido")

Grava `Joaozinho` na linha de Joao Silva em `contatos.txt` (guarda a versao anterior em
`contatos.txt.bak`, preserva comentarios/CRLF/BOM) e passa a valer na hora. Recusa apelido
repetido, igual ao nome ou com virgula/dois-pontos; nome ambiguo pede o nome completo.

## Logs na tela

- A janela abre na hora. Se o motor ainda esta subindo, ela mostra a tela "Iniciando o
  Jairo..." com o jairo.log ao vivo (inclusive erros de inicializacao) e troca para a
  interface quando o painel responde. Precisa de `pip install pywebview`; sem ele a janela
  abre no navegador assim que o motor estiver no ar.
- Inicio: painel "Log ao vivo" com os ultimos registros. Aba Logs: historico completo
  (cauda do arquivo + tempo real), nivel minimo, busca, pausar, limpar tela e "Ir para o fim".
- Erros antes do log existir (biblioteca faltando) e erros nao tratados aparecem numa caixa
  de dialogo e no jairo.log, mesmo sem console.

## Standby

Em espera a esfera fica parada (circulo fixo, sem brilho pulsando), o laco de animacao para
(CPU ~0) e o microfone nao a acorda nem mexe no medidor. So volta a animar ao sair do standby;
se o Jairo falar em espera, ela mostra "Falando" e depois para de novo.

Testes da interface sem navegador: `npm install jsdom` e depois
`node tests/ui/teste_ui.mjs` e `node tests/ui/teste_contatos.mjs`.
