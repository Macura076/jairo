@echo off
rem Abre o Jairo com a interface (sem janela de terminal). Os registros aparecem na tela.
cd /d "%~dp0"
start "" pythonw "%~dp0jairo.py"
