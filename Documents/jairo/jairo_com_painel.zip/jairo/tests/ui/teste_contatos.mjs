// Teste da pagina Contatos sem navegador: npm install jsdom && node tests/ui/teste_contatos.mjs
import { iniciarUI } from "./ambiente.mjs";

// --- servidor falso, com as mesmas regras do painel (ETag, 409, 422) ---
let versao = 1;
let contatos = [
  { id: 0, nome: "João Silva", numero: "5511999990001", apelidos: [], ativo: true },
  { id: 1, nome: "Maria de Souza", numero: "5511999990002", apelidos: ["Mari"], ativo: true },
  { id: 2, nome: "Pedro Antigo", numero: "5511999990004", apelidos: [], ativo: false },
  { id: 3, invalida: true, bruto: "lixo sem dois pontos", nome: "", numero: "", apelidos: [], ativo: true },
];
const etag = () => `"e${versao}"`;
const lerTudo = () => ({
  etag: etag(),
  contatos: JSON.parse(JSON.stringify(contatos)),
  erros: contatos.some((c) => c.invalida) ? [{ linha: 4, mensagem: "linha inválida: 'lixo sem dois pontos'" }] : [],
});
let forcar422 = null;
const rotas = {
  "GET /api/contatos": () => [200, lerTudo()],
  "PUT /api/contatos": ({ corpo, cabecalhos }) => {
    if (cabecalhos["If-Match"] !== etag()) return [409, { erro: "O arquivo foi alterado fora do painel." }];
    if (forcar422) return [422, { erro: "x", erros: forcar422, conflitos: [] }];
    const novos = corpo.contatos.map((c, i) => (c.invalida
      ? { id: i, invalida: true, bruto: "lixo sem dois pontos", nome: "", numero: "", apelidos: [], ativo: true }
      : { id: i, nome: c.nome, numero: c.numero, apelidos: c.apelidos, ativo: c.ativo }));
    contatos = novos; versao++;
    return [200, { ...lerTudo(), alterado: true }];
  },
  "POST /api/contatos/explicar": ({ corpo }) => {
    const n = corpo.nome.toLowerCase();
    if (n === "mari") return [200, { nome: n, resultado: "unico", candidatos: [{ nome: "Maria de Souza", final: "0002", via: "apelido" }] }];
    if (n === "maria") return [200, { nome: n, resultado: "ambiguo", candidatos: [{ nome: "Maria de Souza", final: "0002", via: "nome" }, { nome: "Maria Santos", final: "0003", via: "nome" }] }];
    return [200, { nome: n, resultado: "nenhum", candidatos: [] }];
  },
};

const t = await iniciarUI({ rotas });
const { $, esperar, emitir, chamadas, ok, digitar, clicar, window, document } = t;
const aba = document.querySelector('.nav[data-pagina="contatos"]');
const linhas = () => [...$("contatos-corpo").querySelectorAll("tr[data-busca]")];
const putAnterior = () => chamadas.filter((c) => c.metodo === "PUT" && c.url === "/api/contatos").at(-1);

await esperar(200);
clicar(aba);
await esperar(100);
ok(!$("pagina-contatos").hidden, "aba Contatos abre");
ok(linhas().length === 4, `4 linhas na tabela (tem ${linhas().length})`);
ok($("contatos-resumo").textContent.includes("2 ativo(s), 1 inativo(s)") && $("contatos-resumo").textContent.includes("1 linha(s) inválida(s)"), "resumo conta ativos, inativos e linhas inválidas");
ok(!$("contatos-erros-arquivo").hidden && $("contatos-erros-arquivo").textContent.includes("Linha 4"), "erros do arquivo aparecem no topo");
ok(linhas()[3].textContent.includes("lixo sem dois pontos"), "linha inválida mostrada com o texto original");
ok(linhas()[2].classList.contains("inativo"), "contato inativo fica esmaecido");
ok($("contatos-salvar").disabled, "Salvar desabilitado sem alterações");
ok(linhas()[1].querySelectorAll(".chip").length === 1 && linhas()[1].querySelector(".chip").textContent.startsWith("Mari"), "apelido aparece como chip");

// ---- edicao: apelido por Enter, remover apelido, ativar, novo contato ----
const inApelido = linhas()[0].querySelector(".campo-apelido");
inApelido.value = "Joãozinho";
inApelido.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true }));
ok(linhas()[0].querySelectorAll(".chip").length === 1, "Enter adiciona o apelido como chip");
ok(!$("contatos-salvar").disabled && aba.dataset.sujo === "true", "alteração habilita Salvar e marca a aba com •");

linhas()[1].querySelector(".chip-x").click();
ok(linhas()[1].querySelectorAll(".chip").length === 0, "× remove o apelido");

const chk = linhas()[2].querySelector('input[type="checkbox"]');
chk.checked = true; chk.dispatchEvent(new window.Event("change"));
ok(!linhas()[2].classList.contains("inativo"), "marcar Ativo tira o esmaecimento");

clicar($("contatos-adicionar"));
ok(linhas().length === 5, "Adicionar contato cria uma linha");
const nova = linhas()[4];
digitar(nova.querySelector(".campo-nome"), "Ana <img src=x onerror=alert(1)>");
const num = nova.querySelector(".campo-numero");
digitar(num, "+55 (11) 99999-0005");
num.dispatchEvent(new window.Event("blur"));
ok(num.value === "5511999990005", `número é limpo ao sair do campo (${num.value})`);
ok(!document.querySelector("#contatos-corpo img"), "HTML no nome é texto, não elemento");

// ---- validação local: nome vazio e número ruim não vão ao servidor ----
clicar($("contatos-adicionar"));
const vazia = linhas()[5];
digitar(vazia.querySelector(".campo-numero"), "123");
const putsAntes = chamadas.filter((c) => c.metodo === "PUT").length;
clicar($("contatos-salvar")); await esperar(50);
ok(chamadas.filter((c) => c.metodo === "PUT").length === putsAntes, "validação local impede o envio");
ok($("contatos-corpo").textContent.includes("Informe o nome.") && $("contatos-corpo").textContent.includes("DDI+DDD"), "mensagens de erro nas linhas");
ok($("contatos-aviso").dataset.tipo === "erro", "aviso de erro no topo");
linhas()[5].querySelector('button[aria-label^="Remover o contato"]').click();     // tira a linha vazia
ok(linhas().length === 5, "remover tira a linha");

// ---- salvar ----
clicar($("contatos-salvar")); await esperar(80);
const put = putAnterior();
ok(put && put.cabecalhos["If-Match"] === '"e1"', "PUT com If-Match = etag lido");
ok(put.corpo.contatos.length === 5, "envia 5 linhas");
ok(put.corpo.contatos[0].id === 0 && put.corpo.contatos[0].apelidos[0] === "Joãozinho", "linha existente mantém id e apelidos");
ok(JSON.stringify(put.corpo.contatos[3]) === JSON.stringify({ id: 3, invalida: true }), "linha inválida é enviada só como { id, invalida }");
ok(put.corpo.contatos[4].id === undefined && put.corpo.contatos[4].numero === "5511999990005", "contato novo vai sem id e com número limpo");
ok(put.corpo.contatos[2].ativo === true, "ativo alterado foi enviado");
ok($("contatos-aviso").dataset.tipo === "ok" && $("contatos-aviso").textContent.includes("Salvo"), "aviso de sucesso");
ok($("contatos-salvar").disabled && aba.dataset.sujo === "false", "depois de salvar não há alterações pendentes");
ok(linhas().length === 5 && linhas()[0].querySelector(".chip")?.textContent.startsWith("Joãozinho"), "tabela refletiu o que o servidor devolveu");

// ---- 422 do servidor (regra que a tela não conhece) ----
digitar(linhas()[1].querySelector(".campo-nome"), "Maria de Souza 2");
forcar422 = [{ indice: 1, linha: 2, campo: "nome", mensagem: "Apelido duplicado 'Mari'." }];
clicar($("contatos-salvar")); await esperar(80);
ok($("contatos-corpo").textContent.includes("Apelido duplicado"), "erro 422 aparece na linha indicada");
ok($("contatos-salvar").disabled === false, "continua editável após o erro");
forcar422 = null;

// ---- 409: arquivo mudou por fora ----
versao++;   // alguém editou o arquivo (por voz, Bloco de Notas...)
clicar($("contatos-salvar")); await esperar(80);
ok($("contatos-aviso").textContent.includes("mudou fora desta tela"), "409 explica o conflito");
const botaoRecarregar = $("contatos-aviso").querySelector("button");
ok(!!botaoRecarregar, "409 oferece Recarregar");
botaoRecarregar.click(); await esperar(80);
ok($("contatos-salvar").disabled && !linhas()[1].querySelector(".campo-nome").value.endsWith(" 2"), "Recarregar descarta a edição e traz a versão atual");

// ---- evento "agenda" (apelido criado por voz) ----
contatos[0].apelidos.push("Jão"); versao++;
emitir("agenda", { motivo: "apelido" }); await esperar(120);
ok(linhas()[0].textContent.includes("Jão"), "apelido por voz aparece sem recarregar a página");
ok($("contatos-aviso").textContent.includes("adicionado por voz"), "avisa que veio por voz");

// com alterações pendentes, NÃO sobrescreve
digitar(linhas()[1].querySelector(".campo-nome"), "Maria editada");
contatos[0].apelidos.push("Jonas"); versao++;
emitir("agenda", { motivo: "apelido" }); await esperar(120);
ok(linhas()[1].querySelector(".campo-nome").value === "Maria editada", "alterações pendentes não são sobrescritas");
ok($("contatos-aviso").textContent.includes("Salve ou descarte"), "pede para salvar ou descartar antes");
clicar($("contatos-descartar")); await esperar(80);
ok(linhas()[0].textContent.includes("Jonas") && $("contatos-salvar").disabled, "Descartar volta ao arquivo");

// ---- testar nome falado ----
digitar($("contatos-teste-nome"), "mari");
$("contatos-teste").dispatchEvent(new window.Event("submit", { cancelable: true })); await esperar(60);
ok($("contatos-teste-res").textContent.includes("Maria de Souza") && $("contatos-teste-res").textContent.includes("apelido"), "teste: nome único");
ok(!chamadas.filter((c) => c.url === "/api/contatos/explicar").at(-1).corpo.contatos, "sem alterações, o teste não envia a tabela");
digitar($("contatos-teste-nome"), "maria");
$("contatos-teste").dispatchEvent(new window.Event("submit", { cancelable: true })); await esperar(60);
ok($("contatos-teste-res").textContent.includes("Ambíguo") && $("contatos-teste-res").textContent.includes("Maria Santos"), "teste: nome ambíguo");
digitar(linhas()[0].querySelector(".campo-nome"), "João Editado");
digitar($("contatos-teste-nome"), "ninguem");
$("contatos-teste").dispatchEvent(new window.Event("submit", { cancelable: true })); await esperar(60);
ok(Array.isArray(chamadas.filter((c) => c.url === "/api/contatos/explicar").at(-1).corpo.contatos), "com alterações pendentes, testa com a tabela editada");
ok($("contatos-teste-res").textContent.includes("Nenhum contato"), "teste: nenhum contato");
clicar($("contatos-descartar")); await esperar(80);

// ---- busca ----
digitar($("contatos-busca"), "joaozinho");
ok(linhas().filter((l) => !l.hidden).length === 1, "busca ignora acentos e filtra por apelido");
digitar($("contatos-busca"), "0004");
ok(linhas().filter((l) => !l.hidden).length === 1 && !linhas()[2].hidden, "busca por número");
digitar($("contatos-busca"), "");
ok(linhas().every((l) => !l.hidden), "limpar a busca mostra tudo");

// ---- remover linha inválida ----
linhas()[3].querySelector("button").click();
ok(linhas().length === 4 && !linhas().some((l) => l.textContent.includes("lixo")) && !$("contatos-salvar").disabled, "remover a linha inválida marca alteração");

t.fim();
