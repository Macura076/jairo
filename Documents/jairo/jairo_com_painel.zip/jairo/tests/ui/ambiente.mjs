// Ambiente de teste da interface: DOM simulado (jsdom), servidor falso (fetch + SSE) e o app.js real.
// Uso: const t = await iniciarUI({ rotas: { "GET /api/contatos": () => [200, {...}] } });
import { JSDOM } from "jsdom";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const UI = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../ui");

// real: { base: "http://127.0.0.1:PORTA", token } liga a UI a um painel de verdade (em vez do servidor falso).
export async function iniciarUI({ rotas = {}, cauda = [], real = null } = {}) {
  const dom = new JSDOM(fs.readFileSync(path.join(UI, "index.html"), "utf8").replace(/<script[^>]*><\/script>/, ""), {
    url: `${real ? real.base : "http://127.0.0.1:5555"}/#t=${real ? real.token : "tok123"}`, pretendToBeVisual: true,
  });
  const { window } = dom;
  for (const k of ["document", "location", "history", "sessionStorage", "navigator", "HTMLElement", "Node"]) {
    Object.defineProperty(globalThis, k, { value: window[k], configurable: true, writable: true });
  }
  globalThis.window = window;
  globalThis.matchMedia = () => ({ matches: false, addEventListener() {}, addListener() {} });
  window.matchMedia = globalThis.matchMedia;
  globalThis.devicePixelRatio = 1;
  globalThis.ResizeObserver = class { observe() {} disconnect() {} unobserve() {} };
  const quadros = { n: 0 };
  globalThis.requestAnimationFrame = (f) => setTimeout(() => { quadros.n++; f(performance.now()); }, 16);
  globalThis.cancelAnimationFrame = clearTimeout;
  window.requestAnimationFrame = globalThis.requestAnimationFrame;
  const ctx2d = new Proxy(function () {}, { get: () => ctx2d, apply: () => ctx2d, set: () => true });
  window.HTMLCanvasElement.prototype.getContext = () => ctx2d;
  globalThis.confirm = () => true;
  window.confirm = globalThis.confirm;

  const chamadas = [];
  let emitir = () => {};
  const fetchReal = globalThis.fetch;
  globalThis.fetch = async (url, opts = {}) => {
    if (real) {
      const corpo = opts.body ? JSON.parse(opts.body) : undefined;
      chamadas.push({ metodo: opts.method || "GET", url, corpo, cabecalhos: opts.headers || {} });
      return fetchReal(real.base + url, opts);
    }
    const metodo = opts.method || "GET";
    const caminho = url.split("?")[0];
    const corpo = opts.body ? JSON.parse(opts.body) : undefined;
    chamadas.push({ metodo, url, corpo, cabecalhos: opts.headers || {} });
    const json = (o, status = 200) => ({ ok: status < 400, status, json: async () => o });
    const rota = rotas[`${metodo} ${caminho}`];
    if (rota) { const [status, obj] = rota({ url, corpo, cabecalhos: opts.headers || {} }); return json(obj, status); }
    if (caminho === "/api/estado") return json({ nome: "Jairo", versao: "2.0", historico: [] });
    if (caminho === "/api/log") return json({ linhas: cauda });
    if (caminho === "/api/acao") return json({ ok: true });
    if (caminho === "/events") {
      const enc = new TextEncoder();
      const stream = new ReadableStream({ start(c) { emitir = (tipo, d) => c.enqueue(enc.encode(`event: ${tipo}\ndata: ${JSON.stringify(d)}\n\n`)); } });
      return { ok: true, status: 200, body: stream };
    }
    return json({}, 404);
  };
  globalThis.TextDecoder = TextDecoder;

  await import(pathToFileURL(path.join(UI, "js/app.js")).href);
  const $ = (id) => document.getElementById(id);
  const esperar = (ms) => new Promise((r) => setTimeout(r, ms));
  let falhas = 0;
  const ok = (cond, msg) => { console.log((cond ? "  ok   " : "  FALHA ") + msg); if (!cond) falhas++; };
  const digitar = (el, valor) => { el.value = valor; el.dispatchEvent(new window.Event("input", { bubbles: true })); };
  const clicar = (el) => el.click();
  const fim = () => { console.log(falhas ? `\n${falhas} FALHA(S)` : "\nUI OK"); process.exit(falhas ? 1 : 0); };
  return { $, esperar, emitir: (t, d) => emitir(t, d), chamadas, quadros, ok, digitar, clicar, fim, window, document };
}
