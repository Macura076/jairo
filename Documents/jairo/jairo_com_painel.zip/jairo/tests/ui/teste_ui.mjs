// Testes da interface (Inicio, Logs, standby) sem navegador: npm install jsdom && node tests/ui/teste_ui.mjs
import { iniciarUI } from "./ambiente.mjs";

const cauda = [
  { ts: "10:00:00", nivel: "INFO", thread: "MainThread", msg: "Agenda carregada: 2 contato(s)" },
  { ts: "10:00:01", nivel: "DEBUG", thread: "MainThread", msg: "detalhe de debug" },
  { ts: "10:00:02", nivel: "ERROR", thread: "MainThread", msg: "Erro na calibracao: x\nTraceback (most recent call last):\n  File y" },
];
const t = await iniciarUI({ cauda });
const { $, esperar, emitir, chamadas, ok, window } = t;
const quadros = t.quadros;

await esperar(200);
ok($("pilula-texto").textContent === "Ouvindo", "conectou ao SSE e mostrou 'Ouvindo'");
ok(chamadas.some((c) => c.url.startsWith("/api/log")), "buscou a cauda do log");
ok($("rotulo-nome").textContent === "Jairo:", "nome vindo do servidor: Jairo");

// cauda no painel do Inicio (so INFO+) e na pagina de logs
ok($("mini-log").children.length === 2, `mini-log mostra 2 registros INFO+ (tem ${$("mini-log").children.length})`);
ok($("log-lista").children.length === 2, "pagina de logs (filtro Info+) esconde o debug");

// log ao vivo
emitir("log", { ts: "10:00:05", nivel: "INFO", thread: "MainThread", msg: "[VOZ] Jairo pronto. Pode chamar." });
emitir("log", { ts: "10:00:06", nivel: "WARNING", thread: "AudioCaptura", msg: "aviso ao vivo" });
emitir("log", { ts: "10:00:07", nivel: "DEBUG", thread: "X", msg: "debug ao vivo" });
await esperar(100);
ok($("mini-log").children.length === 4, `mini-log recebeu os 2 novos INFO+ (tem ${$("mini-log").children.length})`);
ok($("mini-log").lastChild.textContent.includes("aviso ao vivo"), "ultima linha do mini-log e o aviso");
ok($("mini-log").lastChild.className.includes("nivel-warning"), "aviso com classe de nivel");
ok($("log-lista").children.length === 4, "pagina de logs recebeu os novos (debug filtrado)");

// repeticao: o que ja veio na cauda nao duplica
emitir("log", cauda[0]);
await esperar(60);
ok($("log-lista").children.length === 4, "registro repetido da cauda nao duplica");

// filtros
$("log-nivel").value = "10"; $("log-nivel").dispatchEvent(new window.Event("change"));
ok($("log-lista").children.length === 6, `filtro 'Tudo' mostra 6 (tem ${$("log-lista").children.length})`);
$("log-nivel").value = "40"; $("log-nivel").dispatchEvent(new window.Event("change"));
ok($("log-lista").children.length === 1, "filtro 'So erros' mostra 1");
ok($("log-lista").textContent.includes("Traceback"), "traceback multilinha preservado");
$("log-nivel").value = "20"; $("log-nivel").dispatchEvent(new window.Event("change"));
$("log-busca").value = "aviso"; $("log-busca").dispatchEvent(new window.Event("input"));
ok($("log-lista").children.length === 1, "busca por texto filtra");
$("log-busca").value = ""; $("log-busca").dispatchEvent(new window.Event("input"));

// pausa
$("log-pausar").click();
emitir("log", { ts: "10:00:08", nivel: "INFO", thread: "T", msg: "durante a pausa" });
await esperar(60);
ok(!$("log-lista").textContent.includes("durante a pausa"), "pausado: nao aparece na pagina");
ok($("log-contagem").textContent.includes("pausado"), "contagem indica pausa");
$("log-pausar").click();
ok($("log-lista").textContent.includes("durante a pausa"), "ao continuar, aparece o que chegou na pausa");

// seguranca: HTML no log nao vira elemento
emitir("log", { ts: "10:00:09", nivel: "INFO", thread: "T", msg: "<img src=x onerror=alert(1)>" });
await esperar(60);
ok(!document.querySelector("#log-lista img") && !document.querySelector("#mini-log img"), "HTML em mensagem de log e tratado como texto");

// navegacao
document.querySelector('.nav[data-pagina="logs"]').click();
ok(!$("pagina-logs").hidden && $("pagina-inicio").hidden, "aba Logs abre e esconde o Inicio");
document.querySelector('.nav[data-pagina="inicio"]').click();
$("btn-ver-logs").click();
ok(!$("pagina-logs").hidden, "'ver tudo' do Inicio abre a pagina de logs");

// abrir arquivo e limpar
$("log-abrir").click(); await esperar(30);
ok(chamadas.some((c) => c.url === "/api/acao" && c.corpo?.acao === "abrir_arquivo" && c.corpo?.arquivo === "log"), "botao 'Abrir arquivo' chama a API");
$("log-limpar").click();
ok($("log-lista").children.length === 0 && $("mini-log").querySelector(".vazio"), "'Limpar tela' esvazia as duas listas");

// resto da tela segue funcionando
emitir("transcricao", { texto: "abrir discord", origem: "voz" });
emitir("comando", { texto: "abrir discord", resultado: "ok", origem: "voz" });
emitir("estado", { modo: "standby", silencioso: false, atividade: "nenhuma" });
await esperar(60);
ok($("voce").textContent === "abrir discord", "transcricao aparece");
ok($("historico").textContent.includes("abrir discord"), "historico de comandos aparece");
ok($("pilula-texto").textContent === "Em espera", "estado standby aparece");

// ---- standby: a esfera NAO se mexe ----
emitir("estado", { modo: "ouvindo", silencioso: false, atividade: "nenhuma" });
await esperar(120);
let antes = quadros.n; await esperar(300);
ok(quadros.n - antes > 5, `ouvindo: esfera animando (${quadros.n - antes} quadros em 300 ms)`);

emitir("estado", { modo: "standby", silencioso: false, atividade: "nenhuma" });
await esperar(2600);                                 // tempo de assentar
antes = quadros.n; await esperar(500);
ok(quadros.n - antes === 0, `standby: laco de animacao parado (${quadros.n - antes} quadros em 500 ms)`);
ok($("pilula-texto").textContent === "Em espera", "standby: pilula 'Em espera'");

emitir("nivel", { v: 0.9, voz: true });
emitir("estado", { modo: "standby", silencioso: false, atividade: "voz" });
await esperar(300);
ok($("medidor-nivel").style.width === "0px" || $("medidor-nivel").style.width === "0", "standby: medidor zerado mesmo com nivel do microfone");
ok($("pilula-texto").textContent === "Em espera", "standby: atividade 'voz' do microfone nao acorda a esfera");
antes = quadros.n; await esperar(400);
ok(quadros.n - antes === 0, `standby + microfone ativo: continua parada (${quadros.n - antes} quadros)`);

emitir("estado", { modo: "standby", silencioso: false, atividade: "falando" });
await esperar(200);
ok($("pilula-texto").textContent === "Falando", "standby: ainda mostra 'Falando' quando o Jairo fala");
emitir("estado", { modo: "standby", silencioso: false, atividade: "nenhuma" });
await esperar(2600);
antes = quadros.n; await esperar(400);
ok(quadros.n - antes === 0, "standby: volta a parar depois de falar");

emitir("estado", { modo: "ouvindo", silencioso: false, atividade: "nenhuma" });
await esperar(200);
antes = quadros.n; await esperar(300);
ok(quadros.n - antes > 5, `sair do standby: esfera volta a animar (${quadros.n - antes} quadros)`);

t.fim();
