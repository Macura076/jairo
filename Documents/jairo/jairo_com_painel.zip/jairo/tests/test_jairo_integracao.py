"""
Testes do jairo.py ligado ao painel: apelidos por voz, parser da agenda e
PainelJairo. Pulados se as dependencias do jairo.py (pyttsx3, selenium,
speech_recognition, python-dotenv) nao estiverem instaladas.
"""
import http.client
import json
import os
import queue
import tempfile
import threading
import time
import unittest
from pathlib import Path

# O jairo.py le a configuracao ao ser importado: isole tudo numa pasta temporaria.
_TMP = tempfile.mkdtemp(prefix="jairo_teste_")
os.environ["JAIRO_DIR"] = _TMP
os.environ["LOCALAPPDATA"] = _TMP
os.environ["JAIRO_PAINEL"] = "true"

try:
    import jairo
    _ERRO_IMPORT = None
except ImportError as exc:  # pragma: no cover
    jairo = None
    _ERRO_IMPORT = str(exc)

from tests.ref_agenda import analisar


@unittest.skipIf(jairo is None, f"dependencias do jairo.py ausentes: {_ERRO_IMPORT}")
class Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.pasta = Path(self._tmp.name)
        self.arquivo = self.pasta / "contatos.txt"
        self.arquivo.write_text(
            "# meus contatos\n"
            "João Silva:5511999990001\n"
            "\n"
            "Maria de Souza:5511999990002:Mari\n"
            "Maria Santos:5511999990003\n"
            "!Pedro Antigo:5511999990004\n",
            encoding="utf-8",
        )
        self.agenda = jairo.Agenda(self.arquivo)


class VozFalsa:
    def __init__(self):
        self.falas = []
        self.silencioso = False
        self.ultima_fala = ""

    def falar(self, texto):
        self.falas.append(texto)

    confirmar = falar

    def ocupada(self):
        return False

    fim_fala = 0.0


class TestAgenda(Base):
    def test_parser_concorda_com_o_de_referencia(self):
        textos = [
            "",
            "# so comentario\n",
            "A B:5511999990001\nA B:5511999990002\n",                   # duplicado
            "A:123\n",                                                   # numero invalido
            "A:5511999990001:x,y\nB:5511999990002:y\n",                  # apelido duplicado
            "A:5511999990001:x,x\n",                                     # repetido no mesmo contato
            "linha sem dois pontos\n",
            ":5511999990001\n",
            "!Antigo:5511999990001\nAntigo:5511999990002\n",
            "A:5511999990001:\n",
            "  Com Espaco  :  5511999990001  :  Apelido , Outro \n",
        ]
        for texto in textos:
            with self.subTest(texto=texto):
                self.assertEqual(jairo.Agenda.analisar_texto(texto), analisar(texto))

    def test_recarregar_mantem_agenda_anterior_se_arquivo_quebrar(self):
        self.arquivo.write_text("lixo\n", encoding="utf-8")
        with self.assertRaises(ValueError):
            self.agenda.recarregar()
        self.assertEqual(self.agenda.buscar("joao silva").numero, "5511999990001")

    def test_recarregar_pega_edicao_externa(self):
        self.arquivo.write_text(
            self.arquivo.read_text(encoding="utf-8") + "Carlos Lima:5511999990005\n",
            encoding="utf-8",
        )
        self.agenda.recarregar()
        self.assertEqual(self.agenda.buscar("carlos").nome, "Carlos Lima")

    def test_le_arquivo_com_bom(self):
        self.arquivo.write_bytes(b"\xef\xbb\xbf" + "João Silva:5511999990001\n".encode("utf-8"))
        agenda = jairo.Agenda(self.arquivo)
        self.assertEqual(agenda.buscar("joão silva").numero, "5511999990001")

    def test_de_texto_nao_toca_no_arquivo(self):
        antes = self.arquivo.read_bytes()
        agenda = jairo.Agenda.de_texto("Ana Lima:5511999990009:Aninha\n")
        self.assertEqual(agenda.buscar("aninha").nome, "Ana Lima")
        self.assertEqual(self.arquivo.read_bytes(), antes)
        with self.assertRaises(ValueError):
            jairo.Agenda.de_texto("lixo\n")


class TestAdicionarApelido(Base):
    def test_adiciona_a_linha_sem_apelidos_e_cria_backup(self):
        antes = self.arquivo.read_bytes()
        contato = self.agenda.buscar("joão silva")
        self.assertEqual(self.agenda.adicionar_apelido(contato, "Joãozinho"), "Joãozinho")

        linhas = self.arquivo.read_text(encoding="utf-8").splitlines()
        self.assertEqual(linhas[1], "João Silva:5511999990001:Joãozinho")
        self.assertEqual(linhas[0], "# meus contatos")          # comentario preservado
        self.assertEqual(linhas[2], "")                          # linha em branco preservada
        self.assertEqual((self.pasta / "contatos.txt.bak").read_bytes(), antes)
        self.assertEqual(self.agenda.buscar("joaozinho").nome, "João Silva")

    def test_acrescenta_a_lista_existente(self):
        contato = self.agenda.buscar("maria de souza")
        self.agenda.adicionar_apelido(contato, "Mariazinha")
        linha = self.arquivo.read_text(encoding="utf-8").splitlines()[3]
        self.assertEqual(linha, "Maria de Souza:5511999990002:Mari,Mariazinha")
        self.assertEqual(self.agenda.buscar("mariazinha").nome, "Maria de Souza")
        self.assertEqual(self.agenda.buscar("mari").nome, "Maria de Souza")

    def test_preserva_crlf_e_bom(self):
        self.arquivo.write_bytes(
            b"\xef\xbb\xbf" + "João Silva:5511999990001\r\nAna Lima:5511999990009\r\n".encode("utf-8")
        )
        agenda = jairo.Agenda(self.arquivo)
        agenda.adicionar_apelido(agenda.buscar("ana lima"), "Aninha")
        bruto = self.arquivo.read_bytes()
        self.assertTrue(bruto.startswith(b"\xef\xbb\xbf"))
        self.assertEqual(
            bruto[3:].decode("utf-8"),
            "João Silva:5511999990001\r\nAna Lima:5511999990009:Aninha\r\n",
        )

    def test_recusa_apelido_de_outro_contato(self):
        with self.assertRaises(ValueError) as erro:
            self.agenda.adicionar_apelido(self.agenda.buscar("joão silva"), "mari")
        self.assertIn("Maria de Souza", str(erro.exception))

    def test_recusa_apelido_repetido_no_mesmo_contato(self):
        with self.assertRaises(ValueError):
            self.agenda.adicionar_apelido(self.agenda.buscar("maria de souza"), "MARI")

    def test_recusa_apelido_igual_ao_nome(self):
        with self.assertRaises(ValueError):
            self.agenda.adicionar_apelido(self.agenda.buscar("joão silva"), "joao silva")

    def test_recusa_caracteres_proibidos_sem_alterar_o_arquivo(self):
        antes = self.arquivo.read_bytes()
        for ruim in ("a,b", "a:b", "", "x" * 61):
            with self.subTest(apelido=ruim), self.assertRaises(ValueError):
                self.agenda.adicionar_apelido(self.agenda.buscar("joão silva"), ruim)
        self.assertEqual(self.arquivo.read_bytes(), antes)
        self.assertFalse((self.pasta / "contatos.txt.bak").exists())

    def test_contato_inativo_nao_e_alterado(self):
        contato = jairo.Contato("Pedro Antigo", "5511999990004")
        with self.assertRaises(ValueError):
            self.agenda.adicionar_apelido(contato, "Pedrinho")
        self.assertIn("!Pedro Antigo:5511999990004\n", self.arquivo.read_text(encoding="utf-8"))

    def test_nao_deixa_arquivo_temporario(self):
        self.agenda.adicionar_apelido(self.agenda.buscar("joão silva"), "Joãozinho")
        self.assertEqual(
            sorted(p.name for p in self.pasta.iterdir()),
            ["contatos.txt", "contatos.txt.bak"],
        )


class TestCandidatosApelido(unittest.TestCase):
    @unittest.skipIf(jairo is None, "jairo.py indisponivel")
    def test_divisoes(self):
        f = jairo._candidatos_apelido
        self.assertEqual(f("chame João Silva de Joãozinho"), [("João Silva", "Joãozinho")])
        self.assertEqual(
            f("chame Maria de Souza de Mari"),
            [("Maria de Souza", "Mari"), ("Maria", "Souza de Mari")],
        )
        self.assertEqual(f("chama o Gustavo como Guto"), [("Gustavo", "Guto")])
        self.assertEqual(f("chame Ana Lima pelo apelido Aninha"), [("Ana Lima", "Aninha")])
        self.assertEqual(f("chame Ana"), [])
        self.assertIsNone(f("abrir spotify"))
        self.assertIsNone(f(""))


class TestApelidoPorVoz(Base):
    def setUp(self):
        super().setUp()
        self.voz = VozFalsa()
        wpp = jairo.WhatsAppService(self.agenda, threading.Event(), None, habilitado=False)
        self.proc = jairo.ProcessadorComandos(
            wpp, self.voz, None, None, None, None, None, threading.Event(), simulado=True
        )

    def test_comando_completo(self):
        retorno = self.proc.processar("chame João Silva de joãozinho")
        self.assertIs(retorno, jairo.Retorno.SEM_SINAL)
        self.assertEqual(self.voz.falas, ["Pronto. Agora Joãozinho é apelido de João Silva."])
        self.assertIn("João Silva:5511999990001:Joãozinho", self.arquivo.read_text(encoding="utf-8"))
        self.assertEqual(self.agenda.buscar("joãozinho").nome, "João Silva")

    def test_sem_acento_na_fala_encontra_o_contato(self):
        self.proc.processar("chame joao silva de jj")
        self.assertEqual(self.agenda.buscar("jj").nome, "João Silva")

    def test_nome_com_de_no_meio(self):
        self.proc.processar("chame maria de souza de mazinha")
        self.assertEqual(self.agenda.buscar("mazinha").nome, "Maria de Souza")

    def test_nome_ambiguo_pede_nome_completo(self):
        self.proc.processar("chame maria de mariquinha")
        self.assertEqual(len(self.voz.falas), 1)
        self.assertIn("Diga o nome completo", self.voz.falas[0])
        self.assertNotIn("Mariquinha", self.arquivo.read_text(encoding="utf-8"))

    def test_contato_inexistente(self):
        self.proc.processar("chame fulano de beltrano")
        self.assertEqual(self.voz.falas, ["Não encontrei fulano na agenda."])

    def test_apelido_ja_usado_e_recusado_falando(self):
        self.proc.processar("chame joão silva de mari")
        self.assertIn("já é apelido de Maria de Souza", self.voz.falas[0])

    def test_sem_conector_explica_o_formato(self):
        self.proc.processar("chame joão silva")
        self.assertEqual(self.voz.falas, ["Diga: chame [nome] de [apelido]."])

    def test_arquivo_em_uso_avisa_sem_quebrar(self):
        original = jairo._gravar_atomico

        def falha(*args, **kwargs):
            raise OSError("em uso")

        jairo._gravar_atomico = falha
        try:
            self.proc.processar("chame joão silva de joãozinho")
        finally:
            jairo._gravar_atomico = original
        self.assertIn("Não consegui gravar no contatos.txt", self.voz.falas[0])


class TestPainelJairo(Base):
    def setUp(self):
        super().setUp()
        self.voz = VozFalsa()
        self.estado = jairo.EstadoFala()
        self.painel = jairo.PainelJairo(self.agenda, self.estado, self.voz, None, simulado=True)
        # Os editores do painel apontam para a pasta do projeto (CFG); use a de teste.
        self.assertTrue(self.painel.iniciar())
        self.addCleanup(self.painel.encerrar)
        self.srv = self.painel._servidor

    def req(self, metodo, caminho, corpo=None):
        cab = {"X-Chasame-Token": self.srv.token}
        dados = None
        if corpo is not None:
            dados = json.dumps(corpo).encode("utf-8")
            cab["Content-Type"] = "application/json"
        conexao = http.client.HTTPConnection("127.0.0.1", self.srv.porta, timeout=5)
        try:
            conexao.request(metodo, caminho, body=dados, headers=cab)
            resposta = conexao.getresponse()
            texto = resposta.read().decode("utf-8")
            try:
                return resposta.status, json.loads(texto)
            except ValueError:
                return resposta.status, texto
        finally:
            conexao.close()

    def test_descoberta_aponta_para_este_processo(self):
        dados = jairo._descoberta.localizar(timeout=2.0)
        self.assertIsNotNone(dados)
        self.assertEqual(dados["pid"], os.getpid())
        self.assertEqual(dados["porta"], self.srv.porta)

    def test_encerrar_remove_a_descoberta(self):
        self.painel.encerrar()
        self.assertIsNone(jairo._descoberta.ler())

    def test_comando_digitado_vai_para_a_fila_do_loop_principal(self):
        status, _ = self.req("POST", "/api/comando", {"texto": "que horas são"})
        self.assertEqual(status, 202)
        self.assertEqual(self.painel.comandos.get(timeout=2), "que horas são")

    def test_acoes_standby_e_silencioso_vao_para_a_fila(self):
        self.assertEqual(self.req("POST", "/api/acao", {"acao": "standby"})[0], 200)
        self.assertEqual(self.req("POST", "/api/acao", {"acao": "silencioso"})[0], 200)
        self.assertEqual(self.painel.acoes.get(timeout=2), "standby")
        self.assertEqual(self.painel.acoes.get(timeout=2), "silencioso")

    def test_acao_testar_fala(self):
        self.assertEqual(self.req("POST", "/api/acao", {"acao": "testar"})[0], 200)
        self.assertEqual(self.voz.falas, ["Teste de voz. Estou funcionando."])

    def test_acao_recarregar_pega_edicao_e_reporta_erro(self):
        self.arquivo.write_text(self.arquivo.read_text(encoding="utf-8") + "Zé Novo:5511999990020\n",
                                encoding="utf-8")
        self.assertEqual(self.req("POST", "/api/acao", {"acao": "recarregar"})[0], 200)
        self.assertEqual(self.agenda.buscar("zé novo").numero, "5511999990020")

        self.arquivo.write_text("lixo\n", encoding="utf-8")
        status, corpo = self.req("POST", "/api/acao", {"acao": "recarregar"})
        self.assertEqual(status, 400)
        self.assertIn("linha 1", json.dumps(corpo))

    def test_eventos_de_fala_e_estado(self):
        assinatura = self.painel.hub.assinar()
        self.painel.ao_falar("Olá", False)
        self.painel.ao_fim_fala()
        self.painel.sincronizar(jairo_ativo=False, ditado=False, silencioso=True)
        estado = self.painel.hub.estado()
        self.assertEqual(estado["modo"], "standby")
        self.assertTrue(estado["silencioso"])
        self.assertEqual(estado["atividade"], "nenhuma")
        tipos = []
        while True:
            evento = assinatura.obter(0.3)
            if evento is None:
                break
            tipos.append(evento["tipo"])
        self.assertIn("fala", tipos)
        self.assertIn("fala_fim", tipos)

    def test_explicar_nome(self):
        r = self.painel._explicar_nome("mari", None)
        self.assertEqual(r["resultado"], "unico")
        self.assertEqual(r["candidatos"][0]["nome"], "Maria de Souza")
        self.assertEqual(r["candidatos"][0]["via"], "apelido")

        r = self.painel._explicar_nome("maria", None)
        self.assertEqual(r["resultado"], "ambiguo")

        r = self.painel._explicar_nome("ana", "Ana Lima:5511999990009\n")
        self.assertEqual(r["resultado"], "unico")

        r = self.painel._explicar_nome("ana", "lixo\n")
        self.assertEqual(r["resultado"], "invalido")

    def test_log_do_jairo_chega_ao_vivo_na_tela(self):
        assinatura = self.painel.hub.assinar()
        jairo.logger.info("mensagem de teste ao vivo")
        jairo.logger.warning("aviso de teste ao vivo")
        recebidos = []
        while True:
            evento = assinatura.obter(0.3)
            if evento is None:
                break
            if evento["tipo"] == "log":
                recebidos.append((evento["dados"]["nivel"], evento["dados"]["msg"]))
        self.assertIn(("INFO", "mensagem de teste ao vivo"), recebidos)
        self.assertIn(("WARNING", "aviso de teste ao vivo"), recebidos)
        # Ao sair o ultimo cliente, o handler sai do logger (custo zero sem janela).
        self.painel.hub.remover(assinatura)
        self.assertFalse(any(isinstance(h, jairo.LogStream) for h in jairo.logger.handlers))

    def test_api_log_devolve_a_cauda_do_arquivo(self):
        jairo.logger.info("linha-para-a-cauda")
        for h in jairo.logger.handlers:
            h.flush()
        status, corpo = self.req("GET", "/api/log?bytes=100000")
        self.assertEqual(status, 200)
        self.assertTrue(any("linha-para-a-cauda" in r["msg"] for r in corpo["linhas"]))

    def test_standby_nao_anima_a_interface_com_o_microfone(self):
        assinatura = self.painel.hub.assinar()
        pcm = (9000).to_bytes(2, "little", signed=True) * 512          # "voz" bem alta

        self.painel.nivel_audio(pcm, 2)
        self.painel.sincronizar(jairo_ativo=True, ditado=False, silencioso=False)
        self.assertEqual(self.painel.hub.estado()["atividade"], "voz")

        self.painel.sincronizar(jairo_ativo=False, ditado=False, silencioso=False)
        self.assertEqual(self.painel.hub.estado()["modo"], "standby")
        self.assertEqual(self.painel.hub.estado()["atividade"], "nenhuma")   # a voz nao conta em espera
        while assinatura.obter(0.05) is not None:                             # descarta o que ja estava na fila
            pass
        for _ in range(5):
            time.sleep(0.06)
            self.painel.nivel_audio(pcm, 2)
        niveis = []
        while True:
            evento = assinatura.obter(0.1)
            if evento is None:
                break
            if evento["tipo"] == "nivel":
                niveis.append(evento["dados"]["v"])
        self.assertLessEqual(len(niveis), 1)                                   # no maximo o zeramento
        self.assertTrue(all(v == 0.0 for v in niveis))

    def test_nivel_audio_sem_cliente_nao_calcula(self):
        # Sem janela conectada o gancho retorna antes de qualquer calculo.
        self.painel.nivel_audio(b"\x00\x10" * 512, 2)
        self.assertEqual(self.painel._ultimo_calculo_nivel, 0.0)


@unittest.skipIf(jairo is None, f"dependencias do jairo.py ausentes: {_ERRO_IMPORT}")
class TestContatosPeloPainel(unittest.TestCase):
    """Pagina Contatos <-> painel <-> Agenda do Jairo, com o servidor HTTP de verdade."""

    def setUp(self):
        self.arquivo = jairo.CFG.caminho_contatos
        self.arquivo.parent.mkdir(parents=True, exist_ok=True)
        for sufixo in ("", ".bak"):
            Path(str(self.arquivo) + sufixo).unlink(missing_ok=True)
        self.arquivo.write_text(
            "João Silva:5511999990001\nMaria de Souza:5511999990002:Mari\n", encoding="utf-8"
        )
        self.agenda = jairo.Agenda(self.arquivo)
        self.voz = VozFalsa()
        self.painel = jairo.PainelJairo(self.agenda, jairo.EstadoFala(), self.voz, None, simulado=True)
        self.assertTrue(self.painel.iniciar())
        self.addCleanup(self.painel.encerrar)
        self.srv = self.painel._servidor

    def req(self, metodo, caminho, corpo=None, extra=None):
        cab = {"X-Chasame-Token": self.srv.token, **(extra or {})}
        dados = None
        if corpo is not None:
            dados = json.dumps(corpo).encode("utf-8")
            cab["Content-Type"] = "application/json"
        conexao = http.client.HTTPConnection("127.0.0.1", self.srv.porta, timeout=5)
        try:
            conexao.request(metodo, caminho, body=dados, headers=cab)
            resposta = conexao.getresponse()
            return resposta.status, json.loads(resposta.read().decode("utf-8") or "{}")
        finally:
            conexao.close()

    def test_get_lista_contatos_com_etag(self):
        status, corpo = self.req("GET", "/api/contatos")
        self.assertEqual(status, 200)
        self.assertEqual([c["nome"] for c in corpo["contatos"]], ["João Silva", "Maria de Souza"])
        self.assertEqual(corpo["contatos"][1]["apelidos"], ["Mari"])
        self.assertTrue(corpo["etag"])
        self.assertEqual(corpo["erros"], [])

    def test_salvar_pela_tela_grava_faz_backup_e_recarrega_a_agenda(self):
        _, atual = self.req("GET", "/api/contatos")
        tabela = atual["contatos"]
        tabela[0]["apelidos"] = ["Zezinho"]
        status, corpo = self.req("PUT", "/api/contatos", {"contatos": tabela}, {"If-Match": atual["etag"]})
        self.assertEqual(status, 200)
        self.assertTrue(corpo["alterado"])
        self.assertIn("João Silva:5511999990001:Zezinho", self.arquivo.read_text(encoding="utf-8"))
        self.assertTrue(Path(str(self.arquivo) + ".bak").exists())
        self.assertEqual(self.agenda.buscar("zezinho").nome, "João Silva")     # sem reiniciar

    def test_etag_velha_da_409(self):
        _, atual = self.req("GET", "/api/contatos")
        self.agenda.adicionar_apelido(self.agenda.buscar("joão silva"), "Jão")   # mudou por fora (voz)
        status, _ = self.req("PUT", "/api/contatos", {"contatos": atual["contatos"]}, {"If-Match": atual["etag"]})
        self.assertEqual(status, 409)

    def test_regra_do_jairo_recusa_com_422(self):
        _, atual = self.req("GET", "/api/contatos")
        tabela = atual["contatos"]
        tabela[0]["apelidos"] = ["Mari"]                  # ja e da Maria
        status, corpo = self.req("PUT", "/api/contatos", {"contatos": tabela}, {"If-Match": atual["etag"]})
        self.assertEqual(status, 422)
        self.assertIn("apelido duplicado", json.dumps(corpo, ensure_ascii=False))
        self.assertNotIn("Mari", self.arquivo.read_text(encoding="utf-8").splitlines()[0])

    def test_apelido_por_voz_avisa_a_tela_e_aparece_na_lista(self):
        assinatura = self.painel.hub.assinar()
        wpp = jairo.WhatsAppService(self.agenda, threading.Event(), None, habilitado=False)
        proc = jairo.ProcessadorComandos(
            wpp, self.voz, None, None, None, None, None, threading.Event(), simulado=True
        )
        proc.processar("chame João Silva de Joãozinho")

        motivos = []
        while True:
            evento = assinatura.obter(0.3)
            if evento is None:
                break
            if evento["tipo"] == "agenda":
                motivos.append(evento["dados"]["motivo"])
        self.assertEqual(motivos, ["apelido"])
        _, corpo = self.req("GET", "/api/contatos")
        self.assertEqual(corpo["contatos"][0]["apelidos"], ["Joãozinho"])

    def test_explicar_com_alteracoes_ainda_nao_salvas(self):
        _, atual = self.req("GET", "/api/contatos")
        tabela = atual["contatos"]
        tabela[0]["apelidos"] = ["Jão"]
        status, corpo = self.req("POST", "/api/contatos/explicar", {"nome": "jão", "contatos": tabela})
        self.assertEqual(status, 200)
        self.assertEqual(corpo["resultado"], "unico")
        self.assertEqual(corpo["candidatos"][0]["nome"], "João Silva")
        self.assertEqual(self.agenda.buscar_todos("jão"), [])                    # nada foi gravado


@unittest.skipIf(jairo is None, f"dependencias do jairo.py ausentes: {_ERRO_IMPORT}")
class TestPapeis(unittest.TestCase):
    def test_papel_inicial(self):
        f = jairo._papel_inicial
        self.assertEqual(f(["--janela"]), "janela")
        for flag in ("--motor", "--autostart", "--terminal", "--com-janela", "--sem-janela",
                     "--texto", "--sem-painel"):
            self.assertEqual(f([flag]), "motor", flag)
        # Sem argumentos: abre a janela (a pasta ui/ existe ao lado do jairo.py).
        self.assertEqual(f([]), "lancador")

    def test_tela_de_inicio_da_janela_le_o_log(self):
        html = jairo._HTML_INICIO
        self.assertIn("ler_log", html)
        self.assertIn("falhou()", html)

    def test_rms_pcm_sem_audioop(self):
        antigo = jairo.audioop
        jairo.audioop = None
        try:
            silencio = jairo._rms_pcm(b"\x00\x00" * 100, 2)
            sinal = jairo._rms_pcm((1000).to_bytes(2, "little", signed=True) * 100, 2)
        finally:
            jairo.audioop = antigo
        self.assertEqual(silencio, 0.0)
        self.assertAlmostEqual(sinal, 1000.0, places=3)


if __name__ == "__main__":
    unittest.main()
