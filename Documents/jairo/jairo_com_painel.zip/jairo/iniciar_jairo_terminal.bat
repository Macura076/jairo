@echo off
rem Abre o Jairo com a interface e mantem este terminal aberto, mostrando os logs tambem aqui.
cd /d "%~dp0"
python jairo.py --terminal
pause
