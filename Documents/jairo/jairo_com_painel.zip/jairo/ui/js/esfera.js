// Cores como [r,g,b]; amp = deformacao, vel = velocidade, glow = brilho, anel: 0 nenhum | 1 pontilhado | 2 duplo, gira = arco girando.
const E = (c1, c2, amp, vel, glow, anel = 0, gira = 0) => ({
  r1: c1[0], g1: c1[1], b1: c1[2], r2: c2[0], g2: c2[1], b2: c2[2], amp, vel, glow, anel, gira,
});
export const ESTADOS = {
  ouvindo:     E([212, 175, 55], [240, 215, 122], .05, .6, .55),
  voz:         E([255, 200, 0], [255, 214, 10], .13, 1.3, .95),
  processando: E([255, 200, 0], [184, 150, 46], .09, 2.8, .8, 0, 1),
  falando:     E([240, 215, 122], [212, 175, 55], .08, 1.4, .85),
  standby:     E([96, 86, 58], [58, 54, 42], 0, 0, .1),      // parada: circulo fixo, sem brilho pulsando
  silencioso:  E([200, 140, 30], [150, 105, 28], .04, .5, .4, 1),
  ditado:      E([212, 175, 55], [240, 215, 122], .05, .7, .6, 2),
  erro:        E([192, 57, 43], [110, 28, 20], .09, 1.6, .6),
  offline:     E([72, 72, 72], [44, 44, 44], .015, .15, .08),
};
const ATIVOS = new Set(["voz", "processando", "falando", "erro"]);
const PONTOS = 72;

export class Esfera {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.atual = { ...ESTADOS.offline };
    this.nome = "offline";
    this.nivelAlvo = 0; this.nivel = 0;
    this.fala = null;               // { inicio, duracao }
    this.t = 0; this.ultimo = 0; this.raf = 0;
    this.reduzido = matchMedia("(prefers-reduced-motion: reduce)").matches;
    new ResizeObserver(() => this.ajustar()).observe(canvas);
    document.addEventListener("visibilitychange", () => (document.hidden ? this.pausar() : this.iniciar()));
    this.ajustar();
    this.iniciar();
  }
  definir(nome) {
    if (!ESTADOS[nome] || nome === this.nome) return;
    this.nome = nome;
    if (nome === "standby") { this.nivelAlvo = 0; this.fala = null; }
    this.iniciar();                                   // acorda o laco se estava parado no standby
  }
  definirNivel(v) { this.nivelAlvo = Math.max(0, Math.min(1, v)); }
  falar(duracaoMs) { this.fala = { inicio: performance.now(), duracao: Math.max(400, duracaoMs || 1500) }; }
  pararFala() { this.fala = null; }

  ajustar() {
    const dpr = Math.min(devicePixelRatio || 1, 2);   // limitado a 2: custo de preenchimento previsivel
    const lado = Math.max(64, Math.round(this.canvas.clientWidth * dpr));
    if (this.canvas.width !== lado) { this.canvas.width = lado; this.canvas.height = lado; }
  }
  iniciar() { if (!this.raf && !document.hidden) { this.ultimo = performance.now(); this.raf = requestAnimationFrame((n) => this.quadro(n)); } }
  pausar() { cancelAnimationFrame(this.raf); this.raf = 0; }

  quadro(agora) {
    this.raf = requestAnimationFrame((n) => this.quadro(n));
    const intervalo = this.reduzido ? 100 : ATIVOS.has(this.nome) || this.nivel > .05 ? 0 : 33;   // 60 fps com atividade, 30 em repouso
    if (agora - this.ultimo < intervalo) return;
    const dt = Math.min((agora - this.ultimo) / 1000, .1);
    this.ultimo = agora;
    const k = 1 - Math.exp(-dt / .13);                 // ~400 ms ate assentar
    const alvo = ESTADOS[this.nome];
    for (const chave in alvo) this.atual[chave] += (alvo[chave] - this.atual[chave]) * k;
    this.nivel += (this.nivelAlvo - this.nivel) * (1 - Math.exp(-dt / .06));
    this.t += dt * (this.reduzido ? 0 : this.atual.vel);
    this.desenhar(agora);

    // Standby assentado: desenha o ultimo quadro e PARA o laco (nada se mexe, CPU ~0).
    if (this.nome === "standby" && this.assentado(alvo)) {
      Object.assign(this.atual, alvo);
      this.nivel = 0;
      this.desenhar(agora);
      this.pausar();
    }
  }

  assentado(alvo) {
    if (this.nivel > .005 || this.fala) return false;
    for (const chave in alvo) if (Math.abs(alvo[chave] - this.atual[chave]) > .01) return false;
    return true;
  }
  envelope(agora) {
    if (!this.fala) return 0;
    const p = (agora - this.fala.inicio) / this.fala.duracao;
    if (p > 1.25) { this.fala = null; return 0; }
    const silaba = .55 + .45 * Math.abs(Math.sin((agora - this.fala.inicio) / 1000 * 11));   // ~4-5 silabas por segundo
    const frase = .6 + .4 * Math.sin((agora - this.fala.inicio) / 1000 * 2.3);
    return silaba * frase * (p > 1 ? Math.max(0, 1 - (p - 1) * 4) : 1);
  }

  desenhar(agora) {
    const { ctx, canvas, atual: a } = this;
    const L = canvas.width, c = L / 2, R = L * .27;
    const env = this.envelope(agora);
    const mov = this.reduzido ? 0 : 1;
    const amp = (a.amp + this.nivel * .22 + env * .16) * mov;
    ctx.clearRect(0, 0, L, L);

    // halo
    const halo = ctx.createRadialGradient(c, c, R * .6, c, c, R * 2.1);
    halo.addColorStop(0, `rgba(${a.r1 | 0},${a.g1 | 0},${a.b1 | 0},${.34 * a.glow})`);
    halo.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = halo; ctx.fillRect(0, 0, L, L);

    // corpo: raio = base + soma de senoides (contorno fluido, sem ruido pesado)
    ctx.beginPath();
    for (let i = 0; i <= PONTOS; i++) {
      const th = (i / PONTOS) * Math.PI * 2;
      const n = Math.sin(th * 2 + this.t * 1.1) * .5 + Math.sin(th * 3 - this.t * 1.7) * .32 + Math.sin(th * 5 + this.t * 2.3) * .18;
      const r = R * (1 + amp * n * 2.2 + env * .06);
      const x = c + Math.cos(th) * r, y = c + Math.sin(th) * r;
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    }
    ctx.closePath();
    const g = ctx.createRadialGradient(c - R * .3, c - R * .35, R * .1, c, c, R * 1.15);
    g.addColorStop(0, `rgb(${a.r2 | 0},${a.g2 | 0},${a.b2 | 0})`);
    g.addColorStop(1, `rgb(${a.r1 | 0},${a.g1 | 0},${a.b1 | 0})`);
    ctx.fillStyle = g;
    ctx.shadowColor = `rgba(${a.r1 | 0},${a.g1 | 0},${a.b1 | 0},${.7 * a.glow})`;
    ctx.shadowBlur = L * .06 * a.glow;
    ctx.fill();
    ctx.shadowBlur = 0;

    // processando: arco de brilho girando
    if (a.gira > .02) {
      ctx.lineWidth = L * .012; ctx.lineCap = "round";
      ctx.strokeStyle = `rgba(255,236,150,${.9 * a.gira})`;
      const ini = this.t * 2.4;
      ctx.beginPath(); ctx.arc(c, c, R * 1.28, ini, ini + 1.2); ctx.stroke();
    }
    // aneis: pontilhado (silencioso) e duplo (ditado)
    if (a.anel > .02) {
      ctx.lineWidth = L * .006;
      if (a.anel < 1.5) {
        ctx.setLineDash([L * .008, L * .018]); ctx.strokeStyle = `rgba(240,215,122,${.8 * Math.min(1, a.anel)})`;
        ctx.beginPath(); ctx.arc(c, c, R * 1.4, this.t * .2, this.t * .2 + Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
      } else {
        ctx.strokeStyle = `rgba(240,215,122,${.7 * (a.anel - 1)})`;
        for (const f of [1.3, 1.46]) { ctx.beginPath(); ctx.arc(c, c, R * f, 0, Math.PI * 2); ctx.stroke(); }
      }
    }
  }
}
