import { api } from "./api.js";

// Pagina Contatos: edita o contatos.txt por tabela. O servidor valida (mesmas regras do
// Jairo), grava com backup .bak e recarrega a agenda; a tela so monta e envia a tabela.
// Texto sempre via textContent/value (nunca innerHTML).

const $ = (id) => document.getElementById(id);
const TELEFONE = /^[1-9]\d{9,14}$/;
const sem_acento = (t) => t.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase();
const limpar_numero = (t) => t.replace(/[\s().+-]/g, "");

function el(tag, classe, texto) {
  const e = document.createElement(tag);
  if (classe) e.className = classe;
  if (texto !== undefined) e.textContent = texto;
  return e;
}

export class Contatos {
  constructor(aoMudarSujo = () => {}) {
    this.aoMudarSujo = aoMudarSujo;
    this.linhas = [];            // copia de trabalho
    this.original = "[]";        // serializacao do que esta no arquivo (detecta alteracoes)
    this.etag = null;
    this.erros = new Map();      // indice da linha -> [{campo, mensagem}]
    this.sujo = false;
    this.filtro = "";
    this.chave = 0;

    $("contatos-adicionar").addEventListener("click", () => this.adicionarLinha());
    $("contatos-salvar").addEventListener("click", () => this.salvar());
    $("contatos-descartar").addEventListener("click", () => this.descartar());
    $("contatos-recarregar").addEventListener("click", () => this.recarregarComAviso());
    $("contatos-busca").addEventListener("input", (e) => { this.filtro = sem_acento(e.target.value.trim()); this.aplicarFiltro(); });
    $("contatos-teste").addEventListener("submit", (e) => { e.preventDefault(); this.testarNome(); });
    window.addEventListener("focus", () => this.verificarMudanca());
  }

  // --- dados -----------------------------------------------------------------

  async carregar({ silencioso = false } = {}) {
    try {
      const d = await api("GET", "/api/contatos");
      this.aplicarServidor(d);
      if (!silencioso) this.aviso("");
    } catch (e) {
      this.aviso(`Não consegui carregar os contatos: ${e.message}`, "erro");
    }
  }

  aplicarServidor(d) {
    this.etag = d.etag;
    this.linhas = (d.contatos || []).map((c) => ({ ...c, apelidos: [...(c.apelidos || [])], _k: ++this.chave }));
    this.original = JSON.stringify(this.serializar());
    this.erros = new Map();
    this.mostrarErrosArquivo(d.erros || []);
    this.render();
    this.atualizarSujo();
  }

  serializar() {
    return this.linhas.map((l) => {
      if (l.invalida) return { id: l.id, invalida: true };
      const item = { nome: l.nome.trim(), numero: limpar_numero(l.numero), apelidos: [...l.apelidos], ativo: !!l.ativo };
      if (l.id !== undefined && l.id !== null) item.id = l.id;
      return item;
    });
  }

  atualizarSujo() {
    const sujo = JSON.stringify(this.serializar()) !== this.original;
    $("contatos-salvar").disabled = !sujo;
    $("contatos-descartar").disabled = !sujo;
    if (sujo !== this.sujo) { this.sujo = sujo; this.aoMudarSujo(sujo); }
    this.atualizarResumo();
  }

  atualizarResumo() {
    const validas = this.linhas.filter((l) => !l.invalida);
    const ativos = validas.filter((l) => l.ativo).length;
    const invalidas = this.linhas.length - validas.length;
    $("contatos-resumo").textContent =
      `${ativos} ativo(s), ${validas.length - ativos} inativo(s)` + (invalidas ? `, ${invalidas} linha(s) inválida(s) no arquivo` : "") + ".";
  }

  // --- acoes -----------------------------------------------------------------

  adicionarLinha() {
    this.linhas.push({ nome: "", numero: "", apelidos: [], ativo: true, _k: ++this.chave });
    this.filtro = ""; $("contatos-busca").value = "";
    this.render();
    this.atualizarSujo();
    const campos = $("contatos-corpo").querySelectorAll("input.campo-nome");
    campos[campos.length - 1]?.focus();
  }

  remover(l) {
    this.linhas = this.linhas.filter((x) => x !== l);
    this.erros = new Map();
    this.render();
    this.atualizarSujo();
  }

  descartar() {
    this.carregar();      // volta ao que esta no arquivo
  }

  recarregarComAviso() {
    if (this.sujo && !confirm("Há alterações não salvas. Recarregar do arquivo e perdê-las?")) return;
    this.carregar();
  }

  async salvar() {
    const erroLocal = this.validarLocal();
    if (erroLocal) { this.render(); this.aviso(erroLocal, "erro"); return; }
    $("contatos-salvar").disabled = true;
    try {
      const d = await api("PUT", "/api/contatos", { contatos: this.serializar() }, { "If-Match": this.etag });
      this.aplicarServidor(d);
      this.aviso(d.aviso ? d.aviso : d.alterado ? "Salvo. A agenda já foi recarregada, sem reiniciar o Jairo." : "Nada mudou.", d.aviso ? "erro" : "ok");
    } catch (e) {
      this.atualizarSujo();
      if (e.status === 409) {
        this.aviso("O contatos.txt mudou fora desta tela (talvez por voz ou no Bloco de Notas). Recarregue para ver a versão atual; suas alterações aqui não foram salvas.", "erro", {
          rotulo: "Recarregar (perde minhas alterações)", acao: () => this.carregar(),
        });
      } else if (e.status === 422) {
        this.mostrarErrosServidor(e.dados);
      } else {
        this.aviso(`Não consegui salvar: ${e.message}`, "erro");
      }
    }
  }

  // --- validacao -------------------------------------------------------------

  validarLocal() {
    this.erros = new Map();
    const nomes = new Map();
    this.linhas.forEach((l, i) => {
      if (l.invalida) return;
      const problemas = [];
      if (!l.nome.trim()) problemas.push({ campo: "nome", mensagem: "Informe o nome." });
      if (!TELEFONE.test(limpar_numero(l.numero))) {
        problemas.push({ campo: "numero", mensagem: "Número com DDI+DDD+número, só dígitos (ex.: 5511999998888)." });
      }
      const k = sem_acento(l.nome.trim());
      if (k) {
        if (nomes.has(k)) problemas.push({ campo: "nome", mensagem: `Nome repetido (linha ${nomes.get(k) + 1}).` });
        else nomes.set(k, i);
      }
      if (problemas.length) this.erros.set(i, problemas);
    });
    return this.erros.size ? `Corrija ${this.erros.size} linha(s) marcada(s) antes de salvar.` : "";
  }

  mostrarErrosServidor(dados) {
    this.erros = new Map();
    const gerais = [];
    for (const e of dados.erros || []) {
      if (typeof e.indice === "number") {
        const lista = this.erros.get(e.indice) || [];
        lista.push({ campo: e.campo, mensagem: e.mensagem });
        this.erros.set(e.indice, lista);
      } else {
        gerais.push(e.linha ? `Linha ${e.linha}: ${e.mensagem}` : e.mensagem);
      }
    }
    this.render();
    this.aviso(gerais.length ? gerais.join(" ") : "O Jairo recusou algumas linhas; veja as marcadas.", "erro");
  }

  mostrarErrosArquivo(erros) {
    const lista = $("contatos-erros-arquivo");
    lista.replaceChildren(...erros.map((e) => el("li", null, `Linha ${e.linha} do arquivo: ${e.mensagem}`)));
    lista.hidden = erros.length === 0;
  }

  // --- teste de nome falado --------------------------------------------------

  async testarNome() {
    const nome = $("contatos-teste-nome").value.trim();
    const saida = $("contatos-teste-res");
    if (!nome) { saida.textContent = ""; return; }
    try {
      const corpo = { nome };
      if (this.sujo) corpo.contatos = this.serializar();   // testa com as alteracoes ainda nao salvas
      const r = await api("POST", "/api/contatos/explicar", corpo);
      const cand = (r.candidatos || []).map((c) => `${c.nome} (final ${c.final}, por ${c.via})`);
      saida.textContent =
        r.resultado === "unico" ? `Vai para: ${cand[0]}.` :
        r.resultado === "ambiguo" ? `Ambíguo, o Jairo pedirá o nome completo: ${cand.join(" ou ")}.` :
        r.resultado === "invalido" ? `Corrija o arquivo antes de testar: ${r.erro}` :
        "Nenhum contato responde por esse nome.";
    } catch (e) {
      saida.textContent = e.status === 422 ? "Corrija as linhas marcadas para testar com as alterações." : `Erro: ${e.message}`;
    }
  }

  // --- mudancas fora da tela ---------------------------------------------------

  // Chamado pelo evento "agenda" (ex.: apelido criado por voz) e ao voltar o foco para a janela.
  async verificarMudanca(motivo = "") {
    if ($("pagina-contatos").hidden && !motivo) return;
    try {
      const d = await api("GET", "/api/contatos");
      if (d.etag === this.etag) return;
      if (!this.sujo) {
        this.aplicarServidor(d);
        this.aviso(motivo === "apelido" ? "Apelido adicionado por voz: lista atualizada." : "O arquivo mudou: lista atualizada.", "info");
      } else {
        this.aviso("O contatos.txt mudou fora desta tela. Salve ou descarte suas alterações e recarregue.", "erro", {
          rotulo: "Recarregar (perde minhas alterações)", acao: () => this.carregar(),
        });
      }
    } catch { /* offline: tentamos de novo no proximo foco */ }
  }

  aoMostrar() {
    if (!this.etag) this.carregar(); else this.verificarMudanca();
  }

  // --- desenho ---------------------------------------------------------------

  aviso(texto, tipo = "info", botao = null) {
    const caixa = $("contatos-aviso");
    caixa.hidden = !texto;
    caixa.dataset.tipo = tipo;
    caixa.replaceChildren(el("span", null, texto));
    if (botao) {
      const b = el("button", "link", botao.rotulo);
      b.type = "button"; b.addEventListener("click", botao.acao);
      caixa.append(" ", b);
    }
  }

  render() {
    const corpo = $("contatos-corpo");
    const linhas = [];
    this.linhas.forEach((l, i) => {
      linhas.push(this.criarLinha(l, i));
      const problemas = this.erros.get(i);
      if (problemas?.length) {
        const tr = el("tr", "linha-erro");
        const td = el("td", null, problemas.map((p) => p.mensagem).join(" "));
        td.colSpan = 5;
        tr.append(td);
        linhas.push(tr);
      }
    });
    if (!linhas.length) {
      const tr = el("tr"); const td = el("td", "vazio", "Nenhum contato ainda. Use “Adicionar contato”.");
      td.colSpan = 5; tr.append(td); linhas.push(tr);
    }
    corpo.replaceChildren(...linhas);
    this.aplicarFiltro();
  }

  criarLinha(l, i) {
    const tr = el("tr", l.ativo === false ? "inativo" : "");
    tr.dataset.busca = sem_acento(`${l.nome} ${l.numero} ${l.apelidos.join(" ")} ${l.bruto || ""}`);
    const marcado = (campo) => (this.erros.get(i) || []).some((p) => p.campo === campo);

    if (l.invalida) {
      const td = el("td", "invalida", `Linha inválida no arquivo: ${l.bruto}`);
      td.colSpan = 4;
      const acao = el("td", "acoes");
      const b = el("button", "botao", "Remover"); b.type = "button";
      b.setAttribute("aria-label", `Remover a linha inválida ${l.bruto}`);
      b.addEventListener("click", () => this.remover(l));
      acao.append(b);
      tr.append(td, acao);
      return tr;
    }

    const ativo = el("td");
    const chk = el("input"); chk.type = "checkbox"; chk.checked = !!l.ativo;
    chk.setAttribute("aria-label", `Contato ativo: ${l.nome || "novo"}`);
    chk.addEventListener("change", () => { l.ativo = chk.checked; tr.classList.toggle("inativo", !l.ativo); this.atualizarSujo(); });
    ativo.append(chk);

    const nome = el("td");
    const inNome = el("input", "campo campo-nome"); inNome.value = l.nome; inNome.placeholder = "Nome completo";
    inNome.maxLength = 80; inNome.setAttribute("aria-label", "Nome");
    inNome.setAttribute("aria-invalid", String(marcado("nome")));
    inNome.addEventListener("input", () => { l.nome = inNome.value; this.atualizarSujo(); });
    nome.append(inNome);

    const numero = el("td");
    const inNum = el("input", "campo campo-numero"); inNum.value = l.numero; inNum.placeholder = "5511999998888";
    inNum.inputMode = "numeric"; inNum.setAttribute("aria-label", "Número com DDI e DDD");
    inNum.setAttribute("aria-invalid", String(marcado("numero")));
    inNum.addEventListener("input", () => { l.numero = inNum.value; this.atualizarSujo(); });
    inNum.addEventListener("blur", () => { const limpo = limpar_numero(inNum.value); if (limpo !== inNum.value) { inNum.value = limpo; l.numero = limpo; this.atualizarSujo(); } });
    numero.append(inNum);

    const apelidos = el("td", "celula-apelidos");
    const chips = el("div", "chips");
    const desenharChips = () => {
      chips.replaceChildren(...l.apelidos.map((a, k) => {
        const c = el("span", "chip", a);
        const x = el("button", "chip-x", "×"); x.type = "button";
        x.setAttribute("aria-label", `Remover o apelido ${a}`);
        x.addEventListener("click", () => { l.apelidos.splice(k, 1); desenharChips(); this.atualizarSujo(); });
        c.append(x);
        return c;
      }));
    };
    desenharChips();
    const inAp = el("input", "campo campo-apelido"); inAp.placeholder = "+ apelido"; inAp.maxLength = 60;
    inAp.setAttribute("aria-label", "Adicionar apelido (Enter)");
    const confirmar = () => {
      const valor = inAp.value.replace(/[,:\n\r]/g, " ").split(/\s+/).filter(Boolean).join(" ");
      inAp.value = "";
      if (!valor) return;
      if (l.apelidos.some((a) => sem_acento(a) === sem_acento(valor))) return;
      l.apelidos.push(valor); desenharChips(); this.atualizarSujo();
    };
    inAp.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === ",") { e.preventDefault(); confirmar(); }
      else if (e.key === "Backspace" && !inAp.value && l.apelidos.length) { l.apelidos.pop(); desenharChips(); this.atualizarSujo(); }
    });
    inAp.addEventListener("blur", confirmar);
    apelidos.append(chips, inAp);

    const acoes = el("td", "acoes");
    const rem = el("button", "botao", "×"); rem.type = "button";
    rem.setAttribute("aria-label", `Remover o contato ${l.nome || "novo"}`);
    rem.addEventListener("click", () => this.remover(l));
    acoes.append(rem);

    tr.append(ativo, nome, numero, apelidos, acoes);
    return tr;
  }

  aplicarFiltro() {
    for (const tr of $("contatos-corpo").querySelectorAll("tr[data-busca]")) {
      const mostrar = !this.filtro || tr.dataset.busca.includes(this.filtro);
      tr.hidden = !mostrar;
      if (tr.nextElementSibling?.classList.contains("linha-erro")) tr.nextElementSibling.hidden = !mostrar;
    }
  }
}
