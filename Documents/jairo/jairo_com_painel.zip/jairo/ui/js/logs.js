import { api } from "./api.js";

// Logs do Jairo na tela: pagina "Logs" (filtros, busca, pausa, seguir o fim) e o
// painel "Log ao vivo" do Inicio. Os registros chegam pelo evento SSE "log" e a
// cauda do arquivo vem de /api/log. Texto sempre via textContent (nunca innerHTML).

const $ = (id) => document.getElementById(id);
const MAX_REGISTROS = 3000;   // em memoria
const MAX_LINHAS = 1500;      // no DOM da pagina de logs
const MAX_MINI = 8;           // no painel do Inicio

const NUMERO = { DEBUG: 10, INFO: 20, WARNING: 30, WARN: 30, ERROR: 40, CRITICAL: 50 };
const ROTULO = { DEBUG: "debug", INFO: "info", WARNING: "aviso", WARN: "aviso", ERROR: "erro", CRITICAL: "crítico" };

const numero = (r) => NUMERO[r.nivel] ?? 20;
const classe = (r) => `nivel-${(r.nivel || "INFO").toLowerCase()}`;
const chave = (r) => `${r.ts}|${r.nivel}|${r.msg}`;

export class Logs {
  constructor() {
    this.registros = [];
    this.vistos = new Set();   // evita repetir, ao vivo, o que a cauda do arquivo ja trouxe
    this.pausado = false;
    this.seguir = true;
    this.minimo = Number($("log-nivel").value) || 20;
    this.busca = "";

    $("log-nivel").addEventListener("change", (e) => { this.minimo = Number(e.target.value); this.renderTudo(); });
    $("log-busca").addEventListener("input", (e) => { this.busca = e.target.value.trim().toLowerCase(); this.renderTudo(); });
    $("log-pausar").addEventListener("click", () => this.alternarPausa());
    $("log-limpar").addEventListener("click", () => { this.registros = []; this.renderTudo(); this.renderMini(); });
    $("log-abrir").addEventListener("click", () => {
      api("POST", "/api/acao", { acao: "abrir_arquivo", arquivo: "log" }).catch(() => {});
    });
    $("log-fim").addEventListener("click", () => this.irParaOFim());
    $("log-lista").addEventListener("scroll", () => {
      const l = $("log-lista");
      this.seguir = l.scrollTop + l.clientHeight >= l.scrollHeight - 24;
      $("log-fim").hidden = this.seguir;
    });
  }

  // --- dados ---------------------------------------------------------------

  async carregar() {
    try {
      const { linhas } = await api("GET", "/api/log?bytes=200000");
      this.registros = (linhas || []).slice(-MAX_REGISTROS);
      this.vistos = new Set(this.registros.slice(-400).map(chave));
      setTimeout(() => this.vistos.clear(), 4000);
      this.renderTudo();
      this.renderMini();
    } catch { /* sem cauda: so o que chegar ao vivo */ }
  }

  adicionar(r) {
    const k = chave(r);
    if (this.vistos.delete(k)) return;           // ja veio na cauda
    this.registros.push(r);
    if (this.registros.length > MAX_REGISTROS) this.registros.splice(0, this.registros.length - MAX_REGISTROS);

    if (!this.pausado && this.passa(r)) {
      $("log-lista").append(this.linha(r));
      while ($("log-lista").children.length > MAX_LINHAS) $("log-lista").firstChild.remove();
      if (this.seguir) this.irParaOFim();
    }
    if (numero(r) >= 20) {
      const mini = $("mini-log");
      mini.querySelector(".vazio")?.remove();
      mini.append(this.linhaMini(r));
      while (mini.children.length > MAX_MINI) mini.firstChild.remove();
    }
    this.atualizarContagem();
  }

  // --- filtros e desenho ---------------------------------------------------

  passa(r) {
    if (numero(r) < this.minimo) return false;
    if (!this.busca) return true;
    return `${r.msg} ${r.thread}`.toLowerCase().includes(this.busca);
  }

  linha(r) {
    const li = document.createElement("li");
    li.className = `log-linha ${classe(r)}`;
    const ts = document.createElement("span"); ts.className = "log-ts"; ts.textContent = r.ts || "";
    const nv = document.createElement("span"); nv.className = "log-nivel"; nv.textContent = ROTULO[r.nivel] || r.nivel || "";
    const th = document.createElement("span"); th.className = "log-thread"; th.textContent = r.thread || "";
    const ms = document.createElement("span"); ms.className = "log-msg"; ms.textContent = r.msg;
    li.append(ts, nv, th, ms);
    return li;
  }

  linhaMini(r) {
    const li = document.createElement("li");
    li.className = classe(r);
    const ts = document.createElement("span"); ts.className = "log-ts"; ts.textContent = r.ts || "";
    const ms = document.createElement("span"); ms.className = "log-msg"; ms.textContent = r.msg.split("\n")[0];
    li.append(ts, ms);
    return li;
  }

  renderTudo() {
    const lista = $("log-lista");
    lista.replaceChildren(...this.registros.filter((r) => this.passa(r)).slice(-MAX_LINHAS).map((r) => this.linha(r)));
    this.atualizarContagem();
    if (this.seguir) this.irParaOFim();
  }

  renderMini() {
    const mini = $("mini-log");
    const itens = this.registros.filter((r) => numero(r) >= 20).slice(-MAX_MINI);
    if (!itens.length) {
      const vazio = document.createElement("li");
      vazio.className = "vazio"; vazio.textContent = "Aguardando o Jairo…";
      mini.replaceChildren(vazio);
      return;
    }
    mini.replaceChildren(...itens.map((r) => this.linhaMini(r)));
  }

  atualizarContagem() {
    const visiveis = $("log-lista").children.length;
    $("log-contagem").textContent = `${visiveis} de ${this.registros.length} registros${this.pausado ? " (pausado)" : ""}`;
  }

  // --- controles -----------------------------------------------------------

  alternarPausa() {
    this.pausado = !this.pausado;
    $("log-pausar").setAttribute("aria-pressed", String(this.pausado));
    $("log-pausar").textContent = this.pausado ? "Continuar" : "Pausar";
    if (!this.pausado) this.renderTudo(); else this.atualizarContagem();
  }

  irParaOFim() {
    const l = $("log-lista");
    l.scrollTop = l.scrollHeight;
    this.seguir = true;
    $("log-fim").hidden = true;
  }

  aoMostrar() {
    this.renderTudo();
    this.irParaOFim();
  }
}
