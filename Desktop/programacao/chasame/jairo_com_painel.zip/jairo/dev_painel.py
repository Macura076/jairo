"""
Demonstracao do painel sem o Chasame, sem Windows e sem microfone.

    python dev_painel.py        # sobe o servidor e abre o navegador (nada acontece sozinho)
    python dev_painel.py --demo # tambem simula frases ficticias a cada ~6 s, so para ver a esfera animada

Nada aqui executa programas no seu computador: so publica eventos de texto para a tela.

Os contatos e permitidos de exemplo ficam numa pasta temporaria; nada do seu
C:\\09projec e tocado. Ctrl+C encerra.
"""

from __future__ import annotations

import argparse
import math
import random
import tempfile
import threading
import time
import webbrowser
from pathlib import Path

from painel import (
    Contexto, EditorContatos, EditorPermitidos, Hub, ServidorPainel, VERSAO_PAINEL, descoberta,
)
from tests.ref_agenda import analisar

AQUI = Path(__file__).resolve().parent


def principal() -> None:
    argumentos = argparse.ArgumentParser()
    argumentos.add_argument("--demo", action="store_true")
    argumentos.add_argument("--sem-navegador", action="store_true")
    opcoes = argumentos.parse_args()

    pasta = Path(tempfile.mkdtemp(prefix="chasame-dev-"))
    (pasta / "contatos.txt").write_text(
        "# Contatos de exemplo\nGustavo Silva:5511999998888:gu,guto\nMaria Souza:5511988887777\n"
        "!Pedro Antigo:5511977776666\n", encoding="utf-8")
    (pasta / "permitidos.txt").write_text("# nomes como no WhatsApp\nGustavo Silva\n", encoding="utf-8")

    hub = Hub()
    hub.definir_estado(pronto=True)

    def falar(texto: str, ms: int) -> None:
        hub.publicar("fala", {"texto": texto, "duracao_estimada_ms": ms, "muda": False})
        hub.definir_estado(atividade="falando")
        time.sleep(ms / 1000)
        hub.publicar("fala_fim")
        hub.definir_estado(atividade="nenhuma")

    def simular_comando(texto: str, origem: str = "texto") -> None:
        hub.definir_estado(atividade="processando")
        time.sleep(0.7)
        hub.publicar("transcricao", {"texto": texto, "origem": origem})
        if "xyz" in texto.lower():
            hub.registrar_comando(texto, "nao_reconhecido", origem)
            hub.definir_estado(atividade="nenhuma")
            return
        hub.registrar_comando(texto, "ok", origem)
        falar(f"Abrindo {texto.split()[-1]}.", 1800)

    def executar_acao(acao: str, dados: dict) -> dict:
        if acao == "standby":
            hub.definir_estado(modo="ouvindo" if hub.estado()["modo"] == "standby" else "standby")
        elif acao == "silencioso":
            hub.definir_estado(silencioso=not hub.estado()["silencioso"])
        return {}

    contexto = Contexto(
        nome="Chasame", versao=f"dev-{VERSAO_PAINEL}", dir_ui=AQUI / "ui",
        caminho_log=pasta / "chasame.log",
        editor_contatos=EditorContatos(pasta / "contatos.txt", analisar),
        editor_permitidos=EditorPermitidos(pasta / "permitidos.txt", lambda: ["Gustavo Silva", "Maria Souza"]),
        injetar_comando=lambda t: threading.Thread(target=simular_comando, args=(t,), daemon=True).start(),
        executar_acao=executar_acao,
        abrir_arquivo=lambda chave: print(f"[dev] abrir {chave}") or True,
    )
    servidor = ServidorPainel(contexto, hub)
    servidor.iniciar()
    url = descoberta.url_painel(servidor.dados_descoberta())
    print(f"Painel de demonstracao: {url}")
    if not opcoes.sem_navegador:
        webbrowser.open(url)

    def demo() -> None:
        """Ciclo: ouvindo -> voz (nivel variando) -> processando -> falando."""
        frases = ["abrir discord", "abrir call", "pausar musica", "abrir spotify"]
        while True:
            for _ in range(60):                       # ~6 s ouvindo, com ruido de fundo baixo
                hub.nivel(0.04 + 0.03 * random.random(), False)
                time.sleep(0.1)
            hub.definir_estado(atividade="voz")
            inicio = time.monotonic()
            while time.monotonic() - inicio < 1.6:    # fala do usuario
                hub.nivel(0.35 + 0.5 * abs(math.sin((time.monotonic() - inicio) * 9)) * random.random(), True)
                time.sleep(0.05)
            hub.definir_estado(atividade="nenhuma")
            simular_comando(random.choice(frases), "voz")

    if opcoes.demo:
        threading.Thread(target=demo, daemon=True).start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        servidor.encerrar()


if __name__ == "__main__":
    principal()
