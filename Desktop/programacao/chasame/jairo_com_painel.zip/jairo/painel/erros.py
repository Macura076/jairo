"""Erros de dominio do painel. O servidor os converte em codigos HTTP."""

from __future__ import annotations


class ErroPainel(Exception):
    """Base dos erros do painel."""


class ConflitoVersao(ErroPainel):
    """O arquivo mudou no disco desde a leitura (ETag diferente): HTTP 409."""

    def __init__(
        self,
        mensagem: str = "O arquivo foi alterado fora do painel. Recarregue antes de salvar.",
    ) -> None:
        super().__init__(mensagem)


class ErroValidacao(ErroPainel):
    """Dados recusados: HTTP 422. erros: [{indice, linha, campo, mensagem}]."""

    def __init__(self, erros: list[dict], conflitos: list[dict] | None = None) -> None:
        self.erros = erros
        self.conflitos = conflitos or []
        resumo = "; ".join(str(e.get("mensagem", "")) for e in erros)
        super().__init__(resumo or "Dados inválidos.")


class ErroArquivo(ErroPainel):
    """Arquivo ilegivel (por exemplo, fora de UTF-8)."""


class ErroEscrita(ErroPainel):
    """Falha ao gravar (arquivo em uso, sem permissao...)."""
