"""
Aplicativos instalados (Get-StartApps) para o seletor de comandos.

O PowerShell roda sem shell=True, sem janela e com saida forcada em UTF-8. O
resultado fica em cache (padrao 10 min); chamadas simultaneas esperam a mesma
execucao em vez de abrir varios PowerShell.
"""

from __future__ import annotations

import json
import subprocess
import threading
import time
from typing import Callable

_PS_COMANDO = (
    "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;"
    "Get-StartApps | Select-Object Name,AppID | ConvertTo-Json -Compress"
)


class ErroApps(RuntimeError):
    """Nao foi possivel listar os aplicativos."""


def _executar_powershell() -> str:
    try:
        processo = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", _PS_COMANDO],
            capture_output=True,
            timeout=25,
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except FileNotFoundError as exc:
        raise ErroApps("PowerShell não encontrado.") from exc
    except subprocess.TimeoutExpired as exc:
        raise ErroApps("Tempo esgotado ao listar os aplicativos.") from exc
    except OSError as exc:
        raise ErroApps(f"Falha ao executar o PowerShell: {exc}") from exc
    if processo.returncode != 0:
        detalhe = processo.stderr.decode("utf-8", errors="replace").strip()[:200]
        raise ErroApps(f"O PowerShell retornou erro: {detalhe}")
    return processo.stdout.decode("utf-8-sig", errors="replace")


def interpretar_apps(texto: str) -> list[dict]:
    """JSON do Get-StartApps -> [{nome, id}] sem duplicatas de AppID, em ordem alfabetica."""
    texto = texto.strip().lstrip("\ufeff")
    if not texto:
        return []
    try:
        dados = json.loads(texto)
    except ValueError as exc:
        raise ErroApps("Resposta inesperada do PowerShell.") from exc
    if isinstance(dados, dict):         # um unico app: o PowerShell nao devolve lista
        dados = [dados]
    if not isinstance(dados, list):
        raise ErroApps("Resposta inesperada do PowerShell.")

    vistos: set = set()
    apps = []
    for item in dados:
        if not isinstance(item, dict):
            continue
        nome, ident = item.get("Name"), item.get("AppID")
        if not isinstance(nome, str) or not isinstance(ident, str):
            continue
        nome, ident = nome.strip(), ident.strip()
        if not nome or not ident or ident in vistos:
            continue
        if any(ord(c) < 32 for c in nome + ident):
            continue
        vistos.add(ident)
        apps.append({"nome": nome, "id": ident})
    apps.sort(key=lambda a: a["nome"].casefold())
    return apps


class ListaApps:
    def __init__(
        self,
        executor: "Callable[[], str] | None" = None,
        ttl: float = 600.0,
        relogio: Callable[[], float] = time.monotonic,
    ) -> None:
        self._executor = executor or _executar_powershell
        self._ttl = ttl
        self._relogio = relogio
        self._lock = threading.Lock()
        self._apps: "list | None" = None
        self._quando = 0.0
        self._gerado_em = 0.0

    def obter(self, atualizar: bool = False) -> dict:
        with self._lock:
            valido = self._apps is not None and (self._relogio() - self._quando) < self._ttl
            if atualizar or not valido:
                apps = interpretar_apps(self._executor())   # erro mantem o cache anterior
                self._apps, self._quando, self._gerado_em = apps, self._relogio(), time.time()
            return {"apps": list(self._apps), "gerado_em": int(self._gerado_em)}
