"""
Descoberta de um Chasame em execucao (usada por `jairo.py --painel` e pela bandeja).

O Chasame grava %LOCALAPPDATA%\\Chasame\\painel.json (pid, porta, token) ao subir o
servidor e apaga ao sair. Fica fora de JAIRO_DIR de proposito: aquela pasta pode estar
em git ou nuvem e o arquivo contem o token. Um arquivo velho (apos crash) e detectado
por sondagem HTTP, nao pelo pid.
"""

from __future__ import annotations

import http.client
import json
import os
import tempfile
from pathlib import Path

from .arquivos import escrita_atomica

NOME_ARQUIVO = "painel.json"


def pasta_estado(ambiente: "dict | None" = None) -> Path:
    ambiente = os.environ if ambiente is None else ambiente
    base = ambiente.get("LOCALAPPDATA") or tempfile.gettempdir()
    return Path(base) / "Chasame"


def caminho_descoberta(pasta: "Path | None" = None) -> Path:
    return Path(pasta) / NOME_ARQUIVO if pasta else pasta_estado() / NOME_ARQUIVO


def gravar(dados: dict, pasta: "Path | None" = None) -> Path:
    caminho = caminho_descoberta(pasta)
    escrita_atomica(caminho, json.dumps(dados).encode("utf-8"), backup=False)
    return caminho


def ler(pasta: "Path | None" = None) -> "dict | None":
    try:
        dados = json.loads(caminho_descoberta(pasta).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(dados, dict) or not {"porta", "token"} <= set(dados):
        return None
    return dados


def remover(pid: "int | None" = None, pasta: "Path | None" = None) -> None:
    """Apaga o arquivo; com pid, so se pertencer a esse processo."""
    dados = ler(pasta)
    if pid is not None and (dados is None or dados.get("pid") != pid):
        return
    try:
        caminho_descoberta(pasta).unlink()
    except OSError:
        pass


def url_painel(dados: dict) -> str:
    """URL com o token no fragmento (o fragmento nunca vai ao servidor nem a logs)."""
    return f"http://127.0.0.1:{int(dados['porta'])}/#t={dados['token']}"


def sondar(dados: dict, timeout: float = 1.5) -> bool:
    try:
        conexao = http.client.HTTPConnection("127.0.0.1", int(dados["porta"]), timeout=timeout)
        try:
            conexao.request("GET", "/api/estado", headers={"X-Chasame-Token": str(dados["token"])})
            resposta = conexao.getresponse()
            corpo = json.loads(resposta.read().decode("utf-8"))
            return resposta.status == 200 and isinstance(corpo, dict) and "nome" in corpo
        finally:
            conexao.close()
    except (OSError, ValueError, http.client.HTTPException):
        return False


def localizar(pasta: "Path | None" = None, timeout: float = 1.5) -> "dict | None":
    """Dados de um Chasame vivo, ou None."""
    dados = ler(pasta)
    return dados if dados is not None and sondar(dados, timeout) else None
