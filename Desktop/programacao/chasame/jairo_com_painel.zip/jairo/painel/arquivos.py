"""
Leitura e escrita segura dos arquivos editados pelo painel.

- escrita_atomica: arquivo temporario na mesma pasta + os.replace, com .bak.
- EditorContatos / EditorPermitidos: tabela <-> arquivo de texto, preservando
  comentarios, linhas em branco, quebras de linha e linhas que o usuario nao tocou.

A validacao dos contatos usa um analisador injetado (o parser da Agenda do
jairo.py), para que o painel e o Chasame apliquem exatamente as mesmas regras.
O painel nunca importa o jairo.py.
"""

from __future__ import annotations

import hashlib
import os
import re
import shutil
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

from .erros import ConflitoVersao, ErroArquivo, ErroEscrita, ErroValidacao

# Mesmos separadores de linha de str.splitlines(), que o Chasame usa ao ler.
_FINS_LINHA = "\r\n\x0b\x0c\x1c\x1d\x1e\x85\u2028\u2029"
_PHONE_RE = re.compile(r"^[1-9]\d{9,14}$")

# Analisador: texto -> [(numero_da_linha_1_based, mensagem), ...] com TODOS os erros.
Analisador = Callable[[str], "list[tuple[int, str]]"]


def normalizar_nome(nome: str) -> str:
    """Mesma normalizacao do Chasame para nomes: NFKC, casefold, espacos colapsados."""
    nome = unicodedata.normalize("NFKC", nome)
    return " ".join(nome.strip().casefold().split())


# ----------------------------------------------------------------------
#  Arquivos
# ----------------------------------------------------------------------

def etag_bytes(dados: bytes) -> str:
    return '"' + hashlib.sha256(dados).hexdigest()[:20] + '"'


def ler_bytes(caminho: Path) -> bytes:
    try:
        return Path(caminho).read_bytes()
    except FileNotFoundError:
        return b""


def etag_arquivo(caminho: Path) -> str:
    return etag_bytes(ler_bytes(caminho))


def escrita_atomica(
    caminho: Path,
    dados: bytes,
    backup: bool = True,
    tentativas: int = 3,
    pausa: float = 0.1,
) -> bool:
    """
    Grava dados em caminho de forma atomica. Retorna False (sem tocar em nada) se o
    conteudo ja e identico. O .bak guarda a versao anterior e so e criado quando o
    conteudo muda. Se o arquivo estiver travado por outro programa, tenta de novo
    e, por fim, levanta ErroEscrita deixando o original intacto.
    """
    caminho = Path(caminho)
    try:
        atual = caminho.read_bytes()
    except FileNotFoundError:
        atual = None
    if atual == dados:
        return False

    caminho.parent.mkdir(parents=True, exist_ok=True)
    temporario = caminho.with_name(f".{caminho.name}.{os.getpid()}.tmp")
    try:
        with open(temporario, "wb") as arquivo:
            arquivo.write(dados)
            arquivo.flush()
            os.fsync(arquivo.fileno())
        if backup and atual is not None:
            shutil.copyfile(caminho, caminho.with_name(caminho.name + ".bak"))
        ultimo: Exception | None = None
        for _ in range(max(1, tentativas)):
            try:
                os.replace(temporario, caminho)
                return True
            except PermissionError as exc:
                ultimo = exc
                time.sleep(pausa)
        raise ErroEscrita(
            f"Não foi possível gravar {caminho.name}: o arquivo está em uso por outro programa."
        ) from ultimo
    except ErroEscrita:
        raise
    except OSError as exc:
        raise ErroEscrita(f"Não foi possível gravar {caminho.name}: {exc}") from exc
    finally:
        try:
            temporario.unlink()
        except OSError:
            pass


# ----------------------------------------------------------------------
#  Modelo de linhas
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class LinhaContato:
    nome: str
    numero: str
    apelidos: tuple
    ativo: bool


@dataclass
class _Linha:
    corpo: str
    eol: str
    tipo: str          # 'outro' | 'contato' | 'invalida' | 'nome'
    valor: object = None


def _eol_padrao(texto: str) -> str:
    if "\r\n" in texto:
        return "\r\n"
    if "\n" in texto:
        return "\n"
    return "\r\n" if os.name == "nt" else "\n"


def _dividir(texto: str, classificar: Callable[[str], "tuple[str, object]"]) -> list[_Linha]:
    linhas = []
    for bruto in texto.splitlines(keepends=True):
        corpo = bruto.rstrip(_FINS_LINHA)
        tipo, valor = classificar(corpo)
        linhas.append(_Linha(corpo, bruto[len(corpo):], tipo, valor))
    return linhas


def _decodificar(dados: bytes) -> str:
    try:
        return dados.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ErroArquivo("O arquivo não está em UTF-8.") from exc


def _tem_separador(texto: str) -> bool:
    return any(c in _FINS_LINHA for c in texto)


def _erro(indice, campo, mensagem, linha=None) -> dict:
    return {"indice": indice, "linha": linha, "campo": campo, "mensagem": mensagem}


# ----------------------------------------------------------------------
#  contatos.txt
# ----------------------------------------------------------------------

def _classificar_contato(corpo: str):
    linha = corpo.strip()
    if not linha or linha.startswith("#"):
        return "outro", None
    ativo = not linha.startswith("!")
    if not ativo:
        linha = linha[1:].strip()
    partes = [p.strip() for p in linha.split(":")]
    if len(partes) not in (2, 3) or not partes[0]:
        return "invalida", None
    apelidos: tuple = ()
    if len(partes) == 3:
        apelidos = tuple(a for a in (x.strip() for x in partes[2].split(",")) if a)
    return "contato", LinhaContato(partes[0], partes[1], apelidos, ativo)


def _formatar_contato(c: LinhaContato) -> str:
    base = f"{c.nome}:{c.numero}"
    if c.apelidos:
        base += ":" + ",".join(c.apelidos)
    return ("" if c.ativo else "!") + base


def _converter_contato(k: int, item: dict):
    """Valida os campos de uma linha da tabela. Retorna (LinhaContato | None, erros)."""
    erros: list[dict] = []
    nome = item.get("nome")
    numero = item.get("numero")
    apelidos = item.get("apelidos", [])
    ativo = item.get("ativo", True)

    if not isinstance(nome, str) or not nome.strip():
        erros.append(_erro(k, "nome", "Informe o nome."))
    else:
        nome = nome.strip()
        if len(nome) > 80:
            erros.append(_erro(k, "nome", "Nome com mais de 80 caracteres."))
        if ":" in nome or _tem_separador(nome):
            erros.append(_erro(k, "nome", "O nome não pode conter dois-pontos nem quebra de linha."))
        if nome[:1] in ("!", "#"):
            erros.append(_erro(k, "nome", "O nome não pode começar com ! ou #."))

    if not isinstance(numero, str) or not _PHONE_RE.fullmatch(numero.strip()):
        erros.append(_erro(
            k, "numero",
            "Número inválido: use DDI+DDD+número, só dígitos (ex.: 5511999998888).",
        ))
    else:
        numero = numero.strip()

    lista: list[str] = []
    if not isinstance(apelidos, list):
        erros.append(_erro(k, "apelidos", "Apelidos devem ser uma lista."))
    else:
        for apelido in apelidos:
            if not isinstance(apelido, str):
                erros.append(_erro(k, "apelidos", "Apelido inválido."))
                continue
            apelido = apelido.strip()
            if not apelido:
                continue
            if ":" in apelido or "," in apelido or _tem_separador(apelido):
                erros.append(_erro(
                    k, "apelidos", "Apelido não pode conter vírgula, dois-pontos ou quebra de linha."
                ))
            elif len(apelido) > 60:
                erros.append(_erro(k, "apelidos", "Apelido com mais de 60 caracteres."))
            else:
                lista.append(apelido)

    if not isinstance(ativo, bool):
        erros.append(_erro(k, "ativo", "O campo ativo deve ser verdadeiro ou falso."))

    if erros:
        return None, erros
    return LinhaContato(nome, numero, tuple(lista), ativo), []


class EditorContatos:
    """Tabela de contatos <-> contatos.txt. Ids sao os indices (0-based) das linhas."""

    def __init__(self, caminho: Path, analisador: Analisador) -> None:
        self._caminho = Path(caminho)
        self._analisador = analisador

    def _carregar(self):
        dados = ler_bytes(self._caminho)
        texto = _decodificar(dados)
        return dados, texto, _dividir(texto, _classificar_contato)

    def ler(self) -> dict:
        dados, texto, linhas = self._carregar()
        contatos = []
        for i, linha in enumerate(linhas):
            if linha.tipo == "contato":
                c: LinhaContato = linha.valor
                contatos.append({
                    "id": i, "nome": c.nome, "numero": c.numero,
                    "apelidos": list(c.apelidos), "ativo": c.ativo,
                })
            elif linha.tipo == "invalida":
                contatos.append({
                    "id": i, "invalida": True, "bruto": linha.corpo.strip(),
                    "nome": "", "numero": "", "apelidos": [], "ativo": True,
                })
        erros = [{"linha": n, "mensagem": m} for n, m in self._analisador(texto)]
        return {"etag": etag_bytes(dados), "contatos": contatos, "erros": erros}

    def montar_texto(self, contatos: list) -> str:
        """Texto resultante de aplicar a tabela ao arquivo atual (sem gravar)."""
        _, texto, linhas = self._carregar()
        return self._montar(texto, linhas, contatos)[0]

    def salvar(self, contatos: list, etag_esperada: str) -> dict:
        dados, texto, linhas = self._carregar()
        if etag_esperada != etag_bytes(dados):
            raise ConflitoVersao()
        novo, mapa = self._montar(texto, linhas, contatos)
        problemas = self._analisador(novo)
        if problemas:
            raise ErroValidacao([
                _erro(mapa.get(n), None, m, linha=n) for n, m in problemas
            ])
        return {"alterado": escrita_atomica(self._caminho, novo.encode("utf-8"))}

    def _montar(self, texto: str, linhas: list, enviados) -> "tuple[str, dict]":
        if not isinstance(enviados, list):
            raise ErroValidacao([_erro(None, None, "Lista de contatos inválida.")])

        existentes = {i for i, l in enumerate(linhas) if l.tipo in ("contato", "invalida")}
        erros: list[dict] = []
        convertidos: list = []      # (id | None, LinhaContato | None)  None = manter a linha como esta
        usados: set = set()
        for k, item in enumerate(enviados):
            if not isinstance(item, dict):
                erros.append(_erro(k, None, "Linha inválida."))
                continue
            ident = item.get("id")
            if ident is not None:
                if (
                    not isinstance(ident, int) or isinstance(ident, bool)
                    or ident not in existentes or ident in usados
                ):
                    erros.append(_erro(
                        k, "id", "Linha inexistente ou repetida. Recarregue a lista."
                    ))
                    continue
                usados.add(ident)
                if item.get("invalida") is True:
                    convertidos.append((ident, None))
                    continue
            contato, problemas = _converter_contato(k, item)
            erros.extend(problemas)
            convertidos.append((ident, contato, k))
        if erros:
            raise ErroValidacao(erros)

        por_id: dict = {}
        novos: list = []
        for k, entrada in enumerate(convertidos):
            ident = entrada[0]
            contato = entrada[1]
            indice = entrada[2] if len(entrada) > 2 else k
            if ident is None:
                novos.append((indice, contato))
            else:
                por_id[ident] = (indice, contato)

        eol = _eol_padrao(texto)
        saida: list = []            # [corpo, eol, indice_submetido | None]
        ultimo = -1
        for i, linha in enumerate(linhas):
            if linha.tipo == "outro":
                saida.append([linha.corpo, linha.eol, None])
                continue
            if i not in por_id:
                continue            # removida pelo usuario
            indice, contato = por_id[i]
            if contato is None or (linha.tipo == "contato" and linha.valor == contato):
                saida.append([linha.corpo, linha.eol, indice])
            else:
                saida.append([_formatar_contato(contato), linha.eol or eol, indice])
            ultimo = len(saida) - 1

        if novos:
            pos = ultimo if ultimo >= 0 else len(saida) - 1
            if pos >= 0 and not saida[pos][1]:
                saida[pos][1] = eol
            ponto = pos + 1
            for indice, contato in novos:
                saida.insert(ponto, [_formatar_contato(contato), eol, indice])
                ponto += 1

        mapa = {n + 1: s[2] for n, s in enumerate(saida) if s[2] is not None}
        return "".join(s[0] + s[1] for s in saida), mapa


# ----------------------------------------------------------------------
#  permitidos.txt
# ----------------------------------------------------------------------

def _classificar_permitido(corpo: str):
    # Mesma regra do Chasame: nao vazia e sem '#' na coluna 0.
    if corpo.strip() and not corpo.startswith("#"):
        return "nome", corpo.strip()
    return "outro", None


class EditorPermitidos:
    """Lista de nomes do auto-responder <-> permitidos.txt."""

    def __init__(self, caminho: Path, nomes_agenda: Callable[[], Iterable[str]]) -> None:
        self._caminho = Path(caminho)
        self._nomes_agenda = nomes_agenda

    def _carregar(self):
        dados = ler_bytes(self._caminho)
        texto = _decodificar(dados)
        return dados, texto, _dividir(texto, _classificar_permitido)

    def ler(self) -> dict:
        dados, _, linhas = self._carregar()
        nomes = [
            {"id": i, "nome": l.valor} for i, l in enumerate(linhas) if l.tipo == "nome"
        ]
        avisos, sugestoes = self._avaliar(nomes)
        return {"etag": etag_bytes(dados), "nomes": nomes, "avisos": avisos, "sugestoes": sugestoes}

    def _avaliar(self, nomes: list) -> "tuple[list, list]":
        agenda = list(self._nomes_agenda())
        chaves_agenda = {normalizar_nome(n) for n in agenda}
        vistos: set = set()
        avisos = []
        for item in nomes:
            chave = normalizar_nome(item["nome"])
            if chave in vistos:
                avisos.append({"id": item.get("id"), "tipo": "duplicado",
                               "mensagem": "Nome repetido na lista."})
            vistos.add(chave)
            if chave not in chaves_agenda:
                avisos.append({
                    "id": item.get("id"), "tipo": "fora_da_agenda",
                    "mensagem": "Não está na agenda. Tudo bem se for exatamente o título "
                                "da conversa no WhatsApp.",
                })
        sugestoes = sorted(
            {n for n in agenda if normalizar_nome(n) not in vistos}, key=normalizar_nome
        )
        return avisos, sugestoes

    def salvar(self, nomes: list, etag_esperada: str) -> dict:
        dados, texto, linhas = self._carregar()
        if etag_esperada != etag_bytes(dados):
            raise ConflitoVersao()
        novo = self._montar(texto, linhas, nomes)
        return {"alterado": escrita_atomica(self._caminho, novo.encode("utf-8"))}

    def _montar(self, texto: str, linhas: list, enviados) -> str:
        if not isinstance(enviados, list):
            raise ErroValidacao([_erro(None, None, "Lista de nomes inválida.")])
        existentes = {i for i, l in enumerate(linhas) if l.tipo == "nome"}
        erros: list[dict] = []
        por_id: dict = {}
        novos: list = []
        for k, item in enumerate(enviados):
            if not isinstance(item, dict):
                erros.append(_erro(k, None, "Linha inválida."))
                continue
            nome = item.get("nome")
            if not isinstance(nome, str) or not nome.strip():
                erros.append(_erro(k, "nome", "Informe o nome."))
                continue
            nome = nome.strip()
            if len(nome) > 100:
                erros.append(_erro(k, "nome", "Nome com mais de 100 caracteres."))
            elif _tem_separador(nome):
                erros.append(_erro(k, "nome", "O nome não pode conter quebra de linha."))
            elif nome.startswith("#"):
                erros.append(_erro(k, "nome", "O nome não pode começar com #."))
            ident = item.get("id")
            if ident is None:
                novos.append(nome)
            elif (
                not isinstance(ident, int) or isinstance(ident, bool)
                or ident not in existentes or ident in por_id
            ):
                erros.append(_erro(k, "id", "Linha inexistente ou repetida. Recarregue a lista."))
            else:
                por_id[ident] = nome
        if erros:
            raise ErroValidacao(erros)

        eol = _eol_padrao(texto)
        saida: list = []
        for i, linha in enumerate(linhas):
            if linha.tipo == "outro":
                saida.append([linha.corpo, linha.eol])
            elif i in por_id:
                nome = por_id[i]
                saida.append([linha.corpo if nome == linha.valor else nome, linha.eol or eol])
                if not linha.eol and nome == linha.valor:
                    saida[-1][1] = ""
        if novos:
            if saida and not saida[-1][1]:
                saida[-1][1] = eol
            for nome in novos:
                saida.append([nome, eol])
        return "".join(c + e for c, e in saida)
