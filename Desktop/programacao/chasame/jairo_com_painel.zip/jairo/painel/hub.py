"""
Hub de eventos do painel.

Regras de projeto:
- Sem assinantes (UI fechada), publicar() e um unico teste de booleano e retorna:
  nenhum calculo, nenhuma alocacao.
- Quem publica (a thread principal do Chasame, a de captura...) nunca bloqueia: o
  evento entra numa fila limitada por assinante; a thread da conexao e quem escreve
  no socket.
- Fila cheia: descarta primeiro os eventos de 'nivel' (efemeros); se ainda assim nao
  couber, o assinante e desconectado.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import deque
from time import monotonic
from typing import Callable

logger = logging.getLogger("jairo.painel")

ESTADO_INICIAL = {
    "modo": "ouvindo",          # ouvindo | standby | ditado
    "silencioso": False,
    "atividade": "nenhuma",     # nenhuma | voz | processando | falando | erro
    "pronto": False,
}


class Assinante:
    """Fila de eventos de um cliente SSE."""

    def __init__(self, capacidade: int = 256) -> None:
        self._itens: deque = deque()
        self._cond = threading.Condition()
        self._capacidade = capacidade
        self.fechado = False

    def colocar(self, evento: dict) -> bool:
        """False se o assinante esta fechado (ou foi fechado por estouro de fila)."""
        with self._cond:
            if self.fechado:
                return False
            if len(self._itens) >= self._capacidade:
                self._itens = deque(e for e in self._itens if e["tipo"] != "nivel")
                if len(self._itens) >= self._capacidade:
                    self._fechar_sem_lock()
                    return False
            elif evento["tipo"] == "nivel" and len(self._itens) >= self._capacidade * 3 // 4:
                return True         # fila quase cheia: o nivel novo e descartado
            self._itens.append(evento)
            self._cond.notify()
            return True

    def obter(self, timeout: float) -> "dict | None":
        """Proximo evento, ou None por timeout / assinante fechado."""
        with self._cond:
            if not self._itens and not self.fechado:
                self._cond.wait(timeout)
            if self._itens:
                return self._itens.popleft()
            return None

    def _fechar_sem_lock(self) -> None:
        self.fechado = True
        self._itens.clear()
        self._cond.notify_all()

    def fechar(self) -> None:
        with self._cond:
            self._fechar_sem_lock()


class Hub:
    def __init__(
        self,
        max_clientes: int = 4,
        capacidade_fila: int = 256,
        intervalo_nivel: float = 0.05,
        tamanho_historico: int = 20,
    ) -> None:
        self._lock = threading.Lock()
        self._assinantes: list = []
        self._max = max_clientes
        self._capacidade = capacidade_fila
        self._intervalo_nivel = intervalo_nivel
        self._ultimo_nivel = 0.0
        self._seq = 0
        self._estado = dict(ESTADO_INICIAL)
        self._historico: deque = deque(maxlen=tamanho_historico)
        self._callbacks: list = []
        self.ativo = False          # lido sem lock nos caminhos quentes

    # --- ciclo de vida dos assinantes ---

    def ao_mudar_ativo(self, callback: Callable[[bool], None]) -> None:
        """callback(True) quando chega o primeiro cliente; callback(False) quando sai o ultimo."""
        self._callbacks.append(callback)

    def _notificar_ativo(self, ativo: bool) -> None:
        for callback in list(self._callbacks):
            try:
                callback(ativo)
            except Exception:
                logger.debug("Falha em callback do hub.", exc_info=True)

    def assinar(self) -> "Assinante | None":
        with self._lock:
            if len(self._assinantes) >= self._max:
                return None
            assinante = Assinante(self._capacidade)
            self._assinantes.append(assinante)
            primeiro = len(self._assinantes) == 1
            if primeiro:
                self.ativo = True
        if primeiro:
            self._notificar_ativo(True)
        return assinante

    def remover(self, assinante: Assinante) -> None:
        assinante.fechar()
        ultimo = False
        with self._lock:
            if assinante in self._assinantes:
                self._assinantes.remove(assinante)
                if not self._assinantes:
                    self.ativo = False
                    ultimo = True
        if ultimo:
            self._notificar_ativo(False)

    def fechar_todos(self) -> None:
        with self._lock:
            assinantes = list(self._assinantes)
        for assinante in assinantes:
            self.remover(assinante)

    @property
    def clientes(self) -> int:
        with self._lock:
            return len(self._assinantes)

    # --- publicacao ---

    def publicar(self, tipo: str, dados: "dict | None" = None) -> None:
        if not self.ativo:
            return
        self._difundir(tipo, dados if dados is not None else {})

    def _difundir(self, tipo: str, dados: dict) -> None:
        with self._lock:
            self._seq += 1
            evento = {"id": self._seq, "tipo": tipo, "dados": dados}
            assinantes = list(self._assinantes)
        for assinante in assinantes:
            if not assinante.colocar(evento):
                self.remover(assinante)

    def nivel(self, valor: float, voz: bool = False) -> None:
        """Nivel do microfone (0 a 1), limitado a ~20 eventos por segundo."""
        if not self.ativo:
            return
        agora = monotonic()
        if agora - self._ultimo_nivel < self._intervalo_nivel:
            return
        self._ultimo_nivel = agora
        self._difundir("nivel", {"v": round(max(0.0, min(1.0, valor)), 3), "voz": bool(voz)})

    # --- estado e historico (sempre mantidos: custo desprezivel) ---

    def definir_estado(self, **campos) -> None:
        with self._lock:
            if all(self._estado.get(k) == v for k, v in campos.items()):
                return
            self._estado.update(campos)
            instantaneo = dict(self._estado)
        if self.ativo:
            self._difundir("estado", instantaneo)

    def registrar_comando(self, texto: str, resultado: str, origem: str = "voz") -> None:
        item = {"t": int(time.time() * 1000), "texto": texto,
                "resultado": resultado, "origem": origem}
        with self._lock:
            self._historico.append(item)
        if self.ativo:
            self._difundir("comando", {"texto": texto, "resultado": resultado, "origem": origem})

    def estado(self) -> dict:
        with self._lock:
            return dict(self._estado)

    def instantaneo(self) -> dict:
        with self._lock:
            return {**self._estado, "historico": list(self._historico)}
