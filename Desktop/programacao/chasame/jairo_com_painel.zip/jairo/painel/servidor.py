"""
Servidor HTTP local do painel (somente biblioteca padrao).

Seguranca:
- escuta so em 127.0.0.1, em porta livre, sem SO_REUSEADDR (no Windows permitiria
  outro processo ocupar a mesma porta);
- token aleatorio por execucao no cabecalho X-Chasame-Token (hmac.compare_digest);
- Host e Origin validados em TODAS as requisicoes (anti DNS rebinding); sem CORS;
- corpo JSON limitado a 1 MB, Content-Type obrigatorio, CSP sem inline;
- arquivos estaticos so de dentro da pasta ui/; abrir_arquivo so por identificador fixo.

A thread principal do Chasame nunca faz I/O de rede: ela publica no Hub e a thread de
cada conexao SSE e quem escreve no socket.
"""

from __future__ import annotations

import hmac
import json
import logging
import mimetypes
import os
import secrets
import socket
import threading
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable
from urllib.parse import parse_qs, unquote

from .apps import ErroApps, ListaApps
from .arquivos import EditorContatos, EditorPermitidos
from .erros import ConflitoVersao, ErroArquivo, ErroEscrita, ErroValidacao
from .hub import Hub
from .logs import ler_cauda

logger = logging.getLogger("jairo.painel")

LIMITE_CORPO = 1_048_576
ARQUIVOS_PERMITIDOS = ("log", "contatos", "permitidos", "pasta")
ACOES = ("standby", "silencioso", "recarregar", "testar")

_CSP = (
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
    "connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; "
    "form-action 'none'; frame-ancestors 'none'"
)
_TIPOS = {
    ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml",
    ".png": "image/png", ".ico": "image/x-icon", ".woff2": "font/woff2",
    ".txt": "text/plain; charset=utf-8",
}


@dataclass
class Contexto:
    """Tudo o que o painel precisa do Chasame, injetado (o painel nunca importa o jairo.py)."""

    nome: str = "Chasame"
    versao: str = ""
    dir_ui: "Path | None" = None
    caminho_log: "Path | None" = None
    editor_contatos: "EditorContatos | None" = None
    editor_permitidos: "EditorPermitidos | None" = None
    comandos: object = None     # ler() / gravar(documento, etag, confirmar_conflitos) / verificar(frase, id)
    lista_apps: "ListaApps | None" = None
    explicar_nome: "Callable[[str, str | None], dict] | None" = None
    ao_salvar_contatos: "Callable[[], None] | None" = None
    ao_salvar_permitidos: "Callable[[], None] | None" = None
    injetar_comando: "Callable[[str], None] | None" = None
    executar_acao: "Callable[[str, dict], dict] | None" = None
    abrir_arquivo: "Callable[[str], bool] | None" = None


class _Http(Exception):
    def __init__(self, status: int, mensagem: str, extra: "dict | None" = None) -> None:
        super().__init__(mensagem)
        self.status = status
        self.mensagem = mensagem
        self.extra = extra or {}


class _Servidor(ThreadingHTTPServer):
    allow_reuse_address = False
    daemon_threads = True

    def handle_error(self, request, client_address) -> None:  # noqa: D401
        logger.debug("Erro de conexao com %s", client_address, exc_info=True)


class _Handler(BaseHTTPRequestHandler):
    servidor: "ServidorPainel"      # definido na subclasse criada por ServidorPainel
    timeout = 20
    server_version = "ChasamePainel"
    sys_version = ""

    def log_message(self, formato, *args) -> None:
        logger.debug("HTTP %s", formato % args)

    # ------------------------------------------------------------------
    #  Entrada
    # ------------------------------------------------------------------

    def do_GET(self) -> None:
        self._despachar("GET")

    def do_PUT(self) -> None:
        self._despachar("PUT")

    def do_POST(self) -> None:
        self._despachar("POST")

    def do_DELETE(self) -> None:
        self._json(405, {"erro": "Método não permitido."})

    do_HEAD = do_OPTIONS = do_PATCH = do_DELETE

    def _despachar(self, metodo: str) -> None:
        try:
            if not self._host_origem_ok():
                raise _Http(403, "Host ou Origin não permitido.")
            caminho, _, consulta = self.path.partition("?")
            if caminho == "/events" and metodo == "GET":
                self._eventos()
            elif caminho.startswith("/api/"):
                if not self._token_ok():
                    raise _Http(401, "Token ausente ou inválido.")
                self._api(metodo, caminho, parse_qs(consulta))
            elif metodo == "GET":
                self._estatico(caminho)
            else:
                raise _Http(405, "Método não permitido.")
        except _Http as exc:
            self._json(exc.status, {"erro": exc.mensagem, **exc.extra})
        except ConflitoVersao as exc:
            self._json(409, {"erro": str(exc)})
        except ErroValidacao as exc:
            self._json(422, {"erro": str(exc), "erros": exc.erros, "conflitos": exc.conflitos})
        except (ErroArquivo, ErroEscrita, ErroApps) as exc:
            self._json(500, {"erro": str(exc)})
        except (BrokenPipeError, ConnectionError, socket.timeout):
            pass
        except Exception:
            logger.exception("Erro interno ao tratar %s %s", metodo, self.path)
            try:
                self._json(500, {"erro": "Erro interno."})
            except OSError:
                pass

    # ------------------------------------------------------------------
    #  Autenticacao
    # ------------------------------------------------------------------

    def _host_origem_ok(self) -> bool:
        porta = self.servidor.porta
        host = (self.headers.get("Host") or "").lower()
        if host not in (f"127.0.0.1:{porta}", f"localhost:{porta}"):
            return False
        origem = self.headers.get("Origin")
        if origem is not None and origem.lower() not in (
            f"http://127.0.0.1:{porta}", f"http://localhost:{porta}"
        ):
            return False
        return True

    def _token_ok(self) -> bool:
        enviado = (self.headers.get("X-Chasame-Token") or "").encode("utf-8")
        return hmac.compare_digest(enviado, self.servidor.token.encode("utf-8"))

    # ------------------------------------------------------------------
    #  Respostas
    # ------------------------------------------------------------------

    def _cabecalhos_comuns(self) -> None:
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", _CSP)

    def _json(self, status: int, dados: object) -> None:
        corpo = json.dumps(dados, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._cabecalhos_comuns()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)

    def _ler_json(self) -> dict:
        tipo = (self.headers.get("Content-Type") or "").lower()
        if not tipo.startswith("application/json"):
            raise _Http(415, "Use Content-Type: application/json.")
        try:
            tamanho = int(self.headers.get("Content-Length", ""))
        except ValueError:
            raise _Http(411, "Content-Length obrigatório.") from None
        if tamanho < 0 or tamanho > LIMITE_CORPO:
            raise _Http(413, "Corpo grande demais.")
        bruto = self.rfile.read(tamanho)
        try:
            corpo = json.loads(bruto.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            raise _Http(400, "JSON inválido.") from None
        if not isinstance(corpo, dict):
            raise _Http(400, "O corpo deve ser um objeto JSON.")
        return corpo

    def _etag(self, corpo: dict) -> str:
        etag = self.headers.get("If-Match") or corpo.get("etag")
        if not isinstance(etag, str) or not etag:
            raise _Http(428, "Envie If-Match com o etag recebido na leitura.")
        return etag.strip()

    # ------------------------------------------------------------------
    #  Estaticos
    # ------------------------------------------------------------------

    def _estatico(self, caminho: str) -> None:
        raiz_ui = self.servidor.contexto.dir_ui
        if raiz_ui is None:
            raise _Http(404, "Interface indisponível.")
        relativo = unquote(caminho).lstrip("/") or "index.html"
        try:
            raiz = Path(raiz_ui).resolve()
            alvo = (raiz / relativo).resolve()
            dentro = raiz in alvo.parents
            existe = dentro and alvo.is_file()
        except (OSError, ValueError):
            raise _Http(404, "Não encontrado.") from None
        if not existe:
            raise _Http(404, "Não encontrado.")
        dados = alvo.read_bytes()
        tipo = _TIPOS.get(alvo.suffix.lower()) or mimetypes.guess_type(alvo.name)[0] \
            or "application/octet-stream"
        self.send_response(200)
        self._cabecalhos_comuns()
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(dados)))
        self.end_headers()
        self.wfile.write(dados)

    # ------------------------------------------------------------------
    #  SSE
    # ------------------------------------------------------------------

    def _eventos(self) -> None:
        if not self._token_ok():
            raise _Http(401, "Token ausente ou inválido.")
        servidor = self.servidor
        assinante = servidor.hub.assinar()
        if assinante is None:
            raise _Http(503, "Clientes demais conectados.")
        self.close_connection = True
        try:
            self.send_response(200)
            self._cabecalhos_comuns()
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            estado = servidor.hub.estado()
            self._escrever_evento({"id": 0, "tipo": "estado", "dados": estado})
            while not assinante.fechado and not servidor.encerrando:
                evento = assinante.obter(servidor.intervalo_ping)
                if evento is None:
                    if assinante.fechado:
                        break
                    self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
                    continue
                self._escrever_evento(evento)
        except (OSError, ValueError):
            pass                    # cliente saiu
        finally:
            servidor.hub.remover(assinante)

    def _escrever_evento(self, evento: dict) -> None:
        dados = json.dumps(evento["dados"], ensure_ascii=False, separators=(",", ":"))
        self.wfile.write(
            f"id: {evento['id']}\nevent: {evento['tipo']}\ndata: {dados}\n\n".encode("utf-8")
        )
        self.wfile.flush()

    # ------------------------------------------------------------------
    #  API
    # ------------------------------------------------------------------

    def _api(self, metodo: str, caminho: str, consulta: dict) -> None:
        rotas = {
            ("GET", "/api/estado"): self._get_estado,
            ("GET", "/api/log"): self._get_log,
            ("GET", "/api/apps"): self._get_apps,
            ("GET", "/api/comandos"): self._get_comandos,
            ("PUT", "/api/comandos"): self._put_comandos,
            ("POST", "/api/comandos/verificar"): self._post_verificar,
            ("GET", "/api/contatos"): self._get_contatos,
            ("PUT", "/api/contatos"): self._put_contatos,
            ("POST", "/api/contatos/explicar"): self._post_explicar,
            ("GET", "/api/permitidos"): self._get_permitidos,
            ("PUT", "/api/permitidos"): self._put_permitidos,
            ("POST", "/api/comando"): self._post_comando,
            ("POST", "/api/acao"): self._post_acao,
        }
        rota = rotas.get((metodo, caminho))
        if rota is None:
            existe = any(c == caminho for _, c in rotas)
            raise _Http(405 if existe else 404, "Método não permitido." if existe else "Não encontrado.")
        corpo = self._ler_json() if metodo in ("PUT", "POST") else {}
        self._json(200 if rota != self._post_comando else 202, rota(corpo, consulta))

    def _ctx(self, campo: str):
        valor = getattr(self.servidor.contexto, campo)
        if valor is None:
            raise _Http(501, "Recurso indisponível nesta instalação.")
        return valor

    def _get_estado(self, corpo, consulta) -> dict:
        ctx = self.servidor.contexto
        return {"nome": ctx.nome, "versao": ctx.versao, **self.servidor.hub.instantaneo()}

    def _get_log(self, corpo, consulta) -> dict:
        caminho = self._ctx("caminho_log")
        try:
            limite = int(consulta.get("bytes", ["200000"])[0])
        except ValueError:
            limite = 200_000
        return {"linhas": ler_cauda(caminho, max(10_000, min(limite, 1_000_000)))}

    def _get_apps(self, corpo, consulta) -> dict:
        atualizar = consulta.get("atualizar", ["0"])[0] in ("1", "true")
        return self._ctx("lista_apps").obter(atualizar)

    # --- comandos ---

    def _get_comandos(self, corpo, consulta) -> dict:
        return self._ctx("comandos").ler()

    def _put_comandos(self, corpo, consulta) -> dict:
        etag = self._etag(corpo)
        confirmados = corpo.get("confirmar_conflitos", [])
        if not isinstance(confirmados, list) or not isinstance(corpo.get("comandos"), list):
            raise _Http(400, "Formato inválido: envie 'comandos' (lista).")
        documento = {"opcoes": corpo.get("opcoes", {}), "comandos": corpo["comandos"]}
        return self._ctx("comandos").gravar(documento, etag, confirmados)

    def _post_verificar(self, corpo, consulta) -> dict:
        frase = corpo.get("frase")
        if not isinstance(frase, str):
            raise _Http(400, "Informe a frase.")
        return self._ctx("comandos").verificar(frase, corpo.get("id"))

    # --- contatos ---

    def _get_contatos(self, corpo, consulta) -> dict:
        return self._ctx("editor_contatos").ler()

    def _put_contatos(self, corpo, consulta) -> dict:
        editor = self._ctx("editor_contatos")
        etag = self._etag(corpo)
        if not isinstance(corpo.get("contatos"), list):
            raise _Http(400, "Formato inválido: envie 'contatos' (lista).")
        resultado = editor.salvar(corpo["contatos"], etag)
        aviso = None
        gancho = self.servidor.contexto.ao_salvar_contatos
        if resultado["alterado"] and gancho is not None:
            try:
                gancho()
            except Exception as exc:
                logger.exception("Falha ao recarregar a agenda.")
                aviso = f"Salvo, mas a agenda não foi recarregada: {exc}"
        resposta = {**editor.ler(), "alterado": resultado["alterado"]}
        if aviso:
            resposta["aviso"] = aviso
        return resposta

    def _post_explicar(self, corpo, consulta) -> dict:
        nome = corpo.get("nome")
        if not isinstance(nome, str) or not nome.strip():
            raise _Http(400, "Informe o nome.")
        texto = None
        if corpo.get("contatos") is not None:
            texto = self._ctx("editor_contatos").montar_texto(corpo["contatos"])
        return self._ctx("explicar_nome")(nome, texto)

    # --- permitidos ---

    def _get_permitidos(self, corpo, consulta) -> dict:
        return self._ctx("editor_permitidos").ler()

    def _put_permitidos(self, corpo, consulta) -> dict:
        editor = self._ctx("editor_permitidos")
        etag = self._etag(corpo)
        if not isinstance(corpo.get("nomes"), list):
            raise _Http(400, "Formato inválido: envie 'nomes' (lista).")
        resultado = editor.salvar(corpo["nomes"], etag)
        aviso = None
        gancho = self.servidor.contexto.ao_salvar_permitidos
        if resultado["alterado"] and gancho is not None:
            try:
                gancho()
            except Exception as exc:
                logger.exception("Falha ao invalidar o cache de permitidos.")
                aviso = f"Salvo, mas o cache não foi atualizado: {exc}"
        resposta = {**editor.ler(), "alterado": resultado["alterado"]}
        if aviso:
            resposta["aviso"] = aviso
        return resposta

    # --- comando de texto e acoes ---

    def _post_comando(self, corpo, consulta) -> dict:
        texto = corpo.get("texto")
        if not isinstance(texto, str) or not texto.strip():
            raise _Http(400, "Informe o texto do comando.")
        texto = texto.strip()
        if len(texto) > 500:
            raise _Http(400, "Comando com mais de 500 caracteres.")
        self._ctx("injetar_comando")(texto)
        return {"ok": True}

    def _post_acao(self, corpo, consulta) -> dict:
        acao = corpo.get("acao")
        if acao == "abrir_arquivo":
            arquivo = corpo.get("arquivo")
            if arquivo not in ARQUIVOS_PERMITIDOS:
                raise _Http(400, "Arquivo não permitido.")
            return {"ok": bool(self._ctx("abrir_arquivo")(arquivo))}
        if acao not in ACOES:
            raise _Http(400, "Ação desconhecida.")
        try:
            resultado = self._ctx("executar_acao")(acao, corpo)
        except ValueError as exc:
            raise _Http(400, str(exc)) from None
        return {"ok": True, **(resultado or {})}


class ServidorPainel:
    def __init__(
        self,
        contexto: Contexto,
        hub: Hub,
        porta: int = 0,
        intervalo_ping: float = 15.0,
    ) -> None:
        self.contexto = contexto
        self.hub = hub
        self.intervalo_ping = intervalo_ping
        self.token = secrets.token_urlsafe(32)
        self.encerrando = False
        self._thread: "threading.Thread | None" = None
        handler = type("HandlerPainel", (_Handler,), {"servidor": self})
        try:
            self._httpd = _Servidor(("127.0.0.1", porta), handler)
        except OSError:
            if porta == 0:
                raise
            logger.warning("Porta %d indisponivel; usando uma porta livre.", porta)
            self._httpd = _Servidor(("127.0.0.1", 0), handler)
        self.porta: int = self._httpd.server_address[1]

    def iniciar(self) -> None:
        self._thread = threading.Thread(
            target=self._httpd.serve_forever,
            kwargs={"poll_interval": 0.25},
            name="PainelHTTP",
            daemon=True,
        )
        self._thread.start()
        logger.info("Painel em http://127.0.0.1:%d", self.porta)

    def encerrar(self) -> None:
        self.encerrando = True
        self.hub.fechar_todos()
        if self._thread is not None:
            self._httpd.shutdown()
            self._thread.join(timeout=3)
        self._httpd.server_close()

    def dados_descoberta(self) -> dict:
        return {
            "pid": os.getpid(), "porta": self.porta, "token": self.token,
            "nome": self.contexto.nome, "inicio": int(time.time()),
        }
