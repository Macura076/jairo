"""
Logs ao vivo para o painel.

- ler_cauda: ultimos N bytes do log lidos com seek (nunca o arquivo inteiro). Se o
  arquivo atual for pequeno (acabou de rotacionar), completa com o .1.
- LogStream: logging.Handler que empurra cada registro para o hub. So fica anexado
  ao logger enquanto ha cliente conectado (custo zero com a UI fechada).
"""

from __future__ import annotations

import logging
import os
import re
import time
from pathlib import Path
from typing import Iterable

from .hub import Hub

# Formato do jairo.py: "%(asctime)s | %(levelname)-8s | %(threadName)-22s | %(message)s"
_RE_LINHA = re.compile(r"^(\d{2}:\d{2}:\d{2}) \| ([A-Z]+) *\| (.*?) *\| (.*)$")


def interpretar_log(linhas: Iterable[str]) -> list[dict]:
    """Agrupa linhas em registros; linhas sem cabecalho (traceback) viram continuacao."""
    itens: list[dict] = []
    for linha in linhas:
        achado = _RE_LINHA.match(linha)
        if achado:
            itens.append({
                "ts": achado.group(1), "nivel": achado.group(2),
                "thread": achado.group(3), "msg": achado.group(4),
            })
        elif itens:
            itens[-1]["msg"] += "\n" + linha
        elif linha.strip():
            itens.append({"ts": "", "nivel": "", "thread": "", "msg": linha})
    return itens


def _cauda(caminho: Path, limite: int) -> "tuple[list[str], int]":
    """(linhas, bytes_lidos). Descarta a primeira linha quando o corte cai no meio dela."""
    try:
        with open(caminho, "rb") as arquivo:
            arquivo.seek(0, os.SEEK_END)
            tamanho = arquivo.tell()
            inicio = max(0, tamanho - limite)
            arquivo.seek(inicio)
            dados = arquivo.read()
    except OSError:
        return [], 0
    linhas = dados.decode("utf-8", errors="replace").splitlines()
    if inicio > 0 and linhas:
        linhas = linhas[1:]
    return linhas, len(dados)


def ler_cauda(caminho: Path, max_bytes: int = 200_000) -> list[dict]:
    caminho = Path(caminho)
    atuais, lidos = _cauda(caminho, max_bytes)
    anteriores: list[str] = []
    if lidos < max_bytes:
        anteriores, _ = _cauda(caminho.with_name(caminho.name + ".1"), max_bytes - lidos)
    return interpretar_log(anteriores + atuais)


class LogStream(logging.Handler):
    """Empurra registros para o hub. Ignora o proprio logger do painel (anti-laco)."""

    def __init__(self, hub: Hub) -> None:
        super().__init__(level=logging.DEBUG)
        self._hub = hub

    def emit(self, record: logging.LogRecord) -> None:
        if not self._hub.ativo or record.name.startswith("jairo.painel"):
            return
        try:
            mensagem = record.getMessage()
            if record.exc_info:
                mensagem += "\n" + logging.Formatter().formatException(record.exc_info)
            self._hub.publicar("log", {
                "ts": time.strftime("%H:%M:%S", time.localtime(record.created)),
                "nivel": record.levelname,
                "thread": record.threadName,
                "msg": mensagem,
            })
        except Exception:
            pass                    # um handler de log nunca pode derrubar quem loga

    def ligar_ao(self, logger: logging.Logger) -> None:
        """Anexa o handler ao logger enquanto houver cliente no hub."""
        def alternar(ativo: bool) -> None:
            if ativo:
                logger.addHandler(self)
            else:
                logger.removeHandler(self)

        self._hub.ao_mudar_ativo(alternar)
