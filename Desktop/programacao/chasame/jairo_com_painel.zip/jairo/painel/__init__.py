"""
Chasame Studio: backend do painel (servidor local, eventos, editores de arquivo).

Somente biblioteca padrao. Este pacote NUNCA importa o jairo.py: tudo o que ele precisa
do Chasame chega por injecao (painel.servidor.Contexto). Assim o Chasame carrega e roda
sem o painel, e o painel pode ser testado sem Windows e sem microfone.
"""

from .apps import ErroApps, ListaApps, interpretar_apps
from .arquivos import (
    EditorContatos,
    EditorPermitidos,
    escrita_atomica,
    etag_arquivo,
    etag_bytes,
    normalizar_nome,
)
from .erros import ConflitoVersao, ErroArquivo, ErroEscrita, ErroPainel, ErroValidacao
from .hub import Hub
from .logs import LogStream, ler_cauda
from .servidor import Contexto, ServidorPainel

VERSAO_PAINEL = "1.0"

__all__ = [
    "ConflitoVersao", "Contexto", "EditorContatos", "EditorPermitidos", "ErroApps",
    "ErroArquivo", "ErroEscrita", "ErroPainel", "ErroValidacao", "Hub", "ListaApps",
    "LogStream", "ServidorPainel", "VERSAO_PAINEL", "escrita_atomica", "etag_arquivo",
    "etag_bytes", "interpretar_apps", "ler_cauda", "normalizar_nome",
]
