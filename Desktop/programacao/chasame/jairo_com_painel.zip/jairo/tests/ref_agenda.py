"""
Analisador de referencia: as MESMAS regras de Agenda._carregar (jairo.py v2.0), mas
coletando todos os erros em vez de parar no primeiro. Serve de contrato nos testes do
painel e, no passo do jairo.py, para provar que o parser refatorado da Agenda concorda.
"""

from __future__ import annotations

import re

from painel.arquivos import normalizar_nome

PHONE_RE = re.compile(r"^[1-9]\d{9,14}$")


def sem_acentos(texto: str) -> str:
    import unicodedata
    decomposto = unicodedata.normalize("NFKD", texto)
    sem = "".join(c for c in decomposto if not unicodedata.combining(c))
    return " ".join(sem.casefold().split())


def analisar(texto: str) -> list:
    erros = []
    vistos: set = set()
    aliases: dict = {}
    for numero_linha, linha in enumerate(texto.splitlines(), start=1):
        linha = linha.strip()
        if not linha or linha.startswith("#"):
            continue
        ativo = not linha.startswith("!")
        if not ativo:
            linha = linha[1:].strip()
        partes = [p.strip() for p in linha.split(":")]
        if len(partes) not in (2, 3) or not partes[0]:
            erros.append((numero_linha, f"linha inválida: {linha!r}"))
            continue
        nome, numero = partes[0], partes[1]
        chave = normalizar_nome(nome)
        if not PHONE_RE.fullmatch(numero):
            erros.append((numero_linha, f"número inválido {numero!r}"))
            continue
        if chave in vistos:
            erros.append((numero_linha, f"contato duplicado {nome!r}"))
            continue
        vistos.add(chave)
        if not ativo:
            continue
        if len(partes) == 3:
            for alias in (a.strip() for a in partes[2].split(",")):
                if not alias:
                    continue
                chave_alias = sem_acentos(alias)
                dono = aliases.get(chave_alias)
                if dono is not None and dono != chave:
                    erros.append((numero_linha, f"apelido duplicado {alias!r}"))
                else:
                    aliases[chave_alias] = chave
    return erros
