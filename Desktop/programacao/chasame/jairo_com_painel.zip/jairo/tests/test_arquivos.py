import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from painel.arquivos import (
    EditorContatos, EditorPermitidos, escrita_atomica, etag_bytes, normalizar_nome,
)
from painel.erros import ConflitoVersao, ErroArquivo, ErroEscrita, ErroValidacao
from tests.ref_agenda import analisar

CONTATOS = (
    "# Formato: Nome:5511999998888[:apelido1,apelido2]\n"
    "\n"
    "Gustavo Silva:5511999998888:gu,guto\n"
    "Maria Souza:5511988887777\n"
    "# comentario no meio\n"
    "!Pedro Antigo:5511977776666\n"
    "# rodape\n"
)


class Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.pasta = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)

    def escrever(self, nome, conteudo, binario=False):
        caminho = self.pasta / nome
        if binario:
            caminho.write_bytes(conteudo)
        else:
            caminho.write_bytes(conteudo.encode("utf-8"))
        return caminho


class TestEscritaAtomica(Base):
    def test_cria_arquivo_e_nao_deixa_temporarios(self):
        alvo = self.pasta / "a.txt"
        self.assertTrue(escrita_atomica(alvo, b"um"))
        self.assertEqual(alvo.read_bytes(), b"um")
        self.assertEqual([p.name for p in self.pasta.iterdir()], ["a.txt"])

    def test_backup_guarda_versao_anterior_so_quando_muda(self):
        alvo = self.escrever("a.txt", "antigo")
        self.assertTrue(escrita_atomica(alvo, b"novo"))
        bak = self.pasta / "a.txt.bak"
        self.assertEqual(bak.read_bytes(), b"antigo")
        self.assertFalse(escrita_atomica(alvo, b"novo"))      # igual: nada muda
        self.assertEqual(bak.read_bytes(), b"antigo")

    def test_arquivo_travado_tenta_de_novo_e_falha_sem_corromper(self):
        alvo = self.escrever("a.txt", "original")
        with mock.patch("painel.arquivos.os.replace", side_effect=PermissionError("em uso")):
            with self.assertRaises(ErroEscrita) as ctx:
                escrita_atomica(alvo, b"novo", tentativas=3, pausa=0)
        self.assertIn("em uso", str(ctx.exception))
        self.assertEqual(alvo.read_bytes(), b"original")
        self.assertFalse(any(p.name.endswith(".tmp") for p in self.pasta.iterdir()))

    def test_replace_funciona_na_segunda_tentativa(self):
        alvo = self.escrever("a.txt", "original")
        real = os.replace
        chamadas = []

        def instavel(origem, destino):
            chamadas.append(1)
            if len(chamadas) == 1:
                raise PermissionError("travado")
            return real(origem, destino)

        with mock.patch("painel.arquivos.os.replace", side_effect=instavel):
            self.assertTrue(escrita_atomica(alvo, b"novo", pausa=0))
        self.assertEqual(alvo.read_bytes(), b"novo")
        self.assertEqual(len(chamadas), 2)


class TestEditorContatos(Base):
    def editor(self, conteudo=CONTATOS, **kw):
        caminho = self.escrever("contatos.txt", conteudo, **kw)
        return caminho, EditorContatos(caminho, analisar)

    def salvar(self, editor, mutar=None):
        lido = editor.ler()
        contatos = lido["contatos"]
        if mutar:
            contatos = mutar(contatos) or contatos
        return editor.salvar(contatos, lido["etag"])

    def test_ler_lista_contatos_e_inativos(self):
        _, ed = self.editor()
        lido = ed.ler()
        self.assertEqual([c["nome"] for c in lido["contatos"]],
                         ["Gustavo Silva", "Maria Souza", "Pedro Antigo"])
        self.assertEqual(lido["contatos"][0]["apelidos"], ["gu", "guto"])
        self.assertFalse(lido["contatos"][2]["ativo"])
        self.assertEqual(lido["erros"], [])

    def test_ida_e_volta_sem_mudar_preserva_bytes(self):
        for conteudo in (CONTATOS, CONTATOS.replace("\n", "\r\n"), CONTATOS.rstrip("\n")):
            caminho, ed = self.editor(conteudo)
            antes = caminho.read_bytes()
            resultado = self.salvar(ed)
            self.assertFalse(resultado["alterado"])
            self.assertEqual(caminho.read_bytes(), antes)
            self.assertFalse((self.pasta / "contatos.txt.bak").exists())

    def test_editar_um_contato_muda_so_a_linha_dele(self):
        caminho, ed = self.editor(CONTATOS.replace("\n", "\r\n"))

        def mutar(cs):
            cs[1]["numero"] = "5511955554444"

        self.salvar(ed, mutar)
        esperado = CONTATOS.replace("5511988887777", "5511955554444").replace("\n", "\r\n")
        self.assertEqual(caminho.read_bytes().decode(), esperado)
        self.assertTrue((self.pasta / "contatos.txt.bak").exists())

    def test_novo_contato_entra_depois_do_ultimo_contato_antes_do_rodape(self):
        caminho, ed = self.editor()

        def mutar(cs):
            cs.append({"nome": "Ana Lima", "numero": "5511911112222",
                       "apelidos": ["aninha"], "ativo": True})

        self.salvar(ed, mutar)
        linhas = caminho.read_text(encoding="utf-8").splitlines()
        self.assertEqual(linhas[-2:], ["Ana Lima:5511911112222:aninha", "# rodape"])
        self.assertIn("# comentario no meio", linhas)

    def test_novo_contato_em_arquivo_sem_quebra_final(self):
        caminho, ed = self.editor("Maria Souza:5511988887777")

        def mutar(cs):
            cs.append({"nome": "Ana", "numero": "5511911112222", "apelidos": [], "ativo": True})

        self.salvar(ed, mutar)
        self.assertEqual(caminho.read_text(encoding="utf-8"),
                         "Maria Souza:5511988887777\nAna:5511911112222\n")

    def test_arquivo_inexistente_e_criado(self):
        caminho = self.pasta / "novo" / "contatos.txt"
        ed = EditorContatos(caminho, analisar)
        lido = ed.ler()
        self.assertEqual(lido["contatos"], [])
        ed.salvar([{"nome": "Ana", "numero": "5511911112222", "apelidos": [], "ativo": True}],
                  lido["etag"])
        self.assertIn("Ana:5511911112222", caminho.read_text(encoding="utf-8"))

    def test_remover_apaga_so_a_linha_e_mantem_comentarios(self):
        caminho, ed = self.editor()
        self.salvar(ed, lambda cs: cs.__delitem__(1))
        texto = caminho.read_text(encoding="utf-8")
        self.assertNotIn("Maria Souza", texto)
        self.assertIn("# comentario no meio", texto)
        self.assertIn("# rodape", texto)

    def test_alternar_ativo_poe_e_tira_o_prefixo(self):
        caminho, ed = self.editor()

        def mutar(cs):
            cs[0]["ativo"] = False
            cs[2]["ativo"] = True

        self.salvar(ed, mutar)
        linhas = caminho.read_text(encoding="utf-8").splitlines()
        self.assertIn("!Gustavo Silva:5511999998888:gu,guto", linhas)
        self.assertIn("Pedro Antigo:5511977776666", linhas)

    def test_numero_invalido_e_bloqueado_com_mensagem_e_arquivo_intacto(self):
        caminho, ed = self.editor()
        antes = caminho.read_bytes()
        lido = ed.ler()
        lido["contatos"][0]["numero"] = "123"
        with self.assertRaises(ErroValidacao) as ctx:
            ed.salvar(lido["contatos"], lido["etag"])
        erro = ctx.exception.erros[0]
        self.assertEqual((erro["indice"], erro["campo"]), (0, "numero"))
        self.assertIn("Número inválido", erro["mensagem"])
        self.assertEqual(caminho.read_bytes(), antes)

    def test_duplicados_sao_pegos_pelo_analisador_e_mapeados_para_a_linha_da_tabela(self):
        _, ed = self.editor()
        lido = ed.ler()
        lido["contatos"].append(
            {"nome": "gustavo silva", "numero": "5511911112222", "apelidos": [], "ativo": True})
        with self.assertRaises(ErroValidacao) as ctx:
            ed.salvar(lido["contatos"], lido["etag"])
        erro = ctx.exception.erros[0]
        self.assertEqual(erro["indice"], 3)
        self.assertIn("duplicado", erro["mensagem"])

    def test_apelido_duplicado_entre_contatos(self):
        _, ed = self.editor()
        lido = ed.ler()
        lido["contatos"][1]["apelidos"] = ["GU"]
        with self.assertRaises(ErroValidacao) as ctx:
            ed.salvar(lido["contatos"], lido["etag"])
        self.assertIn("apelido duplicado", ctx.exception.erros[0]["mensagem"])

    def test_caracteres_que_corromperiam_o_formato(self):
        _, ed = self.editor()
        for campo, valor in (("nome", "A:B"), ("nome", "!Fulano"), ("nome", "#x"),
                             ("nome", "A\nB"), ("apelidos", ["a,b"]), ("apelidos", ["a:b"])):
            lido = ed.ler()
            lido["contatos"][0][campo] = valor
            with self.assertRaises(ErroValidacao, msg=f"{campo}={valor!r}"):
                ed.salvar(lido["contatos"], lido["etag"])

    def test_edicao_manual_concorrente_gera_conflito(self):
        caminho, ed = self.editor()
        lido = ed.ler()
        caminho.write_bytes(caminho.read_bytes() + b"Zeca:5511900000000\n")
        with self.assertRaises(ConflitoVersao):
            ed.salvar(lido["contatos"], lido["etag"])

    def test_id_inexistente_ou_repetido_e_recusado(self):
        _, ed = self.editor()
        lido = ed.ler()
        lido["contatos"][0]["id"] = 99
        with self.assertRaises(ErroValidacao):
            ed.salvar(lido["contatos"], lido["etag"])
        lido = ed.ler()
        lido["contatos"][1]["id"] = lido["contatos"][0]["id"]
        with self.assertRaises(ErroValidacao):
            ed.salvar(lido["contatos"], lido["etag"])

    def test_bom_e_lido_e_a_gravacao_sai_sem_bom(self):
        caminho, ed = self.editor(b"\xef\xbb\xbf" + CONTATOS.encode("utf-8"), binario=True)

        def mutar(cs):
            cs[0]["apelidos"] = ["gu"]

        self.salvar(ed, mutar)
        self.assertFalse(caminho.read_bytes().startswith(b"\xef\xbb\xbf"))
        self.assertIn("Gustavo Silva:5511999998888:gu", caminho.read_text(encoding="utf-8"))

    def test_arquivo_fora_de_utf8_da_erro_claro(self):
        _, ed = self.editor(b"Jos\xe9:5511999998888\n", binario=True)
        with self.assertRaises(ErroArquivo):
            ed.ler()

    def test_linha_invalida_aparece_na_lista_e_pode_ser_removida(self):
        caminho, ed = self.editor("Maria:5511988887777\nlixo sem formato\n")
        lido = ed.ler()
        invalidas = [c for c in lido["contatos"] if c.get("invalida")]
        self.assertEqual(len(invalidas), 1)
        self.assertTrue(lido["erros"])
        restantes = [c for c in lido["contatos"] if not c.get("invalida")]
        ed.salvar(restantes, lido["etag"])
        self.assertEqual(caminho.read_text(encoding="utf-8"), "Maria:5511988887777\n")

    def test_montar_texto_nao_grava(self):
        caminho, ed = self.editor()
        antes = caminho.read_bytes()
        lido = ed.ler()
        lido["contatos"].append(
            {"nome": "Ana", "numero": "5511911112222", "apelidos": [], "ativo": True})
        self.assertIn("Ana:5511911112222", ed.montar_texto(lido["contatos"]))
        self.assertEqual(caminho.read_bytes(), antes)

    def test_nome_com_acento_faz_ida_e_volta(self):
        caminho, ed = self.editor("João Açaí:5511999998888:joão\n")
        self.assertFalse(self.salvar(ed)["alterado"])
        self.assertEqual(ed.ler()["contatos"][0]["nome"], "João Açaí")


class TestEditorPermitidos(Base):
    CONTEUDO = "# nomes como no WhatsApp\nGustavo Silva\n\nMaria Souza\n"

    def editor(self, conteudo=CONTEUDO, agenda=("Gustavo Silva", "Maria Souza", "Ana Lima")):
        caminho = self.escrever("permitidos.txt", conteudo)
        return caminho, EditorPermitidos(caminho, lambda: list(agenda))

    def test_ler_avisos_e_sugestoes(self):
        _, ed = self.editor("Gustavo Silva\nFulano Desconhecido\ngustavo silva\n")
        lido = ed.ler()
        tipos = sorted(a["tipo"] for a in lido["avisos"])
        self.assertEqual(tipos, ["duplicado", "fora_da_agenda"])
        self.assertEqual(lido["sugestoes"], ["Ana Lima", "Maria Souza"])

    def test_ida_e_volta_preserva_comentarios_e_bytes(self):
        caminho, ed = self.editor()
        antes = caminho.read_bytes()
        lido = ed.ler()
        self.assertFalse(ed.salvar(lido["nomes"], lido["etag"])["alterado"])
        self.assertEqual(caminho.read_bytes(), antes)

    def test_adicionar_remover_e_renomear(self):
        caminho, ed = self.editor()
        lido = ed.ler()
        nomes = [n for n in lido["nomes"] if n["nome"] != "Maria Souza"]
        nomes[0]["nome"] = "Gustavo S."
        nomes.append({"nome": "Ana Lima"})
        ed.salvar(nomes, lido["etag"])
        self.assertEqual(caminho.read_text(encoding="utf-8"),
                         "# nomes como no WhatsApp\nGustavo S.\n\nAna Lima\n")

    def test_adicionar_em_arquivo_sem_quebra_final(self):
        caminho, ed = self.editor("Gustavo Silva")
        lido = ed.ler()
        ed.salvar(lido["nomes"] + [{"nome": "Ana Lima"}], lido["etag"])
        self.assertEqual(caminho.read_text(encoding="utf-8"), "Gustavo Silva\nAna Lima\n")

    def test_validacoes(self):
        _, ed = self.editor()
        for ruim in ("", "   ", "#comentario", "a\nb", "x" * 101):
            lido = ed.ler()
            with self.assertRaises(ErroValidacao, msg=repr(ruim)):
                ed.salvar(lido["nomes"] + [{"nome": ruim}], lido["etag"])

    def test_conflito_de_versao(self):
        caminho, ed = self.editor()
        lido = ed.ler()
        caminho.write_bytes(b"Outro\n")
        with self.assertRaises(ConflitoVersao):
            ed.salvar(lido["nomes"], lido["etag"])


class TestNormalizacao(unittest.TestCase):
    def test_normalizar_nome(self):
        self.assertEqual(normalizar_nome("  João   SILVA "), "joão silva")
        self.assertEqual(normalizar_nome("ﬁnal"), "final")      # NFKC
        self.assertEqual(etag_bytes(b"x"), etag_bytes(b"x"))
        self.assertNotEqual(etag_bytes(b"x"), etag_bytes(b"y"))


if __name__ == "__main__":
    unittest.main()
