import json
import logging
import tempfile
import threading
import time
import unittest
from pathlib import Path

from painel import descoberta
from painel.apps import ErroApps, ListaApps, interpretar_apps
from painel.hub import Hub
from painel.logs import LogStream, interpretar_log, ler_cauda


class TestHub(unittest.TestCase):
    def test_sem_assinantes_publicar_nao_faz_nada(self):
        hub = Hub()
        hub.publicar("x", {"a": 1})
        hub.nivel(0.5)
        self.assertFalse(hub.ativo)
        self.assertEqual(hub._seq, 0)       # nenhuma alocacao de evento

    def test_entrega_ordem_e_ids(self):
        hub = Hub()
        a = hub.assinar()
        hub.publicar("um")
        hub.publicar("dois", {"k": 2})
        e1, e2 = a.obter(0.1), a.obter(0.1)
        self.assertEqual([e1["tipo"], e2["tipo"]], ["um", "dois"])
        self.assertLess(e1["id"], e2["id"])
        self.assertIsNone(a.obter(0.01))

    def test_limite_de_clientes_e_callbacks_de_ativo(self):
        hub = Hub(max_clientes=2)
        marcas = []
        hub.ao_mudar_ativo(marcas.append)
        a, b = hub.assinar(), hub.assinar()
        self.assertIsNone(hub.assinar())
        hub.remover(a)
        self.assertTrue(hub.ativo)
        hub.remover(b)
        self.assertFalse(hub.ativo)
        self.assertEqual(marcas, [True, False])

    def test_estado_so_publica_quando_muda_e_snapshot_sempre_vale(self):
        hub = Hub()
        hub.definir_estado(modo="standby")      # sem cliente: so atualiza o snapshot
        self.assertEqual(hub.estado()["modo"], "standby")
        a = hub.assinar()
        hub.definir_estado(modo="standby")      # igual: nada
        self.assertIsNone(a.obter(0.01))
        hub.definir_estado(atividade="voz")
        evento = a.obter(0.1)
        self.assertEqual(evento["tipo"], "estado")
        self.assertEqual(evento["dados"]["atividade"], "voz")
        self.assertEqual(evento["dados"]["modo"], "standby")

    def test_historico_limitado_e_registrado_sem_cliente(self):
        hub = Hub(tamanho_historico=3)
        for i in range(5):
            hub.registrar_comando(f"c{i}", "ok")
        textos = [h["texto"] for h in hub.instantaneo()["historico"]]
        self.assertEqual(textos, ["c2", "c3", "c4"])

    def test_nivel_limitado_a_20_por_segundo(self):
        hub = Hub(intervalo_nivel=0.05)
        a = hub.assinar()
        for _ in range(50):
            hub.nivel(0.4, True)
        self.assertEqual(a.obter(0.01)["dados"], {"v": 0.4, "voz": True})
        self.assertIsNone(a.obter(0.01))
        time.sleep(0.06)
        hub.nivel(1.7)
        self.assertEqual(a.obter(0.1)["dados"]["v"], 1.0)    # limitado a [0, 1]

    def test_fila_cheia_descarta_nivel_e_desconecta_quem_nao_acompanha(self):
        hub = Hub(capacidade_fila=8, intervalo_nivel=0)
        lento = hub.assinar()
        for _ in range(20):
            hub.nivel(0.1)
        tipos = []
        while True:
            e = lento.obter(0.01)
            if e is None:
                break
            tipos.append(e["tipo"])
        self.assertLessEqual(len(tipos), 6)          # nivel e descartado antes de lotar
        self.assertFalse(lento.fechado)
        for i in range(20):                          # eventos importantes lotam a fila
            hub.publicar("log", {"i": i})
        self.assertTrue(lento.fechado)
        self.assertFalse(hub.ativo)                  # assinante removido do hub

    def test_publicar_de_varias_threads(self):
        hub = Hub(capacidade_fila=5000)
        a = hub.assinar()

        def produzir():
            for i in range(200):
                hub.publicar("t", {"i": i})

        threads = [threading.Thread(target=produzir) for _ in range(5)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        recebidos = 0
        while a.obter(0.01):
            recebidos += 1
        self.assertEqual(recebidos, 1000)

    def test_fechar_todos(self):
        hub = Hub()
        a = hub.assinar()
        hub.fechar_todos()
        self.assertTrue(a.fechado)
        self.assertFalse(hub.ativo)


class TestLogs(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.log = Path(self._tmp.name) / "jairo.log"

    @staticmethod
    def linha(i, nivel="INFO"):
        return f"10:00:{i % 60:02d} | {nivel:<8} | {'MainThread':<22} | mensagem {i}\n"

    def test_interpretar_com_traceback(self):
        itens = interpretar_log([
            "10:00:01 | ERROR    | MainThread             | falhou | com barra",
            "Traceback (most recent call last):",
            '  File "x.py", line 1',
            "10:00:02 | INFO     | AudioCaptura           | ok",
        ])
        self.assertEqual(len(itens), 2)
        self.assertEqual(itens[0]["nivel"], "ERROR")
        self.assertEqual(itens[0]["thread"], "MainThread")
        self.assertTrue(itens[0]["msg"].startswith("falhou | com barra\nTraceback"))
        self.assertEqual(itens[1]["thread"], "AudioCaptura")

    def test_cauda_le_so_o_fim_e_descarta_linha_cortada(self):
        self.log.write_text("".join(self.linha(i) for i in range(5000)), encoding="utf-8")
        tamanho = self.log.stat().st_size
        itens = ler_cauda(self.log, 20_000)
        self.assertLess(len(itens), 5000)
        self.assertGreater(len(itens), 100)
        self.assertEqual(itens[-1]["msg"], "mensagem 4999")
        for item in itens:                           # nenhuma linha cortada ao meio
            self.assertTrue(item["msg"].startswith("mensagem "))
        self.assertGreater(tamanho, 20_000)

    def test_arquivo_pequeno_e_ausente(self):
        self.assertEqual(ler_cauda(self.log), [])
        self.log.write_text(self.linha(1), encoding="utf-8")
        self.assertEqual(len(ler_cauda(self.log)), 1)

    def test_apos_rotacao_completa_com_o_arquivo_anterior(self):
        (Path(self._tmp.name) / "jairo.log.1").write_text(
            "".join(self.linha(i) for i in range(10)), encoding="utf-8")
        self.log.write_text(self.linha(50), encoding="utf-8")
        itens = ler_cauda(self.log)
        self.assertEqual(len(itens), 11)
        self.assertEqual(itens[-1]["msg"], "mensagem 50")

    def test_logstream_so_envia_com_cliente_e_ignora_o_logger_do_painel(self):
        hub = Hub()
        logger = logging.getLogger("jairo.teste.logstream")
        logger.setLevel(logging.DEBUG)
        logger.propagate = False
        fluxo = LogStream(hub)
        fluxo.ligar_ao(logger)
        self.assertNotIn(fluxo, logger.handlers)     # sem cliente: nem anexado
        a = hub.assinar()
        self.assertIn(fluxo, logger.handlers)
        logger.warning("ola %s", "mundo")
        try:
            raise ValueError("x")
        except ValueError:
            logger.exception("deu ruim")
        painel = logging.getLogger("jairo.painel.teste")
        painel.addHandler(fluxo)
        painel.propagate = False
        painel.warning("nao deve aparecer")
        painel.removeHandler(fluxo)
        e1, e2, e3 = a.obter(0.1), a.obter(0.1), a.obter(0.05)
        self.assertEqual((e1["tipo"], e1["dados"]["nivel"], e1["dados"]["msg"]),
                         ("log", "WARNING", "ola mundo"))
        self.assertIn("ValueError: x", e2["dados"]["msg"])
        self.assertIsNone(e3)
        hub.remover(a)
        self.assertNotIn(fluxo, logger.handlers)


class TestApps(unittest.TestCase):
    def test_interpretar_lista_objeto_unico_dedupe_e_bom(self):
        bruto = json.dumps([
            {"Name": "Spotify", "AppID": "Spotify.App"},
            {"Name": "discord", "AppID": "com.squirrel.Discord.Discord"},
            {"Name": "Spotify de novo", "AppID": "Spotify.App"},
            {"Name": "", "AppID": "x"},
            {"Name": "Sem id"},
            "lixo",
        ])
        apps = interpretar_apps("\ufeff" + bruto)
        self.assertEqual([a["nome"] for a in apps], ["discord", "Spotify"])
        unico = interpretar_apps(json.dumps({"Name": "Só um", "AppID": "so.um"}))
        self.assertEqual(unico, [{"nome": "Só um", "id": "so.um"}])
        self.assertEqual(interpretar_apps("  "), [])
        with self.assertRaises(ErroApps):
            interpretar_apps("nao e json")

    def test_cache_ttl_e_atualizar(self):
        chamadas = []
        agora = [0.0]

        def executor():
            chamadas.append(1)
            return json.dumps([{"Name": f"App{len(chamadas)}", "AppID": "a"}])

        lista = ListaApps(executor, ttl=100, relogio=lambda: agora[0])
        self.assertEqual(lista.obter()["apps"][0]["nome"], "App1")
        lista.obter()
        self.assertEqual(len(chamadas), 1)
        agora[0] = 101
        self.assertEqual(lista.obter()["apps"][0]["nome"], "App2")
        self.assertEqual(lista.obter(atualizar=True)["apps"][0]["nome"], "App3")

    def test_falha_ao_atualizar_mantem_o_cache(self):
        estado = {"falhar": False}

        def executor():
            if estado["falhar"]:
                raise ErroApps("sem powershell")
            return json.dumps([{"Name": "A", "AppID": "a"}])

        lista = ListaApps(executor)
        lista.obter()
        estado["falhar"] = True
        with self.assertRaises(ErroApps):
            lista.obter(atualizar=True)
        self.assertEqual(len(lista.obter()["apps"]), 1)

    def test_chamadas_simultaneas_compartilham_uma_execucao(self):
        chamadas = []

        def executor():
            chamadas.append(1)
            time.sleep(0.15)
            return json.dumps([{"Name": "A", "AppID": "a"}])

        lista = ListaApps(executor)
        threads = [threading.Thread(target=lista.obter) for _ in range(4)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        self.assertEqual(len(chamadas), 1)


class TestDescoberta(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.pasta = Path(self._tmp.name)

    def test_gravar_ler_remover_por_pid(self):
        dados = {"pid": 123, "porta": 5000, "token": "abc"}
        descoberta.gravar(dados, self.pasta)
        self.assertEqual(descoberta.ler(self.pasta), dados)
        descoberta.remover(pid=999, pasta=self.pasta)        # outro processo: nao apaga
        self.assertIsNotNone(descoberta.ler(self.pasta))
        descoberta.remover(pid=123, pasta=self.pasta)
        self.assertIsNone(descoberta.ler(self.pasta))

    def test_arquivo_corrompido_ou_incompleto(self):
        (self.pasta / "painel.json").write_text("{nao e json", encoding="utf-8")
        self.assertIsNone(descoberta.ler(self.pasta))
        (self.pasta / "painel.json").write_text('{"porta": 1}', encoding="utf-8")
        self.assertIsNone(descoberta.ler(self.pasta))

    def test_arquivo_velho_sem_servidor_nao_e_considerado_vivo(self):
        descoberta.gravar({"pid": 1, "porta": 1, "token": "x"}, self.pasta)
        self.assertIsNone(descoberta.localizar(self.pasta, timeout=0.3))

    def test_url_leva_o_token_no_fragmento(self):
        self.assertEqual(descoberta.url_painel({"porta": 8, "token": "t"}),
                         "http://127.0.0.1:8/#t=t")

    def test_pasta_usa_localappdata(self):
        self.assertEqual(descoberta.pasta_estado({"LOCALAPPDATA": "C:/L"}), Path("C:/L") / "Chasame")


if __name__ == "__main__":
    unittest.main()
