import http.client
import json
import tempfile
import time
import unittest
from pathlib import Path

from painel import descoberta
from painel.apps import ErroApps, ListaApps
from painel.arquivos import EditorContatos, EditorPermitidos
from painel.erros import ConflitoVersao, ErroValidacao
from painel.hub import Hub
from painel.servidor import Contexto, ServidorPainel
from tests.ref_agenda import analisar


class ComandosFalso:
    def __init__(self):
        self.doc = {"etag": '"v1"', "opcoes": {"similaridade": False}, "comandos": []}
        self.gravados = []

    def ler(self):
        return dict(self.doc)

    def gravar(self, documento, etag, confirmar_conflitos):
        if etag != self.doc["etag"]:
            raise ConflitoVersao()
        for c in documento["comandos"]:
            if c.get("frase") == "desligar" and c["id"] not in confirmar_conflitos:
                raise ErroValidacao(
                    [], conflitos=[{"id": c["id"], "nativo": "desligar o chasame"}])
        self.gravados.append(documento)
        self.doc = {"etag": '"v2"', **documento}
        return {"etag": '"v2"'}

    def verificar(self, frase, ident):
        return {"duplicada": False, "conflito_nativo": frase == "desligar"}


class Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        pasta = Path(self._tmp.name)
        (pasta / "ui").mkdir()
        (pasta / "ui" / "index.html").write_text("<h1>painel</h1>", encoding="utf-8")
        (pasta / "ui" / "app.js").write_text("console.log(1)", encoding="utf-8")
        (pasta / "segredo.txt").write_text("segredo", encoding="utf-8")
        (pasta / "contatos.txt").write_text(
            "# c\nMaria Souza:5511988887777\n", encoding="utf-8")
        (pasta / "permitidos.txt").write_text("Maria Souza\n", encoding="utf-8")
        (pasta / "jairo.log").write_text(
            "10:00:01 | INFO     | MainThread             | ola\n", encoding="utf-8")

        self.chamadas = []
        self.comandos = ComandosFalso()
        self.hub = Hub()
        self.contexto = Contexto(
            nome="Chasame", versao="2.0", dir_ui=pasta / "ui",
            caminho_log=pasta / "jairo.log",
            editor_contatos=EditorContatos(pasta / "contatos.txt", analisar),
            editor_permitidos=EditorPermitidos(pasta / "permitidos.txt", lambda: ["Maria Souza"]),
            comandos=self.comandos,
            lista_apps=ListaApps(lambda: json.dumps([{"Name": "Discord", "AppID": "dc"}])),
            explicar_nome=lambda nome, texto: {"nome": nome, "rascunho": texto is not None},
            ao_salvar_contatos=lambda: self.chamadas.append("recarregar"),
            injetar_comando=lambda t: self.chamadas.append(("comando", t)),
            executar_acao=self.acao_falsa,
            abrir_arquivo=lambda chave: self.chamadas.append(("abrir", chave)) or True,
        )
        self.srv = ServidorPainel(self.contexto, self.hub, intervalo_ping=0.2)
        self.srv.iniciar()
        self.addCleanup(self.srv.encerrar)

    def acao_falsa(self, acao, dados):
        if acao == "testar" and not dados.get("id"):
            raise ValueError("Informe o comando a testar.")
        self.chamadas.append(("acao", acao))
        return {"modo": "standby"}

    def req(self, metodo, caminho, corpo=None, token=True, headers=None, bruto=None):
        cab = dict(headers or {})
        if token is True:
            cab["X-Chasame-Token"] = self.srv.token
        elif token:
            cab["X-Chasame-Token"] = token
        dados = bruto
        if corpo is not None:
            dados = json.dumps(corpo).encode("utf-8")
            cab.setdefault("Content-Type", "application/json")
        conexao = http.client.HTTPConnection("127.0.0.1", self.srv.porta, timeout=5)
        try:
            conexao.request(metodo, caminho, body=dados, headers=cab)
            resposta = conexao.getresponse()
            texto = resposta.read().decode("utf-8")
            try:
                corpo_json = json.loads(texto)
            except ValueError:
                corpo_json = texto
            return resposta.status, corpo_json, resposta
        finally:
            conexao.close()


class TestSeguranca(Base):
    def test_sem_token_ou_token_errado_401(self):
        self.assertEqual(self.req("GET", "/api/estado", token=False)[0], 401)
        self.assertEqual(self.req("GET", "/api/estado", token="errado")[0], 401)
        self.assertEqual(self.req("GET", "/api/estado", token="não-ascii-é")[0], 401)
        self.assertEqual(self.req("GET", "/api/estado")[0], 200)

    def test_host_errado_403_inclusive_para_estaticos_e_com_token_valido(self):
        for caminho in ("/", "/api/estado", "/events"):
            status, _, _ = self.req("GET", caminho, headers={"Host": "evil.example.com"})
            self.assertEqual(status, 403, caminho)
        status, _, _ = self.req("GET", "/", headers={"Host": f"127.0.0.1:{self.srv.porta + 1}"})
        self.assertEqual(status, 403)
        status, _, _ = self.req("GET", "/", headers={"Host": f"localhost:{self.srv.porta}"})
        self.assertEqual(status, 200)

    def test_origin_estranho_403(self):
        for origem in ("http://evil.example.com", "null", "https://127.0.0.1"):
            status, _, _ = self.req("GET", "/api/estado", headers={"Origin": origem})
            self.assertEqual(status, 403, origem)
        status, _, _ = self.req(
            "GET", "/api/estado", headers={"Origin": f"http://127.0.0.1:{self.srv.porta}"})
        self.assertEqual(status, 200)

    def test_sem_cabecalhos_cors_e_com_politicas_de_seguranca(self):
        _, _, resposta = self.req("GET", "/")
        self.assertIsNone(resposta.getheader("Access-Control-Allow-Origin"))
        self.assertIn("default-src 'self'", resposta.getheader("Content-Security-Policy"))
        self.assertEqual(resposta.getheader("X-Content-Type-Options"), "nosniff")
        self.assertEqual(resposta.getheader("Cache-Control"), "no-store")
        status, _, _ = self.req("OPTIONS", "/api/estado")
        self.assertEqual(status, 405)

    def test_estaticos_servem_so_a_pasta_ui(self):
        self.assertEqual(self.req("GET", "/", token=False)[0], 200)
        status, corpo, resposta = self.req("GET", "/app.js", token=False)
        self.assertEqual(status, 200)
        self.assertIn("javascript", resposta.getheader("Content-Type"))
        for caminho in ("/../segredo.txt", "/%2e%2e/segredo.txt", "/..%2fsegredo.txt",
                        "/nao-existe.html", "/%00", "/ui"):
            self.assertEqual(self.req("GET", caminho, token=False)[0], 404, caminho)

    def test_limites_do_corpo(self):
        status, corpo, _ = self.req(
            "POST", "/api/comando", bruto=b"x", headers={
                "Content-Type": "application/json", "Content-Length": "2000000"})
        self.assertEqual(status, 413)
        self.assertEqual(self.req("POST", "/api/comando", bruto=b"{}",
                                  headers={"Content-Type": "text/plain"})[0], 415)
        self.assertEqual(self.req("POST", "/api/comando", bruto=b"{nao json",
                                  headers={"Content-Type": "application/json"})[0], 400)
        self.assertEqual(self.req("POST", "/api/comando", bruto=b"[1]",
                                  headers={"Content-Type": "application/json"})[0], 400)

    def test_rota_inexistente_e_metodo_errado(self):
        self.assertEqual(self.req("GET", "/api/nada")[0], 404)
        self.assertEqual(self.req("DELETE", "/api/estado")[0], 405)
        self.assertEqual(self.req("POST", "/api/estado", corpo={})[0], 405)


class TestApi(Base):
    def test_estado_traz_nome_snapshot_e_historico(self):
        self.hub.definir_estado(pronto=True, modo="standby")
        self.hub.registrar_comando("abrir call", "ok")
        status, corpo, _ = self.req("GET", "/api/estado")
        self.assertEqual(status, 200)
        self.assertEqual((corpo["nome"], corpo["modo"], corpo["pronto"]),
                         ("Chasame", "standby", True))
        self.assertEqual(corpo["historico"][0]["texto"], "abrir call")

    def test_contatos_ler_salvar_recarregar_e_etag(self):
        status, lido, _ = self.req("GET", "/api/contatos")
        self.assertEqual(status, 200)
        contatos = lido["contatos"] + [
            {"nome": "Ana", "numero": "5511911112222", "apelidos": [], "ativo": True}]

        self.assertEqual(self.req("PUT", "/api/contatos", corpo={"contatos": contatos})[0], 428)
        status, corpo, _ = self.req("PUT", "/api/contatos", corpo={"contatos": contatos},
                                    headers={"If-Match": '"velho"'})
        self.assertEqual(status, 409)

        status, corpo, _ = self.req("PUT", "/api/contatos", corpo={"contatos": contatos},
                                    headers={"If-Match": lido["etag"]})
        self.assertEqual(status, 200)
        self.assertTrue(corpo["alterado"])
        self.assertEqual([c["nome"] for c in corpo["contatos"]], ["Maria Souza", "Ana"])
        self.assertEqual(self.chamadas, ["recarregar"])
        self.assertNotEqual(corpo["etag"], lido["etag"])

        # sem mudanca: nao recarrega de novo
        status, corpo, _ = self.req("PUT", "/api/contatos", corpo={"contatos": corpo["contatos"],
                                                                   "etag": corpo["etag"]})
        self.assertEqual(status, 200)
        self.assertFalse(corpo["alterado"])
        self.assertEqual(self.chamadas, ["recarregar"])

    def test_contato_invalido_422_com_mensagem_clara_e_arquivo_intacto(self):
        _, lido, _ = self.req("GET", "/api/contatos")
        lido["contatos"][0]["numero"] = "abc"
        antes = (Path(self._tmp.name) / "contatos.txt").read_bytes()
        status, corpo, _ = self.req("PUT", "/api/contatos",
                                    corpo={"contatos": lido["contatos"], "etag": lido["etag"]})
        self.assertEqual(status, 422)
        self.assertIn("Número inválido", corpo["erro"])
        self.assertEqual(corpo["erros"][0]["campo"], "numero")
        self.assertEqual((Path(self._tmp.name) / "contatos.txt").read_bytes(), antes)
        self.assertEqual(self.chamadas, [])

    def test_falha_ao_recarregar_vira_aviso_mas_o_arquivo_foi_salvo(self):
        def quebrado():
            raise RuntimeError("agenda travada")

        self.contexto.ao_salvar_contatos = quebrado
        _, lido, _ = self.req("GET", "/api/contatos")
        lido["contatos"][0]["apelidos"] = ["mari"]
        status, corpo, _ = self.req("PUT", "/api/contatos",
                                    corpo={"contatos": lido["contatos"], "etag": lido["etag"]})
        self.assertEqual(status, 200)
        self.assertIn("agenda travada", corpo["aviso"])

    def test_explicar_nome_usa_rascunho_quando_enviado(self):
        _, lido, _ = self.req("GET", "/api/contatos")
        status, corpo, _ = self.req("POST", "/api/contatos/explicar", corpo={"nome": "maria"})
        self.assertEqual(corpo, {"nome": "maria", "rascunho": False})
        _, corpo, _ = self.req("POST", "/api/contatos/explicar",
                               corpo={"nome": "maria", "contatos": lido["contatos"]})
        self.assertTrue(corpo["rascunho"])
        self.assertEqual(self.req("POST", "/api/contatos/explicar", corpo={"nome": ""})[0], 400)

    def test_permitidos(self):
        _, lido, _ = self.req("GET", "/api/permitidos")
        self.assertEqual(lido["avisos"], [])
        nomes = lido["nomes"] + [{"nome": "Fulano"}]
        status, corpo, _ = self.req("PUT", "/api/permitidos",
                                    corpo={"nomes": nomes, "etag": lido["etag"]})
        self.assertEqual(status, 200)
        self.assertEqual([a["tipo"] for a in corpo["avisos"]], ["fora_da_agenda"])
        status, corpo, _ = self.req("PUT", "/api/permitidos",
                                    corpo={"nomes": [{"nome": "#x"}], "etag": corpo["etag"]})
        self.assertEqual(status, 422)

    def test_comandos_delegados_com_etag_e_confirmacao_de_conflito(self):
        status, corpo, _ = self.req("GET", "/api/comandos")
        self.assertEqual(corpo["etag"], '"v1"')
        novo = {"id": "u1", "frase": "desligar", "acao": {"tipo": "url", "alvo": "https://x.y"}}
        status, corpo, _ = self.req("PUT", "/api/comandos", corpo={"comandos": [novo]},
                                    headers={"If-Match": '"v1"'})
        self.assertEqual(status, 422)
        self.assertEqual(corpo["conflitos"][0]["id"], "u1")
        status, corpo, _ = self.req("PUT", "/api/comandos", headers={"If-Match": '"v1"'},
                                    corpo={"comandos": [novo], "confirmar_conflitos": ["u1"]})
        self.assertEqual((status, corpo["etag"]), (200, '"v2"'))
        self.assertEqual(self.req("PUT", "/api/comandos", corpo={"comandos": []},
                                  headers={"If-Match": '"v1"'})[0], 409)
        self.assertEqual(self.req("PUT", "/api/comandos", corpo={"comandos": "x"},
                                  headers={"If-Match": '"v2"'})[0], 400)
        _, corpo, _ = self.req("POST", "/api/comandos/verificar", corpo={"frase": "desligar"})
        self.assertTrue(corpo["conflito_nativo"])

    def test_apps_e_erro_do_powershell(self):
        status, corpo, _ = self.req("GET", "/api/apps")
        self.assertEqual(corpo["apps"], [{"nome": "Discord", "id": "dc"}])

        def falha():
            raise ErroApps("PowerShell não encontrado.")

        self.contexto.lista_apps = ListaApps(falha)
        status, corpo, _ = self.req("GET", "/api/apps?atualizar=1")
        self.assertEqual(status, 500)
        self.assertIn("PowerShell", corpo["erro"])

    def test_log_tail(self):
        _, corpo, _ = self.req("GET", "/api/log")
        self.assertEqual(corpo["linhas"][0]["msg"], "ola")

    def test_injetar_comando(self):
        status, _, _ = self.req("POST", "/api/comando", corpo={"texto": "  abrir call  "})
        self.assertEqual(status, 202)
        self.assertEqual(self.chamadas, [("comando", "abrir call")])
        for ruim in ({"texto": ""}, {"texto": "   "}, {"texto": 5}, {"texto": "x" * 501}, {}):
            self.assertEqual(self.req("POST", "/api/comando", corpo=ruim)[0], 400, ruim)

    def test_acoes_com_lista_branca(self):
        self.assertEqual(self.req("POST", "/api/acao", corpo={"acao": "standby"})[1]["modo"],
                         "standby")
        self.assertEqual(self.req("POST", "/api/acao", corpo={"acao": "formatar_disco"})[0], 400)
        self.assertEqual(self.req("POST", "/api/acao", corpo={"acao": "testar"})[0], 400)
        for arquivo in ("log", "contatos", "permitidos", "pasta"):
            self.assertEqual(self.req("POST", "/api/acao",
                                      corpo={"acao": "abrir_arquivo", "arquivo": arquivo})[0], 200)
        for ruim in ("C:/Windows/system32/calc.exe", "../x", "perfil_jairo", "", None):
            status, _, _ = self.req("POST", "/api/acao",
                                    corpo={"acao": "abrir_arquivo", "arquivo": ruim})
            self.assertEqual(status, 400, ruim)
        abertos = [c[1] for c in self.chamadas if c[0] == "abrir"]
        self.assertEqual(abertos, ["log", "contatos", "permitidos", "pasta"])

    def test_recurso_nao_injetado_da_501(self):
        self.contexto.abrir_arquivo = None
        self.assertEqual(self.req("POST", "/api/acao",
                                  corpo={"acao": "abrir_arquivo", "arquivo": "log"})[0], 501)


class LeitorSSE:
    def __init__(self, srv, token=True, host=None):
        self.conexao = http.client.HTTPConnection("127.0.0.1", srv.porta, timeout=5)
        cab = {}
        if token:
            cab["X-Chasame-Token"] = srv.token
        if host:
            cab["Host"] = host
        self.conexao.request("GET", "/events", headers=cab)
        self.resposta = self.conexao.getresponse()

    def proximo(self):
        evento = {}
        while True:
            linha = self.resposta.readline().decode("utf-8").rstrip("\n")
            if linha == "":
                if evento:
                    return evento
                continue
            if linha.startswith(":"):
                evento = {"ping": True}
                continue
            campo, _, valor = linha.partition(": ")
            evento[campo] = valor
            if campo == "data":
                evento["dados"] = json.loads(valor)

    def fechar(self):
        # a resposta guarda uma referencia propria ao socket: sem fecha-la o servidor nao ve a saida
        self.resposta.close()
        self.conexao.close()


class TestSSE(Base):
    def esperar(self, condicao, limite=3.0):
        fim = time.monotonic() + limite
        while time.monotonic() < fim:
            if condicao():
                return True
            time.sleep(0.02)
        return False

    def test_exige_token_e_host_valido(self):
        self.assertEqual(LeitorSSE(self.srv, token=False).resposta.status, 401)
        self.assertEqual(LeitorSSE(self.srv, host="evil.example.com").resposta.status, 403)
        self.assertFalse(self.hub.ativo)

    def test_primeiro_evento_e_o_estado_e_depois_os_publicados(self):
        self.hub.definir_estado(pronto=True)
        leitor = LeitorSSE(self.srv)
        self.addCleanup(leitor.fechar)
        self.assertEqual(leitor.resposta.status, 200)
        self.assertIn("text/event-stream", leitor.resposta.getheader("Content-Type"))
        primeiro = leitor.proximo()
        self.assertEqual((primeiro["event"], primeiro["dados"]["pronto"]), ("estado", True))
        self.assertTrue(self.esperar(lambda: self.hub.ativo))

        self.hub.registrar_comando("abrir call", "ok")
        e = leitor.proximo()
        self.assertEqual((e["event"], e["dados"]["texto"]), ("comando", "abrir call"))
        self.hub.publicar("fala", {"texto": "Abrindo a call", "duracao_estimada_ms": 900})
        self.assertEqual(leitor.proximo()["dados"]["duracao_estimada_ms"], 900)

    def test_latencia_do_evento_ate_o_cliente_abaixo_de_200ms(self):
        leitor = LeitorSSE(self.srv)
        self.addCleanup(leitor.fechar)
        leitor.proximo()
        self.assertTrue(self.esperar(lambda: self.hub.ativo))
        piores = []
        for i in range(20):
            inicio = time.perf_counter()
            self.hub.definir_estado(atividade="voz" if i % 2 == 0 else "nenhuma")
            e = leitor.proximo()
            piores.append(time.perf_counter() - inicio)
            self.assertEqual(e["event"], "estado")
        self.assertLess(max(piores), 0.2, f"latencias (s): {sorted(piores)[-3:]}")

    def test_heartbeat_mantem_a_conexao_viva(self):
        leitor = LeitorSSE(self.srv)
        self.addCleanup(leitor.fechar)
        leitor.proximo()
        self.assertTrue(leitor.proximo().get("ping"))

    def test_cliente_que_sai_e_removido_e_custo_volta_a_zero(self):
        leitor = LeitorSSE(self.srv)
        leitor.proximo()
        self.assertTrue(self.esperar(lambda: self.hub.ativo))
        leitor.fechar()
        self.assertTrue(self.esperar(lambda: not self.hub.ativo), "assinante nao foi removido")
        seq = self.hub._seq
        self.hub.publicar("x")
        self.hub.nivel(0.5)
        self.assertEqual(self.hub._seq, seq)

    def test_maximo_de_clientes_503(self):
        leitores = [LeitorSSE(self.srv) for _ in range(4)]
        for l in leitores:
            self.addCleanup(l.fechar)
            l.proximo()
        self.assertEqual(LeitorSSE(self.srv).resposta.status, 503)

    def test_encerrar_fecha_as_conexoes(self):
        leitor = LeitorSSE(self.srv)
        self.addCleanup(leitor.fechar)
        leitor.proximo()
        self.srv.encerrar()
        fim = time.monotonic() + 3
        terminou = False
        while time.monotonic() < fim:
            try:
                if leitor.resposta.readline() == b"":
                    terminou = True
                    break
            except OSError:
                terminou = True
                break
        self.assertTrue(terminou)


class TestDescobertaComServidor(Base):
    def test_localizar_encontra_servidor_vivo_e_url_funciona(self):
        pasta = Path(self._tmp.name) / "estado"
        descoberta.gravar(self.srv.dados_descoberta(), pasta)
        dados = descoberta.localizar(pasta)
        self.assertIsNotNone(dados)
        self.assertEqual(dados["nome"], "Chasame")
        self.assertTrue(descoberta.url_painel(dados).endswith("#t=" + self.srv.token))
        adulterado = {**dados, "token": "outro"}
        self.assertFalse(descoberta.sondar(adulterado))


if __name__ == "__main__":
    unittest.main()
