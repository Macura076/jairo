"""
JAIRO v2.0 (revisao 2)
==============================================================
Assistente virtual por comando de voz integrado ao Windows.

Mudancas arquiteturais em relacao a v1.5:
  - WebDriver isolado em WhatsAppService com worker thread unica.
    Nenhuma outra thread toca o driver diretamente.
  - Agenda com busca exata e validacao de numero na inicializacao.
  - Timeout global compartilhado entre todos os seletores CSS/XPath.
  - Confirmacao de envio via contagem de bolhas .message-out.
  - Auto-responder com fingerprint SHA-256 por mensagem, nao por pessoa.
  - WebElements nunca guardados entre aquisicoes de lock.
  - Backoff exponencial com jitter para retentativas.
  - Logging estruturado com RotatingFileHandler e mascaramento de numero.
  - Threads iniciadas exclusivamente dentro de main().
  - subprocess.Popen sem shell=True.
  - Configuracao via .env com python-dotenv.
  - Injecao JS via argumento do execute_script, sem f-string.

Revisao 2:
  - Palavra de ativacao obrigatoria: todo comando deve comecar com
    "jairo" (aliases em JAIRO_WAKE_ALIASES; desativavel com
    JAIRO_EXIGIR_WAKE=false).
  - Controle de midia e volume (teclas de midia; pycaw opcional para
    volume absoluto).
  - Leitura por voz das conversas nao lidas, sem abrir os chats.
  - "verificar mensagens" agora dispara de fato a varredura do
    auto-responder, via fila do worker (sem tocar o driver fora dele).
  - "cancelar desligamento" executa shutdown /a.
  - TTS: motor recriado a cada fala, deteccao de fala silenciosa,
    fallback automatico para PowerShell/SAPI e modo de diagnostico
    (python jairo.py --testar-voz).
  - O microfone descarta audio capturado enquanto o Jairo fala.

Revisao 3:
  - Leitura de nao lidas reescrita: coleta via JavaScript tolerante a
    mudancas de DOM do WhatsApp Web (fallback para Selenium) e comando
    "diagnosticar whatsapp" que grava wpp_diagnostico.json.
  - Captura de tela (Win+Shift+S) e bloqueio do PC (LockWorkStation).

Revisao 4 (latencia e usabilidade):
  - Acoes instantaneas (print, bloqueio, janelas, midia, volume) executam
    antes de qualquer fala; feedback por bipes.
  - Microfone aberto continuamente (pause_threshold padrao 0.8 s, JAIRO_PAUSE).
  - Envio de WhatsApp sem sleeps fixos (cabecalho confirmado por polling).
  - Novos: timers, janelas, print de tela inteira, data, repetir, ajuda,
    modo silencioso, atalhos para projetos/downloads/configuracoes.

Revisao 5:
  - Microfone: limite minimo de energia 300 -> 120 (JAIRO_ENERGY_MIN), ganho
    automatico para voz baixa (JAIRO_GANHO_MAX), "recalibrar microfone" e
    diagnostico python jairo.py --testar-mic (sugere JAIRO_ENERGY).
  - Calculadora por voz: "quanto e 15 + 14" responde apenas "29".
  - Agenda: apelidos (Nome:numero:apelido), contatos inativos (!Nome:numero),
    nome ambiguo pede o nome completo, "buscar contato X" lista os cadastrados.

Revisao 6 (confirmacao por voz):
  - O prazo de confirmacao so comeca a contar quando o Jairo termina de
    falar o pedido (antes o tempo da propria fala consumia a janela).
  - Resposta sem a palavra de ativacao: "confirmar" (ou "cancelar"/"nao")
    funciona durante um pedido pendente.
  - Qualquer outro comando com a palavra de ativacao descarta o pedido.
  - "confirmar" depois de expirar avisa que a confirmacao expirou.
  - Lixeira: consulta a quantidade de itens (SHQueryRecycleBinW), avisa se
    ja esta vazia, aceita "esvazie/limpe a lixeira" e declara os tipos da
    chamada SHEmptyRecycleBinW.

Revisao 7 (painel grafico e apelidos por voz):
  - "jairo, chame JOAO SILVA de JOAOZINHO" grava o apelido no contatos.txt
    (com backup .bak) e recarrega a agenda na hora.
  - Interface grafica (pastas painel/ e ui/ ao lado deste arquivo):
      python jairo.py             abre a janela (inicia o motor se preciso)
      python jairo.py --terminal  motor em primeiro plano, com logs no console
      python jairo.py --sem-painel  comportamento antigo, sem interface
    O motor roda sem console (pythonw); a janela e um processo separado e
    leve (pywebview se instalado, senao o navegador padrao).
  - Agenda: parser unico que coleta todos os erros (usado pelo painel),
    recarregar() sem reiniciar, leitura com BOM e troca atomica dos dados.
==============================================================
"""

from __future__ import annotations

import ast
import hashlib
import json
import logging
import math
import os
import queue
import random
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
import traceback
import unicodedata
import webbrowser
from array import array
from concurrent.futures import Future
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from logging.handlers import RotatingFileHandler
from pathlib import Path
from time import monotonic
from typing import Callable


# ==============================================================
#  INICIALIZACAO LEVE (papeis "lancador" e "janela")
# ==============================================================
# Estas funcoes usam so a biblioteca padrao e o pacote painel/, e rodam ANTES das
# importacoes pesadas (selenium, speech_recognition, pyttsx3): a janela abre em ~1 s.
#
# Papeis do jairo.py:
#   (sem argumentos)    lancador: abre a janela e libera o terminal na hora
#   --janela            janela do painel (inicia o motor se ele nao estiver rodando)
#   --motor             motor: microfone, voz, WhatsApp e servidor do painel, sem console
#   --terminal          motor em primeiro plano, com logs no console (modo classico)
#   --autostart         motor iniciado com o Windows (sem janela)
#   --sem-painel        motor sem servidor do painel (comportamento anterior)
#   --texto             modo texto (simulado); o painel so com --com-painel

_PASTA_SCRIPT = Path(__file__).resolve().parent
CAMINHO_LOG = _PASTA_SCRIPT / "jairo.log"

# O pacote painel/ fica ao lado do jairo.py (somente biblioteca padrao).
if str(_PASTA_SCRIPT) not in sys.path:
    sys.path.insert(0, str(_PASTA_SCRIPT))
try:
    from painel import (
        Contexto,
        EditorContatos,
        EditorPermitidos,
        Hub,
        ListaApps,
        LogStream,
        ServidorPainel,
        descoberta as _descoberta,
    )
    PAINEL_DISPONIVEL = True
except Exception:  # pragma: no cover - painel ausente ou quebrado: o Jairo roda sem ele
    _descoberta = None
    PAINEL_DISPONIVEL = False

try:  # o .env precisa estar carregado antes de decidir o papel (JAIRO_PAINEL)
    from dotenv import load_dotenv as _load_dotenv_boot
    _load_dotenv_boot()
except Exception:  # pragma: no cover
    pass

_TITULO_JANELA = "Jairo Studio"
_FLAGS_MOTOR = frozenset([
    "--motor", "--autostart", "--terminal", "--texto", "--sem-painel",
    "--testar-voz", "--testar-mic",
    "--instalar-inicio", "--remover-inicio", "--status-inicio",
])
_MUTEXES: dict[str, object] = {}


def _registrar_boot(texto: str) -> None:
    """Linha no jairo.log (mesmo formato do logger) para os papeis leves."""
    try:
        with open(CAMINHO_LOG, "a", encoding="utf-8") as arquivo:
            arquivo.write(
                f"{time.strftime('%H:%M:%S')} | {'INFO':<8} | {'MainThread':<22} | {texto}\n"
            )
    except OSError:
        pass


def _aviso(titulo: str, texto: str) -> None:
    """Mostra um erro ao usuario mesmo sem console (pythonw)."""
    _registrar_boot(f"{titulo}: {texto}")
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, texto, titulo, 0x10)
            return
        except Exception:
            pass
    if sys.stderr is not None:
        print(f"{titulo}: {texto}", file=sys.stderr)


def _mutex_unico(nome: str) -> bool:
    """True se esta e a primeira instancia a criar o mutex `nome` (somente Windows)."""
    if sys.platform != "win32":
        return True
    import ctypes
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    _MUTEXES[nome] = kernel32.CreateMutexW(None, False, nome)
    return ctypes.get_last_error() != 183  # ERROR_ALREADY_EXISTS


def _focar_janela_existente() -> bool:
    """Traz para a frente a janela do painel ja aberta (somente Windows)."""
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        user32.FindWindowW.restype = wintypes.HWND
        user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
        user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        hwnd = user32.FindWindowW(None, _TITULO_JANELA)
        if not hwnd:
            return False
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        user32.SetForegroundWindow(hwnd)
        return True
    except Exception:
        return False


def _executavel_sem_console() -> str:
    python = Path(sys.executable)
    if sys.platform == "win32":
        pythonw = python.with_name("pythonw.exe")
        if pythonw.exists():
            return str(pythonw)
    return str(python)


def _lancar_destacado(argumentos: list[str]) -> bool:
    """Inicia outro processo do Jairo, sem console e independente deste."""
    comando = [_executavel_sem_console(), str(Path(__file__).resolve()), *argumentos]
    opcoes: dict = {}
    if sys.platform == "win32":
        # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        opcoes["creationflags"] = 0x00000008 | 0x00000200
    else:
        opcoes["start_new_session"] = True
    try:
        subprocess.Popen(
            comando,
            cwd=str(_PASTA_SCRIPT),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            **opcoes,
        )
        return True
    except OSError as exc:
        _registrar_boot(f"Falha ao iniciar {argumentos}: {exc}")
        return False


def _garantir_motor(timeout: float = 45.0) -> "dict | None":
    """Dados de um motor do Jairo em execucao; inicia um (e espera) se nao houver."""
    if not PAINEL_DISPONIVEL:
        return None
    dados = _descoberta.localizar()
    if dados is not None:
        return dados
    _registrar_boot("Motor do Jairo nao encontrado; iniciando.")
    if not _lancar_destacado(["--motor"]):
        return None
    limite = monotonic() + timeout
    while monotonic() < limite:
        dados = _descoberta.localizar(timeout=1.0)
        if dados is not None:
            return dados
        time.sleep(0.3)
    return None


def _janela_webview(webview, url: str) -> None:
    """Janela nativa (pywebview). Bloqueia ate o usuario fechar a janela."""

    class Api:
        # Atributos com _ nao sao expostos ao JavaScript.
        def __init__(self) -> None:
            self._janela = None

        def iniciar_chasame(self) -> dict:
            """Botao 'Iniciar' da interface quando o Jairo esta desligado."""
            dados = _garantir_motor()
            if dados is None:
                return {"ok": False}
            if self._janela is not None:
                self._janela.load_url(_descoberta.url_painel(dados))
            return {"ok": True}

    api = Api()
    api._janela = webview.create_window(
        _TITULO_JANELA, url, js_api=api, width=1120, height=780,
        min_size=(840, 600), background_color="#0B0B0C",
    )
    webview.start()


def _abrir_janela(dados: dict) -> None:
    url = _descoberta.url_painel(dados)
    try:
        import webview  # pip install pywebview (opcional)
    except ImportError:
        webview = None
    if webview is not None:
        try:
            _janela_webview(webview, url)
            return
        except Exception as exc:
            _registrar_boot(f"pywebview falhou ({exc}); usando o navegador.")
    webbrowser.open(url)


def _papel_janela() -> None:
    if not PAINEL_DISPONIVEL:
        _aviso("Jairo", "A pasta painel/ nao foi encontrada ao lado do jairo.py.")
        return
    if not _mutex_unico("Local\\JairoJanela"):
        _focar_janela_existente()
        return
    dados = _garantir_motor()
    if dados is None:
        _aviso("Jairo", "Nao consegui iniciar o Jairo. Veja o arquivo jairo.log.")
        return
    _abrir_janela(dados)


def _papel_inicial(args: list[str]) -> str:
    """'janela', 'lancador' ou 'motor'."""
    if "--janela" in args:
        return "janela"
    if _FLAGS_MOTOR.intersection(args):
        return "motor"
    habilitado = os.getenv("JAIRO_PAINEL", "true").strip().lower() == "true"
    if not (PAINEL_DISPONIVEL and habilitado and (_PASTA_SCRIPT / "ui" / "index.html").is_file()):
        return "motor"
    return "lancador"


def _boot() -> None:
    if __name__ != "__main__":
        return
    args = sys.argv[1:]
    papel = _papel_inicial(args)
    if papel == "janela":
        _papel_janela()
        sys.exit(0)
    if papel == "lancador":
        if sys.stdout is not None:
            print("Abrindo o painel do Jairo...", flush=True)
        if not _lancar_destacado(["--janela"]):
            _aviso("Jairo", "Nao consegui abrir a janela do painel.")
        sys.exit(0)


_boot()

import pyttsx3
import speech_recognition as sr
from dotenv import load_dotenv
from selenium import webdriver
from selenium.common.exceptions import (
    NoSuchElementException,
    StaleElementReferenceException,
    TimeoutException,
    UnexpectedAlertPresentException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

try:
    import winsound  # bipes de feedback (somente Windows)
except ImportError:  # pragma: no cover
    winsound = None

try:
    import warnings
    with warnings.catch_warnings():  # audioop e marcado como obsoleto no Python 3.12
        warnings.simplefilter("ignore", DeprecationWarning)
        import audioop  # ganho automatico (dependencia do speech_recognition)
except ImportError:  # pragma: no cover
    audioop = None

try:  # icone na bandeja (opcional)
    import pystray
    from PIL import Image, ImageDraw, ImageFont
except Exception:  # pragma: no cover
    pystray = None
    Image = ImageDraw = ImageFont = None


# ==============================================================
#  LOGGING
# ==============================================================

def _configurar_logging() -> logging.Logger:
    logger = logging.getLogger("jairo")
    logger.setLevel(logging.DEBUG)

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(threadName)-22s | %(message)s",
        datefmt="%H:%M:%S",
    )

    # Sem console (pythonw, iniciado com o Windows): sys.stdout e None.
    if sys.stdout is not None:
        console = logging.StreamHandler(sys.stdout)
        console.setLevel(logging.INFO)
        console.setFormatter(fmt)
        logger.addHandler(console)

    # Caminho absoluto: ao iniciar com o Windows o diretorio atual nao e o do projeto.
    arquivo = RotatingFileHandler(
        str(CAMINHO_LOG),
        maxBytes=2_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    arquivo.setLevel(logging.DEBUG)
    arquivo.setFormatter(fmt)

    logger.addHandler(arquivo)
    return logger


logger = _configurar_logging()


def _mascarar_numero(numero: str) -> str:
    if len(numero) <= 4:
        return "*" * len(numero)
    return f"{'*' * (len(numero) - 4)}{numero[-4:]}"


# ==============================================================
#  CONFIGURACAO (.env)
# ==============================================================

load_dotenv()


@dataclass(frozen=True)
class Config:
    # Paths
    caminho_projeto: Path = field(
        default_factory=lambda: Path(os.getenv("JAIRO_DIR", r"C:\09projec"))
    )
    caminho_brave: Path = field(
        default_factory=lambda: Path(
            os.getenv(
                "BRAVE_PATH",
                r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
            )
        )
    )

    # Comportamento
    modo_debug: bool = field(
        default_factory=lambda: os.getenv("JAIRO_DEBUG", "false").lower() == "true"
    )
    page_load_timeout: int = field(
        default_factory=lambda: int(os.getenv("PAGE_LOAD_TIMEOUT", "30"))
    )
    element_timeout: int = field(
        default_factory=lambda: int(os.getenv("ELEMENT_TIMEOUT", "20"))
    )
    intervalo_auto_responder: int = field(
        default_factory=lambda: int(os.getenv("AUTO_RESPONDER_INTERVAL", "45"))
    )
    intervalo_minimo_envio: float = field(
        default_factory=lambda: float(os.getenv("MIN_SEND_INTERVAL", "3.0"))
    )
    capacidade_fila_wpp: int = field(
        default_factory=lambda: int(os.getenv("WPP_QUEUE_SIZE", "50"))
    )

    # Palavra de ativacao
    exigir_wake_word: bool = field(
        default_factory=lambda: os.getenv("JAIRO_EXIGIR_WAKE", "true").lower() == "true"
    )
    wake_aliases: tuple[str, ...] = field(
        default_factory=lambda: tuple(
            a.strip().lower()
            for a in os.getenv("JAIRO_WAKE_ALIASES", "jairo,jairó,jairu,jayro").split(",")
            if a.strip()
        )
        or ("jairo",)
    )

    # Voz: auto | pyttsx3 | powershell
    tts_backend: str = field(
        default_factory=lambda: os.getenv("JAIRO_TTS", "auto").strip().lower()
    )

    # Leitura de nao lidas: maximo de conversas lidas em voz alta
    max_chats_leitura: int = field(
        default_factory=lambda: int(os.getenv("JAIRO_MAX_CHATS_LEITURA", "5"))
    )

    # Latencia de escuta
    pause_threshold: float = field(
        default_factory=lambda: float(os.getenv("JAIRO_PAUSE", "0.8"))
    )
    phrase_time_limit: int = field(
        default_factory=lambda: int(os.getenv("JAIRO_PHRASE_LIMIT", "6"))
    )
    calibracao_seg: float = field(
        default_factory=lambda: float(os.getenv("JAIRO_CALIBRACAO", "1.5"))
    )

    # Sensibilidade do microfone (RMS int16; use --testar-mic para medir)
    energy_min: int = field(
        default_factory=lambda: int(os.getenv("JAIRO_ENERGY_MIN", "120"))
    )
    energy_max: int = field(
        default_factory=lambda: int(os.getenv("JAIRO_ENERGY_MAX", "900"))
    )
    energy_fixo: int = field(  # > 0: ignora a calibracao e usa este valor
        default_factory=lambda: int(os.getenv("JAIRO_ENERGY", "0"))
    )
    ganho_max: float = field(  # 1.0 desativa o ganho automatico
        default_factory=lambda: float(os.getenv("JAIRO_GANHO_MAX", "4.0"))
    )
    alvo_rms: int = field(
        default_factory=lambda: int(os.getenv("JAIRO_ALVO_RMS", "2500"))
    )

    # WhatsApp opcional (false: assistente so de voz, sem abrir o Brave)
    wpp_habilitado: bool = field(
        default_factory=lambda: os.getenv("JAIRO_WPP", "true").lower() == "true"
    )
    # Mensagens agendadas vencidas ha mais que isto (com o Jairo desligado) sao descartadas
    agenda_tolerancia_min: int = field(
        default_factory=lambda: int(os.getenv("JAIRO_AGENDA_TOLERANCIA", "15"))
    )

    # Energia e inicializacao
    atraso_suspensao: int = field(  # segundos para cancelar a suspensao
        default_factory=lambda: int(os.getenv("JAIRO_SUSPENDER_SEG", "20"))
    )
    bandeja: bool = field(
        default_factory=lambda: os.getenv("JAIRO_BANDEJA", "true").lower() == "true"
    )
    atraso_inicio: int = field(  # espera ao iniciar com o Windows (audio e rede prontos)
        default_factory=lambda: int(os.getenv("JAIRO_ATRASO_INICIO", "20"))
    )

    # Modo silencioso: confirmacoes viram bipes (respostas importantes continuam faladas)
    modo_silencioso: bool = field(
        default_factory=lambda: os.getenv("JAIRO_SILENCIOSO", "false").lower() == "true"
    )

    # Painel grafico
    painel_habilitado: bool = field(
        default_factory=lambda: os.getenv("JAIRO_PAINEL", "true").strip().lower() == "true"
    )
    janela_no_inicio: bool = field(  # abrir a janela tambem quando iniciado com o Windows
        default_factory=lambda: os.getenv("JAIRO_JANELA_NO_INICIO", "false").strip().lower() == "true"
    )

    @property
    def caminho_perfil(self) -> Path:
        return self.caminho_projeto / "perfil_jairo"

    @property
    def caminho_auth(self) -> Path:
        return self.caminho_projeto / "autenticado.txt"

    @property
    def caminho_contatos(self) -> Path:
        return self.caminho_projeto / "contatos.txt"

    @property
    def caminho_permitidos(self) -> Path:
        return self.caminho_projeto / "permitidos.txt"

    @property
    def caminho_db(self) -> Path:
        return self.caminho_projeto / "jairo.db"


CFG = Config()


# ==============================================================
#  UTILITARIOS DE TEXTO
# ==============================================================

_PHONE_RE = re.compile(r"^[1-9]\d{9,14}$")

# Mesmos separadores de linha de str.splitlines(), que a Agenda usa ao ler.
_FINS_LINHA = "\r\n\x0b\x0c\x1c\x1d\x1e\x85\u2028\u2029"


def _normalizar_nome(nome: str) -> str:
    """Normaliza unicode, colapsa espacos, aplica casefold."""
    nome = unicodedata.normalize("NFKC", nome)
    return " ".join(nome.strip().casefold().split())


def _sem_acentos(texto: str) -> str:
    """Remove acentos, colapsa espacos e aplica casefold. Usado so para casar gatilhos."""
    decomposto = unicodedata.normalize("NFKD", texto)
    sem = "".join(c for c in decomposto if not unicodedata.combining(c))
    return " ".join(sem.casefold().split())


def _plural(n: int, singular: str, plural: str) -> str:
    return f"{n} {singular if n == 1 else plural}"


def _limpar_para_fala(texto: str, limite: int = 120) -> str:
    """Remove emojis/simbolos e limita o tamanho para leitura por TTS."""
    texto = re.sub(r"\s+", " ", texto).strip()
    texto = re.sub(r"[^\w\s.,!?:;()@%/'\"-]", "", texto)
    return texto[:limite].strip()


def _gravar_atomico(caminho: Path, dados: bytes, backup: bool = True) -> bool:
    """
    Grava em um arquivo temporario na mesma pasta e troca com os.replace: o
    arquivo nunca fica pela metade. backup=True guarda a versao anterior em
    <nome>.bak. Retorna False, sem tocar em nada, se o conteudo ja e identico.
    Levanta OSError se nao conseguir gravar (por exemplo, arquivo em uso).
    """
    caminho = Path(caminho)
    try:
        atual = caminho.read_bytes()
    except FileNotFoundError:
        atual = None
    if atual == dados:
        return False

    caminho.parent.mkdir(parents=True, exist_ok=True)
    temporario = caminho.with_name(f".{caminho.name}.{os.getpid()}.tmp")
    try:
        with open(temporario, "wb") as arquivo:
            arquivo.write(dados)
            arquivo.flush()
            os.fsync(arquivo.fileno())
        if backup and atual is not None:
            shutil.copyfile(caminho, caminho.with_name(caminho.name + ".bak"))
        ultimo: Exception | None = None
        for _ in range(3):
            try:
                os.replace(temporario, caminho)
                return True
            except PermissionError as exc:
                ultimo = exc
                time.sleep(0.1)
        raise OSError(f"{caminho.name} esta em uso por outro programa") from ultimo
    finally:
        try:
            temporario.unlink()
        except OSError:
            pass


def _validar_apelido(apelido: str) -> None:
    """Levanta ValueError (com mensagem falavel) se o apelido nao puder ir ao contatos.txt."""
    if not apelido:
        raise ValueError("Não entendi o apelido.")
    if len(apelido) > 60:
        raise ValueError("Apelido longo demais. Use até 60 caracteres.")
    if ":" in apelido or "," in apelido or any(c in _FINS_LINHA for c in apelido):
        raise ValueError("O apelido não pode ter vírgula nem dois-pontos.")


# ==============================================================
#  PALAVRA DE ATIVACAO
# ==============================================================

_WAKE_RE = re.compile(
    r"^\s*(?:(?:ei|oi|ol[aá]|ok|opa|fala|e\s+a[ií])[\s,]+)?"
    r"(?:" + "|".join(re.escape(a) for a in CFG.wake_aliases) + r")\b"
    r"[\s,.:;!?-]*(.*)$",
    re.IGNORECASE | re.DOTALL,
)


# Alterado em main() no modo texto, onde a palavra de ativacao e opcional.
_EXIGIR_WAKE: bool = CFG.exigir_wake_word


def _extrair_comando(texto: str) -> str | None:
    """
    Remove a palavra de ativacao do inicio e retorna o restante do comando.
    Retorna None se a palavra de ativacao for exigida e nao estiver presente.
    Retorna string vazia se o usuario disse apenas "jairo".
    """
    texto = texto.strip()
    achado = _WAKE_RE.match(texto)
    if achado:
        return achado.group(1).strip()
    return None if _EXIGIR_WAKE else texto


# ==============================================================
#  DOMINIO: CONTATOS
# ==============================================================

@dataclass(frozen=True)
class Contato:
    nome: str
    numero: str
    aliases: tuple[str, ...] = ()


class ContatoAmbiguo(LookupError):
    """Mais de um contato ativo corresponde ao nome falado."""

    def __init__(self, nome: str, candidatos: list[Contato]) -> None:
        self.candidatos = candidatos
        super().__init__(
            f"Nome ambiguo {nome!r}: " + ", ".join(c.nome for c in candidatos)
        )


class Agenda:
    """
    Carrega contatos.txt na inicializacao e valida todos os numeros.

    Formato do arquivo:
        # comentario
        Nome Completo:5511999998888
        Nome Completo:5511999998888:apelido1,apelido2
        !Nome Antigo:5511999990000          (prefixo ! desativa o contato)

    Resolucao do nome falado (sem acentos, sem diferenciar maiusculas):
      1. Apelido exato: prioridade maxima, e a escolha explicita do usuario.
      2. Todos os termos falados presentes no nome do contato. Se mais de um
         contato ativo casar, levanta ContatoAmbiguo em vez de adivinhar.

    As regras do arquivo vivem em _interpretar(), que coleta TODOS os erros:
    o carregamento levanta o primeiro; o painel (EditorContatos) mostra todos.
    recarregar() e seguro entre threads: os dados sao trocados de uma vez.
    """

    def __init__(self, caminho: Path) -> None:
        self._caminho = Path(caminho)
        self._lock = threading.RLock()
        # (contatos por nome normalizado, apelidos por chave sem acentos). Trocado
        # de uma vez em recarregar(): leitores nunca veem metade de cada.
        self._dados: tuple[dict[str, Contato], dict[str, Contato]] = ({}, {})
        self._permitidos_cache: frozenset[str] = frozenset()
        self._permitidos_mtime: float = -1.0
        self._carregar()

    # ----------------------------------------------------------
    #  LEITURA DO ARQUIVO
    # ----------------------------------------------------------

    @property
    def _contatos(self) -> dict[str, Contato]:
        return self._dados[0]

    @property
    def _aliases(self) -> dict[str, Contato]:
        return self._dados[1]

    @staticmethod
    def _interpretar(
        texto: str,
    ) -> tuple[list[tuple[int, str]], dict[str, Contato], dict[str, Contato], int]:
        """
        Aplica as regras do contatos.txt. Retorna (erros, contatos_ativos,
        apelidos, quantidade_de_inativos); erros = [(numero_da_linha, mensagem)].
        As mensagens sao as do analisador de referencia do painel.
        """
        erros: list[tuple[int, str]] = []
        vistos: set[str] = set()
        contatos: dict[str, Contato] = {}
        apelidos_por_chave: dict[str, Contato] = {}
        inativos = 0

        for numero_linha, linha in enumerate(texto.splitlines(), start=1):
            linha = linha.strip()
            if not linha or linha.startswith("#"):
                continue

            ativo = not linha.startswith("!")
            if not ativo:
                linha = linha[1:].strip()

            partes = [p.strip() for p in linha.split(":")]
            if len(partes) not in (2, 3) or not partes[0]:
                erros.append((numero_linha, f"linha inválida: {linha!r}"))
                continue
            nome_raw, numero = partes[0], partes[1]
            aliases = (
                tuple(a for a in (x.strip() for x in partes[2].split(",")) if a)
                if len(partes) == 3
                else ()
            )
            chave = _normalizar_nome(nome_raw)

            if not _PHONE_RE.fullmatch(numero):
                erros.append((numero_linha, f"número inválido {numero!r}"))
                continue
            if chave in vistos:
                erros.append((numero_linha, f"contato duplicado {nome_raw!r}"))
                continue
            vistos.add(chave)

            if not ativo:
                inativos += 1
                continue

            contato = Contato(nome=nome_raw, numero=numero, aliases=aliases)
            contatos[chave] = contato
            for alias in aliases:
                chave_alias = _sem_acentos(alias)
                dono = apelidos_por_chave.get(chave_alias)
                if dono is not None and dono is not contato:
                    erros.append((numero_linha, f"apelido duplicado {alias!r}"))
                else:
                    apelidos_por_chave[chave_alias] = contato

        return erros, contatos, apelidos_por_chave, inativos

    @staticmethod
    def analisar_texto(texto: str) -> list[tuple[int, str]]:
        """Todos os erros de um contatos.txt: [(numero_da_linha, mensagem)]."""
        return Agenda._interpretar(texto)[0]

    @classmethod
    def de_texto(cls, texto: str) -> "Agenda":
        """Agenda em memoria (sem arquivo): usada para simular uma edicao no painel."""
        erros, contatos, apelidos, _ = cls._interpretar(texto)
        if erros:
            numero, mensagem = erros[0]
            raise ValueError(f"contatos.txt linha {numero}: {mensagem}")
        agenda = cls.__new__(cls)
        agenda._caminho = Path()
        agenda._lock = threading.RLock()
        agenda._dados = (contatos, apelidos)
        agenda._permitidos_cache = frozenset()
        agenda._permitidos_mtime = -1.0
        return agenda

    def _carregar(self) -> None:
        caminho = self._caminho
        if not caminho.exists():
            caminho.parent.mkdir(parents=True, exist_ok=True)
            caminho.write_text(
                "# Formato: Nome:5511999998888[:apelido1,apelido2]  "
                "(DDI+DDD+numero, sem + ou espacos)\n"
                "# Prefixo ! desativa um contato antigo: !Fulano Antigo:5511999990000\n",
                encoding="utf-8",
            )
            logger.warning("Arquivo de contatos criado vazio: %s", caminho)
        self.recarregar()

    def recarregar(self) -> None:
        """
        Le o contatos.txt de novo. Se tiver erro, levanta ValueError com a
        primeira linha problematica e MANTEM a agenda anterior em memoria.
        """
        with self._lock:
            try:
                texto = self._caminho.read_bytes().decode("utf-8-sig")
            except FileNotFoundError:
                texto = ""
            except UnicodeDecodeError as exc:
                raise ValueError("contatos.txt não está em UTF-8.") from exc

            erros, contatos, apelidos, inativos = self._interpretar(texto)
            if erros:
                numero, mensagem = erros[0]
                raise ValueError(f"contatos.txt linha {numero}: {mensagem}")

            self._dados = (contatos, apelidos)

        logger.info(
            "Agenda carregada: %d contato(s) ativo(s), %d inativo(s).",
            len(contatos),
            inativos,
        )

    # ----------------------------------------------------------
    #  CONSULTA
    # ----------------------------------------------------------

    def contatos_ativos(self) -> list[Contato]:
        return list(self._dados[0].values())

    def dono_do_apelido(self, apelido: str) -> Contato | None:
        return self._dados[1].get(_sem_acentos(apelido))

    def buscar_todos(self, nome: str) -> list[Contato]:
        """Contatos que casam com o nome falado (apelido tem prioridade)."""
        contatos, aliases = self._dados
        chave = _sem_acentos(nome)
        if not chave:
            return []
        if chave in aliases:
            return [aliases[chave]]
        termos = set(chave.split())
        return [
            c for c in contatos.values()
            if termos <= set(_sem_acentos(c.nome).split())
        ]

    def buscar(self, nome: str) -> Contato:
        """
        Levanta LookupError se nao encontrado e ContatoAmbiguo (subclasse)
        se mais de um contato ativo corresponder.
        """
        achados = self.buscar_todos(nome)
        if not achados:
            raise LookupError(f"Contato nao encontrado na agenda: {nome!r}")
        if len(achados) > 1:
            raise ContatoAmbiguo(nome, achados)
        return achados[0]

    # ----------------------------------------------------------
    #  APELIDOS APRENDIDOS POR VOZ
    # ----------------------------------------------------------

    def adicionar_apelido(self, contato: Contato, apelido: str) -> str:
        """
        Acrescenta `apelido` a linha do contato em contatos.txt (guardando a
        versao anterior em contatos.txt.bak) e recarrega a agenda. Preserva
        comentarios, linhas em branco, quebras de linha e BOM. Retorna o
        apelido gravado.

        Levanta ValueError (mensagem falavel) se o apelido for invalido ou
        conflitar com outro contato, e OSError se nao conseguir gravar.
        """
        apelido = " ".join(apelido.split())
        _validar_apelido(apelido)

        with self._lock:
            chave = _sem_acentos(apelido)
            if chave == _sem_acentos(contato.nome):
                raise ValueError(f"{apelido} já é o nome de {contato.nome}.")
            dono = self.dono_do_apelido(apelido)
            if dono is not None:
                raise ValueError(f"{apelido} já é apelido de {dono.nome}.")

            try:
                bruto = self._caminho.read_bytes()
            except FileNotFoundError:
                raise ValueError("Não encontrei o arquivo contatos.txt.") from None
            tem_bom = bruto.startswith(b"\xef\xbb\xbf")
            try:
                texto = bruto.decode("utf-8-sig")
            except UnicodeDecodeError:
                raise ValueError("O contatos.txt não está em UTF-8.") from None

            alvo = _normalizar_nome(contato.nome)
            linhas = texto.splitlines(keepends=True)
            achou = False
            for indice, bruta in enumerate(linhas):
                corpo = bruta.rstrip(_FINS_LINHA)
                eol = bruta[len(corpo):]
                limpa = corpo.strip()
                if not limpa or limpa.startswith(("#", "!")):
                    continue
                partes = [p.strip() for p in limpa.split(":")]
                if len(partes) not in (2, 3) or _normalizar_nome(partes[0]) != alvo:
                    continue
                existentes = (
                    [a for a in (x.strip() for x in partes[2].split(",")) if a]
                    if len(partes) == 3
                    else []
                )
                indentacao = corpo[: len(corpo) - len(corpo.lstrip())]
                novo_corpo = ":".join([partes[0], partes[1], ",".join(existentes + [apelido])])
                linhas[indice] = indentacao + novo_corpo + eol
                achou = True
                break
            if not achou:
                raise ValueError(
                    f"Não achei a linha de {contato.nome} no contatos.txt. "
                    "O arquivo mudou? Tente de novo."
                )

            novo_texto = "".join(linhas)
            erros = self._interpretar(novo_texto)[0]
            if erros:
                raise ValueError(f"Esse apelido geraria um erro no contatos.txt: {erros[0][1]}")

            dados = novo_texto.encode("utf-8")
            if tem_bom:
                dados = b"\xef\xbb\xbf" + dados
            _gravar_atomico(self._caminho, dados, backup=True)
            self.recarregar()

        logger.info("Apelido %r adicionado a %s.", apelido, contato.nome)
        return apelido

    # ----------------------------------------------------------
    #  PERMITIDOS (auto-responder)
    # ----------------------------------------------------------

    def invalidar_permitidos(self) -> None:
        """Forca a releitura do permitidos.txt na proxima consulta."""
        self._permitidos_mtime = -1.0

    def ler_permitidos(self) -> frozenset[str]:
        """Retorna chaves normalizadas do arquivo de permitidos (cache por mtime)."""
        caminho = CFG.caminho_permitidos
        if not caminho.exists():
            caminho.parent.mkdir(parents=True, exist_ok=True)
            caminho.write_text(
                "# Um nome por linha (exatamente como aparece no WhatsApp)\n",
                encoding="utf-8",
            )
            self._permitidos_cache = frozenset()
            self._permitidos_mtime = -1.0
            return self._permitidos_cache

        mtime = caminho.stat().st_mtime
        if mtime != self._permitidos_mtime:
            self._permitidos_cache = frozenset(
                _normalizar_nome(l)
                for l in caminho.read_text(encoding="utf-8-sig").splitlines()
                if l.strip() and not l.startswith("#")
            )
            self._permitidos_mtime = mtime
        return self._permitidos_cache


# ==============================================================
#  DOMINIO: RESULTADOS
# ==============================================================

class EstadoEnvio(Enum):
    INSERIDO_NA_INTERFACE  = "inserido_na_interface"
    CONFIRMADO_NA_CONVERSA = "confirmado_na_conversa"
    FALHOU                 = "falhou"
    FILA_CHEIA             = "fila_cheia"


@dataclass(frozen=True)
class ResultadoEnvio:
    estado: EstadoEnvio
    destinatario: str
    detalhe: str = ""


@dataclass(frozen=True)
class ChatNaoLido:
    """Snapshot de uma conversa nao lida (somente strings, sem WebElements)."""
    nome: str
    previa: str
    horario: str
    quantidade: int
    fingerprint: str


@dataclass(frozen=True)
class ResultadoVarredura:
    """
    detalhe vazio = varredura executada.
    Valores possiveis quando nao executou: driver_inativo, sem_permitidos,
    erro_varredura.
    """
    respondidos: int
    nao_lidos: int
    detalhe: str = ""


@dataclass(frozen=True)
class MensagemLida:
    texto: str
    horario: str = ""


@dataclass(frozen=True)
class ResultadoLeitura:
    chat: str
    mensagens: tuple[MensagemLida, ...]


# ==============================================================
#  EXCECOES DE DOMINIO
# ==============================================================

class DestinatarioInvalido(Exception):
    """Numero invalido ou contato nao encontrado. Nao retenta."""


class AutenticacaoNecessaria(Exception):
    """Sessao expirada. Nao retenta automaticamente."""


class MensagemVazia(ValueError):
    """Mensagem sem conteudo. Nao retenta."""


class ConversaAmbigua(LookupError):
    """Mais de uma conversa da lista lateral corresponde ao nome falado."""

    def __init__(self, nome: str, nomes: list[str]) -> None:
        self.nomes = nomes
        super().__init__(f"Nome ambiguo {nome!r}: " + ", ".join(nomes))


# ==============================================================
#  AGENDADOR DE ENVIOS (SQLite)
# ==============================================================

@dataclass(frozen=True)
class EnvioAgendado:
    id: int
    contato: str
    numero: str
    mensagem: str
    quando: float
    status: str = "pendente"


class Agendador:
    """
    Fila persistente de mensagens agendadas do WhatsApp (jairo.db, SQLite da
    biblioteca padrao). Quem EXECUTA os envios e a WhatsAppWorker; as demais
    threads apenas agendam, listam e cancelam.

    Mensagens vencidas ha mais de JAIRO_AGENDA_TOLERANCIA minutos enquanto o
    Jairo estava desligado sao marcadas como 'perdida' em vez de enviadas com
    atraso (um "boa noite" as 3h da manha, por exemplo).

    O banco guarda nomes, numeros e textos das mensagens: nao o publique.
    """

    def __init__(self, caminho: Path) -> None:
        self._caminho = caminho
        self._lock = threading.Lock()
        self._proxima: float | None = None
        caminho.parent.mkdir(parents=True, exist_ok=True)
        self._sql(
            "CREATE TABLE IF NOT EXISTS envios_agendados ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "contato TEXT NOT NULL, numero TEXT NOT NULL, mensagem TEXT NOT NULL, "
            "quando REAL NOT NULL, status TEXT NOT NULL DEFAULT 'pendente', "
            "criado_em REAL NOT NULL, detalhe TEXT NOT NULL DEFAULT '')"
        )
        self._atualizar_proxima()

    def _sql(self, comando: str, parametros: tuple = ()) -> tuple[list, int]:
        with self._lock:
            conexao = sqlite3.connect(str(self._caminho), timeout=5)
            try:
                conexao.row_factory = sqlite3.Row
                cursor = conexao.execute(comando, parametros)
                linhas = cursor.fetchall()
                conexao.commit()
                return linhas, cursor.lastrowid or 0
            finally:
                conexao.close()

    @staticmethod
    def _envio(linha) -> EnvioAgendado:
        return EnvioAgendado(
            id=linha["id"],
            contato=linha["contato"],
            numero=linha["numero"],
            mensagem=linha["mensagem"],
            quando=linha["quando"],
            status=linha["status"],
        )

    def _atualizar_proxima(self) -> None:
        linhas, _ = self._sql(
            "SELECT MIN(quando) AS m FROM envios_agendados WHERE status = 'pendente'"
        )
        valor = linhas[0]["m"] if linhas else None
        self._proxima = float(valor) if valor is not None else None

    def proxima_ts(self) -> float | None:
        """Instante (epoch) do proximo envio pendente; consulta barata, sem banco."""
        return self._proxima

    def agendar(self, contato: Contato, mensagem: str, quando: datetime) -> int:
        _, novo_id = self._sql(
            "INSERT INTO envios_agendados (contato, numero, mensagem, quando, criado_em) "
            "VALUES (?, ?, ?, ?, ?)",
            (contato.nome, contato.numero, mensagem, quando.timestamp(), time.time()),
        )
        self._atualizar_proxima()
        return novo_id

    def pendentes(self) -> list[EnvioAgendado]:
        linhas, _ = self._sql(
            "SELECT * FROM envios_agendados WHERE status = 'pendente' ORDER BY quando"
        )
        return [self._envio(l) for l in linhas]

    def devidos(self, agora: float) -> list[EnvioAgendado]:
        linhas, _ = self._sql(
            "SELECT * FROM envios_agendados WHERE status = 'pendente' AND quando <= ? "
            "ORDER BY quando",
            (agora,),
        )
        return [self._envio(l) for l in linhas]

    def marcar(self, envio_id: int, status: str, detalhe: str = "") -> None:
        self._sql(
            "UPDATE envios_agendados SET status = ?, detalhe = ? WHERE id = ?",
            (status, detalhe[:200], envio_id),
        )
        self._atualizar_proxima()

    def cancelar(self, nome: str | None = None) -> int:
        """Cancela todos os pendentes, ou so os de contatos que casam com o nome."""
        alvo = self.pendentes()
        if nome:
            termos = set(_sem_acentos(nome).split())
            alvo = [
                e for e in alvo
                if termos <= set(_sem_acentos(e.contato).split())
            ]
        for envio in alvo:
            self._sql(
                "UPDATE envios_agendados SET status = 'cancelada' "
                "WHERE id = ? AND status = 'pendente'",
                (envio.id,),
            )
        self._atualizar_proxima()
        return len(alvo)

    def expirar_perdidas(self, agora: float, tolerancia_seg: float) -> list[EnvioAgendado]:
        linhas, _ = self._sql(
            "SELECT * FROM envios_agendados WHERE status = 'pendente' AND quando < ?",
            (agora - tolerancia_seg,),
        )
        perdidas = [self._envio(l) for l in linhas]
        for envio in perdidas:
            self.marcar(envio.id, "perdida", "Jairo desligado no horario agendado.")
        return perdidas


# ==============================================================
#  LIMITADOR DE FREQUENCIA
# ==============================================================

class LimitadorEnvio:
    """
    Garante intervalo minimo global entre envios consecutivos.
    Adiciona jitter aleatorio de ate 0.5s para comportamento menos previsivel.
    """

    def __init__(self, intervalo_global: float = CFG.intervalo_minimo_envio) -> None:
        self._intervalo = intervalo_global
        self._ultimo_envio: float = 0.0
        self._lock = threading.Lock()

    def aguardar(self) -> None:
        with self._lock:
            agora = monotonic()
            restante = self._intervalo - (agora - self._ultimo_envio)
            if restante > 0:
                time.sleep(restante + random.uniform(0.0, 0.5))
            self._ultimo_envio = monotonic()


# ==============================================================
#  SELETORES DO WHATSAPP WEB
# ==============================================================

# Ordenados por estabilidade historica: data-testid > role ARIA > estrutural > generico.
_CSS_COMPOSITOR: list[str] = [
    "div[data-testid='conversation-text-input']",
    "footer div[contenteditable='true'][role='textbox']",
    "footer div[contenteditable='true'][data-tab]",
    "div[contenteditable='true'][role='textbox']",
    "div[contenteditable='true'][data-tab='10']",
]

_XPATH_COMPOSITOR: list[str] = [
    "//div[@contenteditable='true' and @data-testid='conversation-text-input']",
    "//footer//div[@contenteditable='true' and @role='textbox']",
    "//footer//div[@contenteditable='true']",
]

_CSS_PAINEL_LATERAL: list[str] = [
    "div#pane-side",
    "div[data-testid='chatlist-panel']",
    "div[aria-label='Lista de conversas']",
]

_CSS_POPUP_FECHAR: list[str] = [
    "div[data-testid='popup-controls-ok']",
    "button[data-testid='confirm-popup-ok']",
    "div[role='button'][data-testid='btn-ok']",
]

# Indicador de nao lida dentro de um item da lista lateral.
_CSS_BADGE_NAO_LIDA: list[str] = [
    "span[data-testid='icon-unread-count']",
    "span[aria-label*='não lida']",
    "span[aria-label*='nao lida']",
    "span[aria-label*='unread']",
]

_CSS_PREVIA_CHAT = (
    "span[data-testid='last-msg-status'] + span, "
    "div[data-testid='last-message-preview']"
)

_CSS_BOLHA_SAIDA = "div.message-out"

_JS_NAVEGAR_CHAT = """
const numero = arguments[0];
const chatId = numero + '@c.us';
const store = window.Store;
if (!store || !store.Chat || !store.Cmd) { return false; }
const chat = store.Chat.get(chatId);
if (!chat) { return false; }
store.Cmd.openChatBottom(chat);
return true;
"""

# Utilitarios JS compartilhados: localizam os itens da lista lateral de forma
# tolerante a mudancas de DOM (listitem, row ou cell-frame-container).
_JS_ITENS_CHAT = r"""
function itensDaLista() {
  const painel = document.querySelector('#pane-side') || document;
  const itens = Array.from(painel.querySelectorAll(
    '[role="listitem"], [role="row"], [data-testid="cell-frame-container"]'
  ));
  return itens.filter(el => !itens.some(o => o !== el && el.contains(o)));
}
function nomeDoItem(item) {
  const t = item.querySelector('span[title]');
  if (t && t.getAttribute('title')) return t.getAttribute('title').trim();
  const s = item.querySelector('span[dir="auto"]');
  return s ? (s.textContent || '').trim() : '';
}
"""

_JS_COLETAR_NAO_LIDOS = _JS_ITENS_CHAT + r"""
const reRotulo = /n[aã]o\s*lidas?|unread/i;
const reHora = /^\d{1,2}:\d{2}$/;
const itens = itensDaLista();
const chats = [];
for (const item of itens) {
  let quantidade = 0;
  let achou = false;
  const candidatos = item.querySelectorAll(
    '[aria-label], [data-testid="icon-unread-count"]'
  );
  for (const el of candidatos) {
    const rotulo = el.getAttribute('aria-label') || '';
    const ehBadge = el.getAttribute('data-testid') === 'icon-unread-count';
    if (ehBadge || reRotulo.test(rotulo)) {
      achou = true;
      const m = (rotulo + ' ' + (el.textContent || '')).match(/\d+/);
      quantidade = m ? parseInt(m[0], 10) : 1;
      break;
    }
  }
  if (!achou) continue;

  const nome = nomeDoItem(item);
  if (!nome) continue;

  let previa = '';
  const ltr = item.querySelector('span[dir="ltr"]');
  if (ltr) previa = (ltr.textContent || '').trim();
  if (!previa || previa === nome) {
    const titulos = item.querySelectorAll('span[title]');
    previa = titulos.length > 1 ? (titulos[1].getAttribute('title') || '').trim() : '';
  }

  let horario = '';
  for (const el of item.querySelectorAll('div, span')) {
    const txt = (el.textContent || '').trim();
    if (el.children.length === 0 && reHora.test(txt)) { horario = txt; break; }
  }

  chats.push({nome: nome, previa: previa, horario: horario, quantidade: quantidade});
}
return {total: itens.length, chats: chats};
"""

_JS_ABRIR_CHAT_POR_NOME = _JS_ITENS_CHAT + r"""
const alvo = arguments[0];
for (const item of itensDaLista()) {
  if (nomeDoItem(item) !== alvo) continue;
  const el = item.querySelector('[data-testid="cell-frame-container"]') || item;
  ['mousedown', 'mouseup', 'click'].forEach(tipo =>
    el.dispatchEvent(new MouseEvent(tipo, {bubbles: true, cancelable: true, view: window}))
  );
  return true;
}
return false;
"""

_JS_DIAGNOSTICO = _JS_ITENS_CHAT + r"""
const seletores = [
  '#pane-side', '[role="listitem"]', '[role="row"]', '[role="grid"]',
  '[data-testid="cell-frame-container"]', '[data-testid="icon-unread-count"]',
  '[aria-label*="lida"]', '[aria-label*="unread"]', 'span[title]'
];
const contagens = {};
for (const s of seletores) contagens[s] = document.querySelectorAll(s).length;
const itens = itensDaLista();
return {
  url: location.href,
  contagens: contagens,
  total_itens: itens.length,
  amostra_html: itens.slice(0, 4).map(i => i.outerHTML.slice(0, 4000)),
  rotulos_aria: Array.from(document.querySelectorAll('#pane-side [aria-label]'))
    .slice(0, 40).map(e => e.getAttribute('aria-label'))
};
"""

_JS_NOMES_CHATS = _JS_ITENS_CHAT + r"""
return itensDaLista().map(nomeDoItem).filter(n => n);
"""

# Ultimas mensagens RECEBIDAS da conversa aberta (data-id "false_..." = nao enviada por mim).
_JS_ULTIMAS_RECEBIDAS = r"""
const quantidade = arguments[0] || 1;
const candidatos = Array.from(
  document.querySelectorAll('div[data-id^="false_"], div.message-in')
);
const mensagens = candidatos.filter(
  el => !candidatos.some(o => o !== el && el.contains(o))
);
function textoDe(el) {
  const spans = Array.from(el.querySelectorAll(
    'span.selectable-text, span[data-testid="selectable-text"]'
  ));
  const externos = spans.filter(s => !spans.some(o => o !== s && o.contains(s)));
  let texto = externos
    .map(s => (s.innerText || s.textContent || '').trim())
    .filter(Boolean)
    .join(' ');
  if (!texto) {
    if (el.querySelector('img, video, canvas')) texto = '[imagem ou video]';
    else if (el.querySelector('audio, [data-icon*="audio"], [data-icon*="ptt"]'))
      texto = '[mensagem de voz]';
    else texto = '[mensagem sem texto]';
  }
  return texto;
}
const ultimas = mensagens.slice(-quantidade).map(el => {
  const meta = el.querySelector('[data-pre-plain-text]');
  return {
    texto: textoDe(el),
    pre: meta ? (meta.getAttribute('data-pre-plain-text') || '') : ''
  };
});
return {mensagens: ultimas};
"""

# Botao de enviar da previa de midia (aparece depois de colar uma imagem).
_CSS_BOTAO_ENVIAR_MIDIA: list[str] = [
    "span[data-icon='send']",
    "[data-testid='send']",
    "div[aria-label='Enviar']",
    "button[aria-label='Enviar']",
    "div[aria-label='Send']",
    "button[aria-label='Send']",
]


# ==============================================================
#  UTILITARIOS SELENIUM
# ==============================================================

def _encontrar_elemento(
    driver: webdriver.Chrome,
    seletores_css: list[str],
    xpaths: list[str],
    timeout_total: float,
) -> webdriver.remote.webelement.WebElement:
    """
    Varre todos os seletores CSS e XPath dentro de um deadline global unico.
    Levanta TimeoutException se nenhum for encontrado no prazo.
    """
    deadline = monotonic() + timeout_total
    while monotonic() < deadline:
        for seletor in seletores_css:
            try:
                elementos = driver.find_elements(By.CSS_SELECTOR, seletor)
                for el in elementos:
                    try:
                        if el.is_displayed() and el.is_enabled():
                            logger.debug("Elemento localizado via CSS: %s", seletor)
                            return el
                    except StaleElementReferenceException:
                        continue
            except WebDriverException:
                continue

        for xpath in xpaths:
            try:
                elementos = driver.find_elements(By.XPATH, xpath)
                for el in elementos:
                    try:
                        if el.is_displayed() and el.is_enabled():
                            logger.debug("Elemento localizado via XPath: %s", xpath)
                            return el
                    except StaleElementReferenceException:
                        continue
            except WebDriverException:
                continue

        time.sleep(0.1)

    raise TimeoutException(
        f"Nenhum elemento encontrado em {timeout_total:.1f}s "
        f"({len(seletores_css)} CSS + {len(xpaths)} XPath)."
    )


def _aguardar_painel(driver: webdriver.Chrome, timeout: float = 180.0) -> None:
    deadline = monotonic() + timeout
    while monotonic() < deadline:
        for seletor in _CSS_PAINEL_LATERAL:
            try:
                elementos = driver.find_elements(By.CSS_SELECTOR, seletor)
                if elementos and elementos[0].is_displayed():
                    logger.info("Painel lateral do WhatsApp confirmado.")
                    return
            except WebDriverException:
                pass
        time.sleep(0.5)
    raise TimeoutException("Painel lateral nao carregou no prazo.")


def _dispensar_popups(driver: webdriver.Chrome) -> None:
    """Fecha alertas nativos e popups do WhatsApp Web que bloqueiam o fluxo."""
    try:
        alert = driver.switch_to.alert
        logger.warning("Alert nativo detectado: %r. Dispensando.", alert.text)
        alert.dismiss()
        time.sleep(0.3)
    except Exception:
        pass

    for seletor in _CSS_POPUP_FECHAR:
        try:
            botoes = driver.find_elements(By.CSS_SELECTOR, seletor)
            if botoes and botoes[0].is_displayed():
                botoes[0].click()
                logger.warning("Popup WA Web dispensado: %s", seletor)
                time.sleep(0.3)
                break
        except (NoSuchElementException, WebDriverException):
            continue


def _backoff(tentativa: int) -> float:
    """Backoff exponencial com jitter: min(30, 2^n) + uniform(0, 1)."""
    return min(30.0, 2.0 ** tentativa) + random.uniform(0.0, 1.0)


# ==============================================================
#  FINGERPRINT PARA AUTO-RESPONDER
# ==============================================================

def _criar_fingerprint(nome_chat: str, texto_previa: str, horario: str) -> str:
    conteudo = f"{nome_chat}|{texto_previa}|{horario}"
    return hashlib.sha256(conteudo.encode("utf-8")).hexdigest()


# ==============================================================
#  WHATSAPP SERVICE
# ==============================================================

@dataclass(frozen=True)
class _PedidoEnvio:
    contato: Contato
    mensagem: str
    future: Future


@dataclass(frozen=True)
class _PedidoVarredura:
    """Pede ao worker um ciclo imediato do auto-responder. Future -> ResultadoVarredura."""
    future: Future


@dataclass(frozen=True)
class _PedidoLeitura:
    """Pede ao worker a lista de conversas nao lidas. Future -> list[ChatNaoLido]."""
    future: Future


@dataclass(frozen=True)
class _PedidoDiagnostico:
    """Pede ao worker um dump do DOM da lista lateral. Future -> Path do arquivo."""
    future: Future


@dataclass(frozen=True)
class _PedidoLerChat:
    """Abre uma conversa e le as ultimas recebidas. Future -> ResultadoLeitura."""
    contato: Contato | None   # None: localiza pelo nome na lista lateral
    nome: str
    quantidade: int
    future: Future


@dataclass(frozen=True)
class _PedidoResponder:
    """Responde numa conversa da lista lateral. nome=None: unica conversa nao lida."""
    nome: str | None
    mensagem: str
    future: Future            # -> ResultadoEnvio


@dataclass(frozen=True)
class _PedidoImagem:
    """Cola a imagem da area de transferencia na conversa e envia. Future -> ResultadoEnvio."""
    contato: Contato
    future: Future


class WhatsAppService:
    """
    Servico de mensageria com WebDriver isolado em worker thread unica.

    Contrato:
      - O driver e criado, usado e encerrado EXCLUSIVAMENTE pela _worker_thread.
      - Todas as outras threads comunicam com o servico via fila
        (enviar(), varrer_agora(), listar_nao_lidos()).
      - O auto-responder e executado pela mesma worker thread em ciclos periodicos,
        garantindo acesso sequencial ao driver.
    """

    def __init__(
        self,
        agenda: Agenda,
        evento_saida: threading.Event,
        agendador: "Agendador | None" = None,
        habilitado: bool = True,
    ) -> None:
        self._agenda       = agenda
        self._evento_saida = evento_saida
        self._agendador    = agendador
        self._habilitado   = habilitado
        # notificar(texto, essencial): usado para avisar o resultado de envios agendados.
        self.notificar: "Callable[[str, bool], None] | None" = None
        self._driver: webdriver.Chrome | None = None
        self._autenticado  = False
        self._limitador    = LimitadorEnvio()
        self._mensagens_processadas: set[str] = set()

        self._fila: queue.Queue[
            _PedidoEnvio | _PedidoVarredura | _PedidoLeitura | _PedidoDiagnostico
            | _PedidoLerChat | _PedidoResponder | _PedidoImagem | None
        ] = queue.Queue(maxsize=CFG.capacidade_fila_wpp)

        self._worker_thread = threading.Thread(
            target=self._worker,
            name="WhatsAppWorker",
            daemon=False,
        )

    @property
    def disponivel(self) -> bool:
        return self._habilitado

    def iniciar(self) -> None:
        if not self._habilitado:
            logger.info("WhatsApp desativado (JAIRO_WPP=false ou modo texto).")
            return
        self._worker_thread.start()

    def encerrar(self) -> None:
        if self._worker_thread.ident is None:  # nunca iniciada
            return
        try:
            self._fila.put_nowait(None)
        except queue.Full:
            pass
        self._worker_thread.join(timeout=15)
        self._encerrar_driver()

    # ----------------------------------------------------------
    #  API PUBLICA (chamada de qualquer thread)
    # ----------------------------------------------------------

    def resolver_contato(self, nome: str) -> Contato:
        """Levanta LookupError / ContatoAmbiguo conforme a agenda."""
        return self._agenda.buscar(nome)

    def buscar_contatos(self, nome: str) -> list[Contato]:
        return self._agenda.buscar_todos(nome)

    def adicionar_apelido(self, contato: Contato, apelido: str) -> str:
        """Grava o apelido no contatos.txt (com backup). ValueError / OSError como em Agenda."""
        return self._agenda.adicionar_apelido(contato, apelido)

    def enviar(self, nome: str, mensagem: str) -> Future:
        """Resolve o nome na agenda e enfileira o envio. Future -> ResultadoEnvio."""
        try:
            contato = self._agenda.buscar(nome)
        except LookupError as erro:
            future: Future = Future()
            future.set_result(ResultadoEnvio(EstadoEnvio.FALHOU, nome, str(erro)))
            return future
        return self.enviar_para(contato, mensagem)

    def enviar_para(self, contato: Contato, mensagem: str) -> Future:
        """Enfileira um envio para um contato ja resolvido. Future -> ResultadoEnvio."""
        future: Future = Future()
        if not self._habilitado:
            future.set_result(
                ResultadoEnvio(EstadoEnvio.FALHOU, contato.nome, "O WhatsApp esta desligado.")
            )
            return future
        mensagem = mensagem.strip()

        if not mensagem:
            future.set_result(
                ResultadoEnvio(EstadoEnvio.FALHOU, contato.nome, "Mensagem vazia.")
            )
            return future

        logger.info(
            "Destinatario resolvido: %s (%s).",
            contato.nome,
            _mascarar_numero(contato.numero),
        )
        pedido = _PedidoEnvio(contato=contato, mensagem=mensagem, future=future)

        try:
            self._fila.put_nowait(pedido)
        except queue.Full:
            future.set_result(
                ResultadoEnvio(
                    EstadoEnvio.FILA_CHEIA,
                    contato.nome,
                    "Fila do WhatsApp cheia. Tente novamente.",
                )
            )
        return future

    def varrer_agora(self) -> Future:
        """
        Solicita um ciclo imediato do auto-responder (ignora a janela minima
        de 10 minutos; o fingerprint ainda evita resposta duplicada).
        Future -> ResultadoVarredura.
        """
        return self._enfileirar_interno(_PedidoVarredura(future=Future()))

    def listar_nao_lidos(self) -> Future:
        """
        Solicita a lista de conversas nao lidas sem abrir nenhum chat
        (portanto sem marcar como lidas). Future -> list[ChatNaoLido].
        """
        return self._enfileirar_interno(_PedidoLeitura(future=Future()))

    def diagnosticar_whatsapp(self) -> Future:
        """
        Grava wpp_diagnostico.json (contagem de seletores, HTML de amostra e
        resultado da coleta) na pasta do projeto. Future -> Path.
        """
        return self._enfileirar_interno(_PedidoDiagnostico(future=Future()))

    # --- mensagens agendadas (persistentes; executadas pela worker) ---

    def agendar_envio(self, contato: Contato, mensagem: str, quando: datetime) -> int:
        if not self._habilitado:
            raise ConnectionError("O WhatsApp esta desligado.")
        if self._agendador is None:
            raise RuntimeError("O agendador de mensagens nao esta disponivel.")
        return self._agendador.agendar(contato, mensagem.strip(), quando)

    def listar_agendados(self) -> list[EnvioAgendado]:
        return self._agendador.pendentes() if self._agendador else []

    def cancelar_agendados(self, nome: str | None = None) -> int:
        return self._agendador.cancelar(nome) if self._agendador else 0

    # --- conversas ---

    def ler_chat(self, contato: Contato | None, nome: str, quantidade: int = 1) -> Future:
        """Abre a conversa e le as ultimas mensagens recebidas (marca como lidas)."""
        return self._enfileirar_interno(
            _PedidoLerChat(
                contato=contato,
                nome=nome,
                quantidade=max(1, min(5, quantidade)),
                future=Future(),
            )
        )

    def responder(self, nome: str | None, mensagem: str) -> Future:
        """Responde numa conversa da lista lateral (nome=None: unica nao lida)."""
        return self._enfileirar_interno(
            _PedidoResponder(nome=nome, mensagem=mensagem.strip(), future=Future())
        )

    def enviar_imagem(self, contato: Contato) -> Future:
        """Cola a imagem da area de transferencia na conversa do contato e envia."""
        return self._enfileirar_interno(_PedidoImagem(contato=contato, future=Future()))

    def _enfileirar_interno(self, pedido) -> Future:
        if not self._habilitado:
            self._resolver(pedido.future, erro=ConnectionError("O WhatsApp esta desligado."))
            return pedido.future
        try:
            self._fila.put_nowait(pedido)
        except queue.Full:
            self._resolver(pedido.future, erro=queue.Full("Fila do WhatsApp cheia."))
        return pedido.future

    @staticmethod
    def _resolver(
        future: Future, valor: object = None, erro: BaseException | None = None
    ) -> None:
        if future.done():
            return
        try:
            if erro is not None:
                future.set_exception(erro)
            else:
                future.set_result(valor)
        except Exception:
            pass

    # ----------------------------------------------------------
    #  WORKER (unica thread com acesso ao driver)
    # ----------------------------------------------------------

    def _worker(self) -> None:
        try:
            self._conectar()
        except AutenticacaoNecessaria as exc:
            logger.error("%s", exc)

        ultimo_auto_responder = monotonic()

        while True:
            # Processa pedidos com timeout curto para checar saida.
            try:
                pedido = self._fila.get(timeout=1.0)
            except queue.Empty:
                pedido = None

            if pedido is None and self._evento_saida.is_set():
                logger.info("WhatsAppWorker encerrando.")
                break

            if pedido is not None:
                self._despachar(pedido)
                self._fila.task_done()

            # Mensagens agendadas vencidas (consulta em memoria; o banco so e lido quando vence).
            if self._agendador is not None:
                proxima = self._agendador.proxima_ts()
                if proxima is not None and time.time() >= proxima:
                    try:
                        self._executar_agendados()
                    except Exception:
                        logger.exception("Falha ao executar mensagens agendadas.")

            # Ciclo periodico do auto-responder.
            agora = monotonic()
            if agora - ultimo_auto_responder >= CFG.intervalo_auto_responder:
                try:
                    self._ciclo_auto_responder()
                except Exception:
                    logger.exception("Falha no ciclo periodico do auto-responder.")
                ultimo_auto_responder = monotonic()

    def _despachar(self, pedido: object) -> None:
        if isinstance(pedido, _PedidoEnvio):
            resultado = self._enviar_com_retry(pedido)
            self._resolver(pedido.future, resultado)

        elif isinstance(pedido, _PedidoVarredura):
            try:
                self._resolver(
                    pedido.future, self._ciclo_auto_responder(forcar=True)
                )
            except Exception as exc:
                logger.exception("Falha na varredura manual.")
                self._resolver(pedido.future, erro=exc)

        elif isinstance(pedido, _PedidoLeitura):
            try:
                self._resolver(pedido.future, self._ler_nao_lidos())
            except Exception as exc:
                logger.warning("Falha ao listar nao lidos: %s", exc)
                self._resolver(pedido.future, erro=exc)

        elif isinstance(pedido, _PedidoDiagnostico):
            try:
                self._resolver(pedido.future, self._diagnosticar())
            except Exception as exc:
                logger.warning("Falha no diagnostico: %s", exc)
                self._resolver(pedido.future, erro=exc)

        elif isinstance(pedido, _PedidoLerChat):
            try:
                self._resolver(pedido.future, self._ler_chat(pedido))
            except Exception as exc:
                logger.warning("Falha ao ler conversa: %s", exc)
                self._resolver(pedido.future, erro=exc)

        elif isinstance(pedido, _PedidoResponder):
            try:
                self._resolver(pedido.future, self._responder(pedido))
            except Exception as exc:
                logger.warning("Falha ao responder: %s", exc)
                self._resolver(pedido.future, erro=exc)

        elif isinstance(pedido, _PedidoImagem):
            try:
                self._resolver(pedido.future, self._enviar_imagem(pedido))
            except Exception as exc:
                logger.warning("Falha ao enviar imagem: %s", exc)
                self._resolver(pedido.future, erro=exc)

    # ----------------------------------------------------------
    #  DRIVER
    # ----------------------------------------------------------

    def _criar_driver(self, modo_visivel: bool) -> webdriver.Chrome:
        opcoes = webdriver.ChromeOptions()
        opcoes.binary_location = str(CFG.caminho_brave)
        opcoes.add_argument(f"--user-data-dir={CFG.caminho_perfil}")
        opcoes.add_argument("--window-size=1366,768")
        opcoes.add_argument("--disable-gpu")
        opcoes.add_argument("--disable-extensions")
        opcoes.add_argument("--disable-renderer-backgrounding")
        opcoes.add_argument("--disable-background-timer-throttling")
        opcoes.add_argument("--disable-backgrounding-occluded-windows")
        opcoes.add_argument("--force-device-scale-factor=1")
        opcoes.add_experimental_option(
            "excludeSwitches", ["enable-automation", "enable-logging"]
        )
        opcoes.add_experimental_option("useAutomationExtension", False)

        posicao = "--window-position=100,100" if (modo_visivel or CFG.modo_debug) \
                  else "--window-position=-1200,0"
        opcoes.add_argument(posicao)

        driver = webdriver.Chrome(options=opcoes)
        driver.set_page_load_timeout(CFG.page_load_timeout + 10)
        return driver

    def _conectar(self) -> None:
        """Inicializa o driver e autentica no WhatsApp Web."""
        ja_autenticado = CFG.caminho_auth.exists()

        try:
            self._driver = self._criar_driver(modo_visivel=not ja_autenticado)
            self._driver.get("https://web.whatsapp.com")

            if not ja_autenticado:
                logger.info("Primeiro acesso. Aguardando QR Code (3 minutos).")
                _aguardar_painel(self._driver, timeout=180.0)
                CFG.caminho_projeto.mkdir(parents=True, exist_ok=True)
                CFG.caminho_auth.write_text(
                    f"Autenticado em {datetime.now()}\n", encoding="utf-8"
                )
                logger.info("QR Code autenticado. Sessao salva.")
                if not CFG.modo_debug:
                    self._driver.set_window_position(-1200, 0)
            else:
                try:
                    _aguardar_painel(self._driver, timeout=30.0)
                    logger.info("Sessao restaurada com sucesso.")
                except TimeoutException:
                    logger.warning("Sessao expirada. Removendo marcador de autenticacao.")
                    CFG.caminho_auth.unlink(missing_ok=True)
                    raise AutenticacaoNecessaria("Sessao expirada. Escanear QR Code.")

            self._autenticado = True

        except AutenticacaoNecessaria:
            raise
        except TimeoutException:
            logger.error("Timeout aguardando QR Code.")
            self._encerrar_driver()
        except WebDriverException as exc:
            logger.exception("Falha ao inicializar WebDriver: %s", exc)
            self._encerrar_driver()

    def _encerrar_driver(self) -> None:
        if self._driver is not None:
            try:
                self._driver.quit()
            except Exception:
                pass
            self._driver = None
        self._autenticado = False

    def _driver_ativo(self) -> bool:
        if self._driver is None or not self._autenticado:
            return False
        try:
            _ = self._driver.current_url
            return True
        except WebDriverException:
            return False

    # ----------------------------------------------------------
    #  NAVEGACAO
    # ----------------------------------------------------------

    def _navegar_para_contato(self, numero: str) -> bool:
        assert self._driver is not None

        # Estrategia 1: API JS interna (sem reload de pagina).
        try:
            resultado = self._driver.execute_script(_JS_NAVEGAR_CHAT, numero)
            if resultado:
                logger.debug(
                    "Navegacao JS para %s bem-sucedida.", _mascarar_numero(numero)
                )
                time.sleep(0.15)
                return True
        except WebDriverException as exc:
            logger.debug("Navegacao JS falhou (%s). Usando URL.", exc)

        # Estrategia 2: URL de fallback.
        try:
            url = (
                f"https://web.whatsapp.com/send/"
                f"?phone={numero}&type=phone_number&app_absent=0"
            )
            self._driver.get(url)
            WebDriverWait(self._driver, CFG.page_load_timeout).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
            )
            time.sleep(1.0)
            _dispensar_popups(self._driver)
            logger.debug(
                "Navegacao URL para %s concluida.", _mascarar_numero(numero)
            )
            return True
        except TimeoutException:
            logger.error(
                "Timeout ao carregar URL para %s.", _mascarar_numero(numero)
            )
            return False
        except WebDriverException as exc:
            logger.error(
                "WebDriverException na URL para %s: %s",
                _mascarar_numero(numero),
                exc,
            )
            return False

    # ----------------------------------------------------------
    #  ENVIO COM CONFIRMACAO
    # ----------------------------------------------------------

    def _titulo_chat_aberto(self) -> str:
        assert self._driver is not None
        for seletor in (
            "div[data-testid='conversation-header'] span[dir='auto']",
            "header span[dir='auto']",
        ):
            elementos = self._driver.find_elements(By.CSS_SELECTOR, seletor)
            if elementos:
                texto = elementos[0].text.strip()
                if texto:
                    return texto
        return ""

    def _confirmar_destinatario(self, contato: Contato) -> None:
        """
        Aguarda (ate 3 s, polling de 100 ms) o cabecalho refletir o contato.
        Segue assim que bater; aborta se o chat aberto for outro; prossegue
        se o cabecalho nao for localizavel.
        """
        esperado = _normalizar_nome(contato.nome)
        limite = monotonic() + 3.0
        titulo = ""
        while monotonic() < limite:
            try:
                titulo = self._titulo_chat_aberto()
            except WebDriverException:
                titulo = ""
            if titulo and _normalizar_nome(titulo) == esperado:
                return
            time.sleep(0.1)

        if titulo:
            logger.warning(
                "Chat aberto e '%s', esperado '%s'. Abortando envio.",
                titulo,
                contato.nome,
            )
            raise DestinatarioInvalido(
                f"Chat incorreto: aberto={titulo!r}, esperado={contato.nome!r}"
            )
        logger.debug("Nao foi possivel confirmar o header do chat. Prosseguindo.")

    def _enviar_uma_vez(self, pedido: _PedidoEnvio) -> ResultadoEnvio:
        """
        Executa uma unica tentativa de envio e aguarda confirmacao visual
        (nova bolha .message-out no DOM).
        """
        assert self._driver is not None
        contato = pedido.contato

        if not self._navegar_para_contato(contato.numero):
            raise TimeoutException("Falha de navegacao para o contato.")

        self._confirmar_destinatario(contato)
        return self._digitar_e_enviar(pedido.mensagem, contato.nome)

    def _digitar_e_enviar(self, mensagem: str, destinatario: str) -> ResultadoEnvio:
        """Digita no compositor da conversa aberta, envia e confirma pela bolha de saida."""
        assert self._driver is not None

        campo = _encontrar_elemento(
            self._driver,
            _CSS_COMPOSITOR,
            _XPATH_COMPOSITOR,
            timeout_total=float(CFG.element_timeout),
        )

        # Conta bolhas antes do envio para usar como baseline de confirmacao.
        bolhas_antes = len(self._driver.find_elements(By.CSS_SELECTOR, _CSS_BOLHA_SAIDA))

        campo.click()
        campo.send_keys(mensagem)
        time.sleep(0.1)
        campo.send_keys(Keys.ENTER)

        # Aguarda confirmacao visual: pelo menos uma bolha nova de saida.
        try:
            WebDriverWait(self._driver, 10).until(
                lambda d: len(d.find_elements(By.CSS_SELECTOR, _CSS_BOLHA_SAIDA))
                > bolhas_antes
            )
            logger.info("Mensagem confirmada na conversa com %s.", destinatario)
            return ResultadoEnvio(
                EstadoEnvio.CONFIRMADO_NA_CONVERSA,
                destinatario,
                "Bolha de saida detectada no DOM.",
            )
        except TimeoutException:
            logger.warning(
                "Mensagem inserida mas bolha nao confirmada para %s.", destinatario
            )
            return ResultadoEnvio(
                EstadoEnvio.INSERIDO_NA_INTERFACE,
                destinatario,
                "Keys.ENTER executado. Bolha nao confirmada.",
            )

    def _enviar_com_retry(self, pedido: _PedidoEnvio) -> ResultadoEnvio:
        """Executa ate 3 tentativas com backoff exponencial e jitter."""
        ultimo_erro: Exception | None = None

        for tentativa in range(1, 4):
            logger.info(
                "Tentativa %d/3 para %s.", tentativa, pedido.contato.nome
            )

            if not self._driver_ativo():
                logger.warning("Driver inativo. Reconectando.")
                self._encerrar_driver()
                try:
                    self._conectar()
                except AutenticacaoNecessaria as exc:
                    return ResultadoEnvio(
                        EstadoEnvio.FALHOU,
                        pedido.contato.nome,
                        str(exc),
                    )

            try:
                self._limitador.aguardar()
                return self._enviar_uma_vez(pedido)

            except DestinatarioInvalido as exc:
                # Erro permanente: nao retenta.
                return ResultadoEnvio(
                    EstadoEnvio.FALHOU,
                    pedido.contato.nome,
                    str(exc),
                )

            except AutenticacaoNecessaria as exc:
                return ResultadoEnvio(
                    EstadoEnvio.FALHOU,
                    pedido.contato.nome,
                    str(exc),
                )

            except UnexpectedAlertPresentException:
                logger.warning("Alert inesperado. Dispensando.")
                try:
                    if self._driver:
                        self._driver.switch_to.alert.dismiss()
                except Exception:
                    pass
                ultimo_erro = UnexpectedAlertPresentException("Alert dispensado.")

            except TimeoutException as exc:
                logger.warning("Timeout na tentativa %d: %s", tentativa, exc)
                if self._driver:
                    _dispensar_popups(self._driver)
                ultimo_erro = exc

            except WebDriverException as exc:
                logger.error("WebDriverException na tentativa %d: %s", tentativa, exc)
                self._encerrar_driver()
                ultimo_erro = exc

            if tentativa < 3:
                espera = _backoff(tentativa)
                logger.debug("Aguardando %.1fs antes da proxima tentativa.", espera)
                time.sleep(espera)

        return ResultadoEnvio(
            EstadoEnvio.FALHOU,
            pedido.contato.nome,
            f"Falha apos 3 tentativas: {ultimo_erro}",
        )

    # ----------------------------------------------------------
    #  MENSAGENS AGENDADAS
    # ----------------------------------------------------------

    def _avisar(self, texto: str, essencial: bool) -> None:
        logger.info("[AVISO] %s", texto)
        if self.notificar is not None:
            try:
                self.notificar(texto, essencial)
            except Exception:
                logger.debug("Falha ao notificar.", exc_info=True)

    def _executar_agendados(self) -> None:
        """Envia (ate 3 por ciclo) as mensagens agendadas vencidas e registra o resultado."""
        assert self._agendador is not None
        for envio in self._agendador.devidos(time.time())[:3]:
            contato = Contato(nome=envio.contato, numero=envio.numero)
            pedido = _PedidoEnvio(contato=contato, mensagem=envio.mensagem, future=Future())
            resultado = self._enviar_com_retry(pedido)
            if resultado.estado in (
                EstadoEnvio.CONFIRMADO_NA_CONVERSA,
                EstadoEnvio.INSERIDO_NA_INTERFACE,
            ):
                self._agendador.marcar(envio.id, "enviada", resultado.detalhe)
                self._avisar(f"Mensagem agendada enviada para {envio.contato}.", False)
            else:
                self._agendador.marcar(envio.id, "falhou", resultado.detalhe)
                self._avisar(
                    f"Nao consegui enviar a mensagem agendada para {envio.contato}. "
                    f"{resultado.detalhe}",
                    True,
                )

    # ----------------------------------------------------------
    #  CONVERSAS: LER, RESPONDER E ENVIAR IMAGEM
    # ----------------------------------------------------------

    def _resolver_chat_na_lista(self, nome: str) -> str:
        """
        Titulo EXATO de uma conversa visivel na lista lateral que casa com o nome
        falado. Levanta LookupError (nenhuma) ou ConversaAmbigua (mais de uma).
        """
        assert self._driver is not None
        titulos = self._driver.execute_script(_JS_NOMES_CHATS) or []
        termos = set(_sem_acentos(nome).split())
        if not termos:
            raise LookupError("Nome de conversa vazio.")
        achados = list(dict.fromkeys(
            t for t in titulos if termos <= set(_sem_acentos(t).split())
        ))
        if not achados:
            raise LookupError(
                f"Nao encontrei uma conversa recente com {nome}. "
                "So consigo localizar as conversas visiveis na lista."
            )
        if len(achados) > 1:
            raise ConversaAmbigua(nome, achados)
        return achados[0]

    def _abrir_conversa(self, contato: Contato | None, nome: str | None) -> str:
        """Abre a conversa (pelo numero ou pela lista lateral) e devolve o titulo."""
        assert self._driver is not None
        if contato is not None:
            if not self._navegar_para_contato(contato.numero):
                raise TimeoutException("Falha de navegacao para o contato.")
            self._confirmar_destinatario(contato)
            return contato.nome

        titulo = self._resolver_chat_na_lista(nome or "")
        if not self._abrir_chat_pelo_nome(titulo):
            raise LookupError(f"Nao consegui abrir a conversa com {titulo}.")
        self._confirmar_destinatario(Contato(nome=titulo, numero=""))
        return titulo

    def _ler_chat(self, pedido: _PedidoLerChat) -> ResultadoLeitura:
        if not self._driver_ativo():
            raise ConnectionError("O WhatsApp nao esta conectado.")
        assert self._driver is not None

        titulo = self._abrir_conversa(pedido.contato, pedido.nome)

        brutas: list = []
        limite = monotonic() + 4.0
        while monotonic() < limite:
            dados = self._driver.execute_script(
                _JS_ULTIMAS_RECEBIDAS, pedido.quantidade
            ) or {}
            brutas = dados.get("mensagens", [])
            if brutas:
                break
            time.sleep(0.2)

        mensagens = []
        for bruta in brutas:
            achado = re.search(r"\[(\d{1,2}:\d{2})", str(bruta.get("pre", "")))
            mensagens.append(
                MensagemLida(
                    texto=str(bruta.get("texto", "")).strip(),
                    horario=achado.group(1) if achado else "",
                )
            )
        return ResultadoLeitura(chat=titulo, mensagens=tuple(mensagens))

    def _responder(self, pedido: _PedidoResponder) -> ResultadoEnvio:
        """Nunca levanta: erros de resolucao viram ResultadoEnvio FALHOU com a explicacao."""
        rotulo = pedido.nome or ""
        try:
            if not self._driver_ativo():
                return ResultadoEnvio(EstadoEnvio.FALHOU, rotulo, "O WhatsApp nao esta conectado.")
            assert self._driver is not None

            if pedido.nome is None:
                nao_lidas = self._coletar_nao_lidos()
                if not nao_lidas:
                    return ResultadoEnvio(
                        EstadoEnvio.FALHOU, "", "Nao ha conversas nao lidas para responder."
                    )
                if len(nao_lidas) > 1:
                    return ResultadoEnvio(
                        EstadoEnvio.FALHOU,
                        "",
                        f"Ha {len(nao_lidas)} conversas nao lidas. Diga para quem responder.",
                    )
                titulo = nao_lidas[0].nome
                if not self._abrir_chat_pelo_nome(titulo):
                    return ResultadoEnvio(
                        EstadoEnvio.FALHOU, titulo, f"Nao consegui abrir a conversa com {titulo}."
                    )
                self._confirmar_destinatario(Contato(nome=titulo, numero=""))
            else:
                titulo = self._abrir_conversa(None, pedido.nome)

            self._limitador.aguardar()
            return self._digitar_e_enviar(pedido.mensagem, titulo)

        except ConversaAmbigua as exc:
            return ResultadoEnvio(
                EstadoEnvio.FALHOU,
                rotulo,
                "Encontrei " + " ou ".join(exc.nomes) + ". Diga o nome completo.",
            )
        except LookupError as exc:
            return ResultadoEnvio(EstadoEnvio.FALHOU, rotulo, str(exc))
        except DestinatarioInvalido as exc:
            return ResultadoEnvio(EstadoEnvio.FALHOU, rotulo, str(exc))
        except WebDriverException as exc:
            logger.warning("Erro ao responder: %s", exc)
            return ResultadoEnvio(
                EstadoEnvio.FALHOU, rotulo, "Houve um erro no navegador ao responder."
            )

    def _aguardar_botao_envio_midia(self, timeout: float):
        """Espera o botao de enviar da previa de midia (apos colar a imagem)."""
        assert self._driver is not None
        limite = monotonic() + timeout
        while monotonic() < limite:
            for seletor in _CSS_BOTAO_ENVIAR_MIDIA:
                try:
                    for elemento in self._driver.find_elements(By.CSS_SELECTOR, seletor):
                        if elemento.is_displayed():
                            return elemento
                except WebDriverException:
                    continue
            time.sleep(0.2)
        return None

    def _enviar_imagem(self, pedido: _PedidoImagem) -> ResultadoEnvio:
        """
        Cola (Ctrl+V) a imagem da area de transferencia no compositor, espera a
        previa de midia e clica em enviar. Nunca levanta.
        """
        contato = pedido.contato
        try:
            if not self._driver_ativo():
                return ResultadoEnvio(
                    EstadoEnvio.FALHOU, contato.nome, "O WhatsApp nao esta conectado."
                )
            assert self._driver is not None

            self._limitador.aguardar()
            if not self._navegar_para_contato(contato.numero):
                raise TimeoutException("Falha de navegacao para o contato.")
            self._confirmar_destinatario(contato)

            campo = _encontrar_elemento(
                self._driver,
                _CSS_COMPOSITOR,
                _XPATH_COMPOSITOR,
                timeout_total=float(CFG.element_timeout),
            )
            bolhas_antes = len(
                self._driver.find_elements(By.CSS_SELECTOR, _CSS_BOLHA_SAIDA)
            )

            campo.click()
            campo.send_keys(Keys.CONTROL, "v")

            botao = self._aguardar_botao_envio_midia(8.0)
            if botao is None:
                return ResultadoEnvio(
                    EstadoEnvio.FALHOU,
                    contato.nome,
                    "A previa da imagem nao apareceu. Confira a area de transferencia.",
                )
            self._driver.execute_script(
                "(arguments[0].closest('[role=\"button\"], button') || arguments[0]).click();",
                botao,
            )

            try:
                WebDriverWait(self._driver, 25).until(
                    lambda d: len(d.find_elements(By.CSS_SELECTOR, _CSS_BOLHA_SAIDA))
                    > bolhas_antes
                )
                return ResultadoEnvio(
                    EstadoEnvio.CONFIRMADO_NA_CONVERSA,
                    contato.nome,
                    "Imagem confirmada pela bolha de saida.",
                )
            except TimeoutException:
                return ResultadoEnvio(
                    EstadoEnvio.INSERIDO_NA_INTERFACE,
                    contato.nome,
                    "Botao de enviar acionado. Bolha nao confirmada.",
                )

        except DestinatarioInvalido as exc:
            return ResultadoEnvio(EstadoEnvio.FALHOU, contato.nome, str(exc))
        except WebDriverException as exc:
            logger.warning("Erro ao enviar imagem para %s: %s", contato.nome, exc)
            return ResultadoEnvio(
                EstadoEnvio.FALHOU,
                contato.nome,
                "Houve um erro no navegador ao enviar a imagem.",
            )

    # ----------------------------------------------------------
    #  LISTA LATERAL: COLETA DE NAO LIDOS
    # ----------------------------------------------------------

    @staticmethod
    def _texto_opcional(item, seletor: str) -> str:
        try:
            return item.find_element(By.CSS_SELECTOR, seletor).text.strip()
        except NoSuchElementException:
            return ""

    def _coletar_nao_lidos(self) -> list[ChatNaoLido]:
        """
        Le a lista lateral e devolve apenas strings (nenhum WebElement e
        guardado). Nao abre nenhum chat, portanto nao marca nada como lido.
        Tenta primeiro um script JS tolerante a mudancas de DOM; se ele nao
        achar nada, cai para os seletores Selenium.
        """
        assert self._driver is not None

        try:
            dados = self._driver.execute_script(_JS_COLETAR_NAO_LIDOS) or {}
            chats: list[ChatNaoLido] = []
            for d in dados.get("chats", []):
                nome = str(d.get("nome", "")).strip()
                previa = str(d.get("previa", "")).strip()
                horario = str(d.get("horario", "")).strip()
                quantidade = int(d.get("quantidade") or 1)
                if not nome:
                    continue
                chats.append(
                    ChatNaoLido(
                        nome=nome,
                        previa=previa,
                        horario=horario,
                        quantidade=quantidade,
                        fingerprint=_criar_fingerprint(nome, previa, horario),
                    )
                )
            logger.info(
                "Lista lateral: %d item(ns), %d nao lido(s) (JS).",
                dados.get("total", 0),
                len(chats),
            )
            if chats:
                return chats
        except WebDriverException as exc:
            logger.debug("Coleta via JS falhou: %s", exc)

        chats = self._coletar_nao_lidos_selenium()
        logger.info("Fallback Selenium: %d nao lido(s).", len(chats))
        if not chats:
            logger.warning(
                "Nenhuma conversa nao lida detectada. Se ha mensagens pendentes, "
                "use o comando 'diagnosticar whatsapp'."
            )
        return chats

    def _coletar_nao_lidos_selenium(self) -> list[ChatNaoLido]:
        """Coleta por seletores Selenium (fallback). Apenas strings, sem WebElements."""
        assert self._driver is not None
        resultado: list[ChatNaoLido] = []

        itens = self._driver.find_elements(By.CSS_SELECTOR, "div[role='listitem']")
        for item in itens:
            try:
                badge = None
                for seletor in _CSS_BADGE_NAO_LIDA:
                    encontrados = item.find_elements(By.CSS_SELECTOR, seletor)
                    if encontrados:
                        badge = encontrados[0]
                        break
                if badge is None:
                    continue

                texto_badge = (
                    badge.text or badge.get_attribute("aria-label") or ""
                ).strip()
                achado = re.search(r"\d+", texto_badge)
                quantidade = int(achado.group()) if achado else 1

                nome = (
                    item.find_element(By.CSS_SELECTOR, "span[title]")
                    .get_attribute("title")
                    or ""
                )
                if not nome:
                    continue

                previa = self._texto_opcional(item, _CSS_PREVIA_CHAT)
                horario = self._texto_opcional(item, "span[data-testid='msg-time']")

                resultado.append(
                    ChatNaoLido(
                        nome=nome,
                        previa=previa,
                        horario=horario,
                        quantidade=quantidade,
                        fingerprint=_criar_fingerprint(nome, previa, horario),
                    )
                )
            except (NoSuchElementException, StaleElementReferenceException):
                continue

        return resultado

    def _ler_nao_lidos(self) -> list[ChatNaoLido]:
        if not self._driver_ativo():
            raise ConnectionError("WhatsApp nao esta conectado.")
        return self._coletar_nao_lidos()

    def _diagnosticar(self) -> Path:
        """
        Grava wpp_diagnostico.json na pasta do projeto. O arquivo contem HTML
        da lista lateral (nomes e previas de mensagens): revise antes de compartilhar.
        """
        if not self._driver_ativo():
            raise ConnectionError("WhatsApp nao esta conectado.")
        assert self._driver is not None

        dados = self._driver.execute_script(_JS_DIAGNOSTICO) or {}
        dados["coleta_js"] = self._driver.execute_script(_JS_COLETAR_NAO_LIDOS)

        CFG.caminho_projeto.mkdir(parents=True, exist_ok=True)
        caminho = CFG.caminho_projeto / "wpp_diagnostico.json"
        caminho.write_text(
            json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        logger.info("Diagnostico gravado em %s", caminho)
        return caminho

    # ----------------------------------------------------------
    #  AUTO-RESPONDER
    # ----------------------------------------------------------

    def _ciclo_auto_responder(self, forcar: bool = False) -> ResultadoVarredura:
        """
        Responde chats nao lidos de contatos permitidos.
        forcar=True ignora a janela minima de 10 minutos (usado na varredura
        manual); o fingerprint continua impedindo resposta duplicada.
        """
        if not self._driver_ativo():
            return ResultadoVarredura(0, 0, "driver_inativo")

        permitidos = self._agenda.ler_permitidos()
        if not permitidos:
            return ResultadoVarredura(0, 0, "sem_permitidos")

        # Fase 1: coleta apenas dados (strings) para evitar stale refs.
        try:
            chats = self._coletar_nao_lidos()
        except WebDriverException as exc:
            logger.warning("Erro na varredura do auto-responder: %s", exc)
            return ResultadoVarredura(0, 0, "erro_varredura")

        candidatos = [
            c for c in chats
            if _normalizar_nome(c.nome) in permitidos
            and c.fingerprint not in self._mensagens_processadas
            and (forcar or self._validar_janela_tempo(c.horario))
        ]

        # Fase 2: processa cada candidato re-localizando o elemento pelo nome.
        respondidos = 0
        for chat in candidatos:
            if self._evento_saida.is_set():
                break
            if self._processar_chat_pelo_nome(chat.nome):
                self._mensagens_processadas.add(chat.fingerprint)
                respondidos += 1
            time.sleep(0.8)

        return ResultadoVarredura(respondidos, len(chats))

    def _validar_janela_tempo(self, horario: str) -> bool:
        """Retorna True se o horario da mensagem estiver dentro de 10min a 24h atras."""
        if not (horario and ":" in horario and len(horario) == 5):
            return True  # Formato desconhecido: permite processar.
        try:
            h, m = map(int, horario.split(":"))
            agora = datetime.now()
            t_msg = agora.replace(hour=h, minute=m, second=0, microsecond=0)
            if t_msg > agora:
                t_msg -= timedelta(days=1)
            diff_min = (agora - t_msg).total_seconds() / 60
            return 10 <= diff_min < 1440
        except ValueError:
            return True

    def _abrir_chat_pelo_nome(self, nome: str) -> bool:
        """Abre o chat na lista lateral pelo nome (JS primeiro, Selenium como fallback)."""
        assert self._driver is not None
        try:
            if self._driver.execute_script(_JS_ABRIR_CHAT_POR_NOME, nome):
                return True
        except WebDriverException as exc:
            logger.debug("Abertura de chat via JS falhou: %s", exc)

        for item in self._driver.find_elements(By.CSS_SELECTOR, "div[role='listitem']"):
            try:
                titulo = item.find_element(By.CSS_SELECTOR, "span[title]")
                if titulo.get_attribute("title") == nome:
                    self._driver.execute_script("arguments[0].click();", item)
                    return True
            except (NoSuchElementException, StaleElementReferenceException):
                continue
        return False

    def _processar_chat_pelo_nome(self, nome: str) -> bool:
        """Re-localiza o chat pelo nome e envia a auto-resposta."""
        assert self._driver is not None
        try:
            if not self._abrir_chat_pelo_nome(nome):
                logger.warning("Chat '%s' nao encontrado na lista lateral.", nome)
                return False
            time.sleep(1.2)

            campo = _encontrar_elemento(
                self._driver,
                _CSS_COMPOSITOR,
                _XPATH_COMPOSITOR,
                timeout_total=15.0,
            )
            campo.click()
            campo.send_keys(
                "Jairo: Oi! Sou o assistente pessoal desse contato. "
                "Vou avisa-lo agora. Ele te responde em breve!"
            )
            time.sleep(0.3)
            campo.send_keys(Keys.ENTER)
            logger.info("Auto-resposta enviada para %s.", nome)
            return True
        except WebDriverException as exc:
            logger.warning("Erro no auto-responder para %s: %s", nome, exc)
        return False


# ==============================================================
#  SINAIS SONOROS (feedback instantaneo, sem TTS)
# ==============================================================

class Sinal:
    """Bipes curtos (somente Windows). Sincronos, mas de 30 a 160 ms."""

    console: bool = False  # modo texto: imprime o bipe em vez de toca-lo

    @classmethod
    def _bip(cls, frequencia: int, ms: int) -> None:
        if cls.console:
            print(f"  [bip {frequencia} Hz]", flush=True)
            return
        if winsound is None:
            return
        try:
            winsound.Beep(frequencia, ms)
        except Exception:
            pass

    @classmethod
    def ok(cls) -> None:
        cls._bip(1200, 40)

    @classmethod
    def erro(cls) -> None:
        cls._bip(400, 160)

    @classmethod
    def alerta(cls) -> None:
        for frequencia in (900, 1200, 900):
            cls._bip(frequencia, 90)


# ==============================================================
#  ESTADO COMPARTILHADO DE FALA (anti-eco)
# ==============================================================

class EstadoFala:
    """
    Compartilhado entre VozService e AudioPipeline para que o microfone
    descarte audio capturado enquanto (ou logo apos) o Jairo fala.
    """

    def __init__(self) -> None:
        self.falando = threading.Event()
        self.geracao: int = 0
        self.fim: float = -1e9

    def iniciar(self) -> None:
        self.geracao += 1
        self.falando.set()

    def finalizar(self) -> None:
        self.fim = monotonic()
        self.falando.clear()

    def interferiu(self, geracao_antes: int, margem: float = 1.0) -> bool:
        """True se houve fala durante (ou imediatamente antes do fim d)a captura."""
        return (
            self.falando.is_set()
            or self.geracao != geracao_antes
            or (monotonic() - self.fim) < margem
        )


# ==============================================================
#  GANHO AUTOMATICO (voz baixa)
# ==============================================================

def _ganho_automatico(audio: "sr.AudioData") -> "sr.AudioData":
    """
    Amplifica frases captadas em volume baixo ate um RMS-alvo (limitado por
    JAIRO_GANHO_MAX) antes de enviar ao reconhecedor. Melhora a acuracia do
    STT com fala baixa ou microfone distante. Sem audioop, devolve o original.
    """
    if audioop is None or CFG.ganho_max <= 1.0:
        return audio
    try:
        rms = audioop.rms(audio.frame_data, audio.sample_width)
        if rms <= 0:
            return audio
        ganho = min(CFG.ganho_max, CFG.alvo_rms / rms)
        if ganho < 1.15:
            return audio
        dados = audioop.mul(audio.frame_data, audio.sample_width, ganho)
        logger.debug("Ganho automatico x%.2f (rms %d).", ganho, rms)
        return sr.AudioData(dados, audio.sample_rate, audio.sample_width)
    except Exception as exc:
        logger.debug("Ganho automatico falhou: %s", exc)
        return audio


# ==============================================================
#  AUDIO: CAPTURA E TRANSCRICAO
# ==============================================================

class _StreamComNivel:
    """
    Proxy do stream do microfone: repassa read() sem alterar os dados e avisa
    cada bloco ao callback (usado so para o medidor de nivel do painel).
    """

    def __init__(self, stream, callback, largura: int) -> None:
        self._stream = stream
        self._callback = callback
        self._largura = largura

    def read(self, *args, **kwargs):
        dados = self._stream.read(*args, **kwargs)
        try:
            self._callback(dados, self._largura)
        except Exception:
            pass
        return dados

    def __getattr__(self, nome: str):
        return getattr(self._stream, nome)


def _rms_pcm(dados: bytes, largura: int) -> float:
    """RMS de audio PCM (a mesma escala do energy_threshold do speech_recognition)."""
    if audioop is not None:
        try:
            return float(audioop.rms(dados, largura))
        except Exception:
            pass
    if largura != 2 or len(dados) < 2:
        return 0.0
    amostras = array("h")
    amostras.frombytes(dados[: len(dados) - len(dados) % 2])
    if not amostras:
        return 0.0
    return math.sqrt(sum(a * a for a in amostras) / len(amostras))


class AudioPipeline:
    """
    Gerencia captura de microfone e transcricao em threads dedicadas.
    Todos os comandos transcritos chegam em cmd_queue.
    """

    def __init__(self, evento_saida: threading.Event, estado_fala: EstadoFala) -> None:
        self._evento_saida  = evento_saida
        self._estado_fala   = estado_fala
        self._reconhecedor  = sr.Recognizer()
        self._audio_queue: queue.Queue[sr.AudioData] = queue.Queue(maxsize=3)
        self.cmd_queue:    queue.Queue[str]           = queue.Queue()
        self._threads: list[threading.Thread] = []
        self._recalibrar_apos: float | None = None
        # Gancho opcional (painel): ao_nivel(bloco_pcm, largura_da_amostra), na thread de captura.
        self.ao_nivel: "Callable[[bytes, int], None] | None" = None

    def limiar_energia(self) -> float:
        return float(self._reconhecedor.energy_threshold)

    def _aplicar_limite_energia(self) -> None:
        if CFG.energy_fixo > 0:
            self._reconhecedor.energy_threshold = CFG.energy_fixo
        else:
            self._reconhecedor.energy_threshold = max(
                CFG.energy_min, min(self._reconhecedor.energy_threshold, CFG.energy_max)
            )

    def solicitar_recalibracao(self) -> None:
        """
        Pede recalibracao do microfone. Quem executa e a thread de captura,
        que e dona do stream, depois que o Jairo terminar de falar.
        """
        self._recalibrar_apos = monotonic() + 0.5

    def _recalibrar_agora(self, mic) -> None:
        try:
            self._reconhecedor.adjust_for_ambient_noise(
                mic, duration=CFG.calibracao_seg
            )
            self._aplicar_limite_energia()
            logger.info(
                "Microfone recalibrado. Threshold: %.0f",
                self._reconhecedor.energy_threshold,
            )
            Sinal.ok()
        except Exception as exc:
            logger.warning("Falha na recalibracao: %s", exc)

    def configurar(self) -> None:
        # pause_threshold = silencio que encerra a frase (principal fonte de latencia).
        self._reconhecedor.pause_threshold          = CFG.pause_threshold
        self._reconhecedor.non_speaking_duration    = min(0.5, CFG.pause_threshold)
        self._reconhecedor.phrase_threshold         = 0.2
        self._reconhecedor.dynamic_energy_threshold = False
        # Ponto de partida da calibracao: o padrao do speech_recognition (300)
        # puxava o limite para cima e exigia fala mais alta.
        self._reconhecedor.energy_threshold = (
            CFG.energy_fixo if CFG.energy_fixo > 0 else CFG.energy_min
        )

    def calibrar(self) -> None:
        logger.info("Calibrando microfone (%.1f s de silencio)...", CFG.calibracao_seg)
        try:
            with sr.Microphone() as mic:
                self._reconhecedor.adjust_for_ambient_noise(mic, duration=CFG.calibracao_seg)
            self._aplicar_limite_energia()
            logger.info(
                "Microfone calibrado. Threshold: %.0f",
                self._reconhecedor.energy_threshold,
            )
        except OSError as exc:
            logger.error("Microfone nao encontrado: %s", exc)
        except Exception as exc:
            logger.exception("Erro na calibracao: %s", exc)

    def iniciar(self) -> None:
        captura     = threading.Thread(
            target=self._capturar, name="AudioCaptura", daemon=False
        )
        transcricao = threading.Thread(
            target=self._transcrever, name="AudioTranscricao", daemon=False
        )
        self._threads = [captura, transcricao]
        for t in self._threads:
            t.start()

    def encerrar(self) -> None:
        for t in self._threads:
            t.join(timeout=5)

    def _capturar(self) -> None:
        """
        Mantem o microfone ABERTO entre frases (reabrir a cada frase custava
        100-300 ms e podia cortar o inicio da fala). timeout=1 permite checar
        o evento de saida sem ficar preso em listen().
        """
        while not self._evento_saida.is_set():
            try:
                with sr.Microphone() as mic:
                    if self.ao_nivel is not None:
                        mic.stream = _StreamComNivel(mic.stream, self.ao_nivel, mic.SAMPLE_WIDTH)
                    while not self._evento_saida.is_set():
                        apos = self._recalibrar_apos
                        if (
                            apos is not None
                            and monotonic() >= apos
                            and not self._estado_fala.falando.is_set()
                            and monotonic() - self._estado_fala.fim > 0.8
                        ):
                            self._recalibrar_apos = None
                            self._recalibrar_agora(mic)
                            continue

                        falava_antes = self._estado_fala.falando.is_set()
                        geracao_antes = self._estado_fala.geracao

                        try:
                            audio = self._reconhecedor.listen(
                                mic,
                                timeout=1,
                                phrase_time_limit=CFG.phrase_time_limit,
                            )
                        except sr.WaitTimeoutError:
                            continue

                        if self._evento_saida.is_set():
                            break

                        # Descarta o proprio TTS captado pelo microfone.
                        if falava_antes or self._estado_fala.interferiu(geracao_antes):
                            logger.debug("Audio descartado (captado durante fala do Jairo).")
                            continue

                        try:
                            self._audio_queue.put_nowait(audio)
                        except queue.Full:
                            pass
            except OSError:
                time.sleep(2)
            except Exception as exc:
                logger.warning("AudioCaptura: %s", exc)
                time.sleep(1)

    def _transcrever(self) -> None:
        while not self._evento_saida.is_set():
            try:
                audio = self._audio_queue.get(timeout=1)
            except queue.Empty:
                continue
            try:
                texto = self._reconhecedor.recognize_google(
                    _ganho_automatico(audio), language="pt-BR"
                )
                if texto.strip():
                    self.cmd_queue.put(texto.lower())
            except sr.UnknownValueError:
                pass
            except sr.RequestError as exc:
                logger.error("API STT Google: %s", exc)
            except Exception as exc:
                logger.warning("AudioTranscricao: %s", exc)


# ==============================================================
#  SERVICO DE VOZ
# ==============================================================

_PS_FALAR = (
    "Add-Type -AssemblyName System.Speech;"
    "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
    "try { $s.SelectVoiceByHints("
    "[System.Speech.Synthesis.VoiceGender]::NotSet,"
    "[System.Speech.Synthesis.VoiceAge]::NotSet,0,"
    "[System.Globalization.CultureInfo]::GetCultureInfo('pt-BR')) } catch {};"
    "$s.Volume = 100;"
    "$s.Speak($env:JAIRO_TEXTO)"
)


class VozService:
    """
    Sintetizador de voz seguro para Windows COM.
    A fila e consumida EXCLUSIVAMENTE na thread principal.

    Backends (JAIRO_TTS):
      auto       pyttsx3 com fallback automatico para PowerShell/SAPI
      pyttsx3    somente pyttsx3
      powershell somente System.Speech via PowerShell

    O motor pyttsx3 e recriado a cada fala: reutilizar uma instancia apos
    runAndWait() e uma causa conhecida de fala silenciosa no Windows.
    Uma fala cujo runAndWait() retorna rapido demais para o tamanho do
    texto e tratada como silenciosa e repetida pelo PowerShell.
    """

    _SEGUNDOS_MIN_POR_CHAR = 0.02

    def __init__(
        self,
        estado_fala: EstadoFala,
        console: bool = False,
        falar_tambem: bool = False,
    ) -> None:
        self._fila: queue.Queue[str] = queue.Queue()
        self._estado = estado_fala
        # console: imprime as falas (modo texto). falar_tambem: imprime E fala.
        self._console = console
        self._falar_tambem = falar_tambem
        self._backend = CFG.tts_backend if CFG.tts_backend in (
            "auto", "pyttsx3", "powershell"
        ) else "auto"
        self._voz_id: str | None = None
        self._falhas_pyttsx3 = 0
        self.silencioso: bool = CFG.modo_silencioso
        self.ultima_fala: str = ""
        # Ganchos opcionais (painel grafico): ao_falar(texto, muda) quando uma fala
        # comeca (muda=True: confirmacao so por bipe) e ao_fim_fala() quando termina.
        self.ao_falar: "Callable[[str, bool], None] | None" = None
        self.ao_fim_fala: "Callable[[], None] | None" = None

    # ----------------------------------------------------------
    #  INICIALIZACAO
    # ----------------------------------------------------------

    def iniciar(self) -> None:
        if self._console and not self._falar_tambem:
            return
        if self._backend == "powershell":
            logger.info("TTS: backend PowerShell/SAPI (configurado).")
            return
        try:
            motor = pyttsx3.init()
            for voz in motor.getProperty("voices"):
                logger.debug("Voz disponivel: %s | %s", voz.name, voz.id)
                identificador = f"{voz.name} {voz.id}".lower()
                if self._voz_id is None and any(
                    k in identificador
                    for k in ("brazil", "portuguese", "pt-br", "pt_br")
                ):
                    self._voz_id = voz.id
                    logger.info("Voz selecionada: %s", voz.name)
            try:
                motor.stop()
            except Exception:
                pass
            logger.info("Motor de voz inicializado (backend: %s).", self._backend)
        except Exception as exc:
            logger.error("pyttsx3 nao iniciou: %s. Usando PowerShell/SAPI.", exc)
            self._backend = "powershell"

    # ----------------------------------------------------------
    #  API PUBLICA
    # ----------------------------------------------------------

    def falar(self, texto: str) -> None:
        """Enfileira uma resposta (sempre falada). Retorna imediatamente."""
        logger.info("[VOZ] %s", texto)
        self.ultima_fala = texto
        self._fila.put(texto)

    def confirmar(self, texto: str) -> None:
        """
        Confirmacao curta de acao. Falada normalmente; no modo silencioso vira
        um bip. Nao sobrescreve ultima_fala (usada por "repetir").
        """
        if self.silencioso:
            logger.info("[ACK] %s", texto)
            Sinal.ok()
            self._notificar_fala(texto, True)
            return
        logger.info("[VOZ] %s", texto)
        self._fila.put(texto)

    def _notificar_fala(self, texto: str, muda: bool) -> None:
        if self.ao_falar is not None:
            try:
                self.ao_falar(texto, muda)
            except Exception:
                logger.debug("Gancho ao_falar falhou.", exc_info=True)

    def _notificar_fim_fala(self) -> None:
        if self.ao_fim_fala is not None:
            try:
                self.ao_fim_fala()
            except Exception:
                logger.debug("Gancho ao_fim_fala falhou.", exc_info=True)

    def ocupada(self) -> bool:
        """True se ha fala em andamento ou pendente na fila."""
        return (not self._fila.empty()) or self._estado.falando.is_set()

    @property
    def fim_fala(self) -> float:
        """Instante (monotonic) em que a ultima fala terminou."""
        return self._estado.fim

    def consumir_fila(self) -> None:
        """
        Deve ser chamado no loop da thread principal.
        Processa todos os textos pendentes na fila.
        """
        while not self._fila.empty():
            try:
                texto = self._fila.get_nowait()
            except queue.Empty:
                break
            try:
                if texto:
                    self._estado.iniciar()
                    self._notificar_fala(texto, False)
                    try:
                        self._reproduzir(texto)
                    finally:
                        self._estado.finalizar()
                        self._notificar_fim_fala()
            except Exception as exc:
                logger.warning("Erro ao reproduzir voz: %s", exc)
            finally:
                self._fila.task_done()

    # ----------------------------------------------------------
    #  BACKENDS
    # ----------------------------------------------------------

    def _reproduzir(self, texto: str) -> None:
        if self._console:
            print(f"  jairo> {texto}", flush=True)
            if not self._falar_tambem:
                return
        if self._backend in ("auto", "pyttsx3"):
            resultado = self._falar_pyttsx3(texto)
            if resultado == "ok":
                self._falhas_pyttsx3 = 0
                return

            self._falhas_pyttsx3 += 1
            logger.warning(
                "pyttsx3 retornou '%s' (ocorrencia %d).",
                resultado,
                self._falhas_pyttsx3,
            )
            if self._backend == "pyttsx3":
                return
            if self._falhas_pyttsx3 >= 2:
                logger.warning("Alternando definitivamente para PowerShell/SAPI.")
                self._backend = "powershell"

        self._falar_powershell(texto)

    def _falar_pyttsx3(self, texto: str) -> str:
        """Retorna 'ok', 'silencioso' ou 'erro'."""
        try:
            motor = pyttsx3.init()
            motor.setProperty("rate", 175)
            motor.setProperty("volume", 1.0)
            if self._voz_id:
                motor.setProperty("voice", self._voz_id)

            inicio = monotonic()
            motor.say(texto)
            motor.runAndWait()
            decorrido = monotonic() - inicio

            try:
                motor.stop()
            except Exception:
                pass
            del motor

            if (
                len(texto) >= 8
                and decorrido < len(texto) * self._SEGUNDOS_MIN_POR_CHAR
            ):
                return "silencioso"
            return "ok"
        except Exception as exc:
            logger.warning("pyttsx3 falhou: %s", exc)
            return "erro"

    def _falar_powershell(self, texto: str) -> bool:
        """
        Fala via System.Speech. O texto vai por variavel de ambiente, nunca
        interpolado no script, sem shell=True.
        """
        try:
            processo = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-NonInteractive",
                    "-Command",
                    _PS_FALAR,
                ],
                env={**os.environ, "JAIRO_TEXTO": texto},
                capture_output=True,
                timeout=90,
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if processo.returncode != 0:
                logger.error(
                    "PowerShell TTS retornou %d: %s",
                    processo.returncode,
                    processo.stderr.decode("utf-8", errors="replace").strip(),
                )
                return False
            return True
        except FileNotFoundError:
            logger.error("powershell.exe nao encontrado no PATH.")
        except subprocess.TimeoutExpired:
            logger.error("Timeout no TTS via PowerShell.")
        except OSError as exc:
            logger.error("Falha ao executar PowerShell TTS: %s", exc)
        return False

    # ----------------------------------------------------------
    #  DIAGNOSTICO (python jairo.py --testar-voz)
    # ----------------------------------------------------------

    def diagnostico(self) -> None:
        print("Vozes detectadas pelo pyttsx3:")
        try:
            motor = pyttsx3.init()
            for voz in motor.getProperty("voices"):
                print(f"  - {voz.name} | {voz.id}")
            motor.stop()
        except Exception as exc:
            print(f"  falha ao listar vozes: {exc}")

        print("\n[1/2] Teste via pyttsx3...")
        resultado = self._falar_pyttsx3(
            "Teste de voz pelo pyttsx3. Se voce esta ouvindo isso, o audio funciona."
        )
        print(f"  resultado interno: {resultado}")

        print("\n[2/2] Teste via PowerShell/SAPI...")
        ok = self._falar_powershell(
            "Teste de voz pelo PowerShell. Se voce esta ouvindo isso, o audio funciona."
        )
        print(f"  executou sem erro: {ok}")

        print(
            "\nInterpretacao:\n"
            "  - Ouviu apenas o segundo: defina JAIRO_TTS=powershell no .env.\n"
            "  - Ouviu apenas o primeiro: defina JAIRO_TTS=pyttsx3 no .env.\n"
            "  - Nao ouviu nenhum: verifique o dispositivo de saida padrao do Windows,\n"
            "    o mixer de volume (volume do Python/terminal) e se ha vozes pt-BR\n"
            "    instaladas em Configuracoes > Hora e idioma > Fala."
        )


# ==============================================================
#  CONTROLE DE MIDIA E VOLUME
# ==============================================================

_VK_VOLUME_MUTE      = 0xAD
_VK_VOLUME_DOWN      = 0xAE
_VK_VOLUME_UP        = 0xAF
_VK_MEDIA_NEXT       = 0xB0
_VK_MEDIA_PREV       = 0xB1
_VK_MEDIA_PLAY_PAUSE = 0xB3
_KEYEVENTF_KEYUP     = 0x0002


class ControleMidia:
    """
    Controle de midia e volume do Windows.

    - Play/pause, proxima e anterior usam as teclas de midia virtuais
      (funcionam com Spotify, YouTube no navegador, etc.).
    - Volume: usa pycaw se instalado (valor absoluto e leitura do volume
      atual). Sem pycaw, cai para teclas de volume (cada toque = 2%),
      sem leitura do valor atual.

    Chamado somente pela thread principal (COM).
    """

    def __init__(self, simulado: bool = False) -> None:
        self._simulado = simulado  # modo texto: registra em vez de executar
        self._user32 = None
        if sys.platform == "win32" and not simulado:
            import ctypes
            self._user32 = ctypes.windll.user32
        self._avisou_pycaw = False

    # ----------------------------------------------------------
    #  TECLAS
    # ----------------------------------------------------------

    def _tecla(self, vk: int, vezes: int = 1) -> bool:
        if self._simulado:
            logger.info("[simulado] tecla de midia/volume %#x x%d", vk, vezes)
            return True
        if self._user32 is None:
            return False
        for _ in range(vezes):
            self._user32.keybd_event(vk, 0, 0, 0)
            self._user32.keybd_event(vk, 0, _KEYEVENTF_KEYUP, 0)
            time.sleep(0.01)
        return True

    def play_pause(self) -> bool:
        return self._tecla(_VK_MEDIA_PLAY_PAUSE)

    def proxima(self) -> bool:
        return self._tecla(_VK_MEDIA_NEXT)

    def anterior(self) -> bool:
        return self._tecla(_VK_MEDIA_PREV)

    # ----------------------------------------------------------
    #  VOLUME (pycaw opcional)
    # ----------------------------------------------------------

    def _endpoint(self):
        if self._simulado:
            return None
        try:
            from ctypes import POINTER, cast
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        except ImportError:
            if not self._avisou_pycaw:
                logger.info(
                    "pycaw nao instalado: volume por teclas (pip install pycaw "
                    "para volume absoluto)."
                )
                self._avisou_pycaw = True
            return None

        try:
            dispositivo = AudioUtilities.GetSpeakers()
            # Versoes recentes do pycaw expoem EndpointVolume diretamente.
            endpoint = getattr(dispositivo, "EndpointVolume", None)
            if endpoint is not None:
                return endpoint
            interface = dispositivo.Activate(
                IAudioEndpointVolume._iid_, CLSCTX_ALL, None
            )
            return cast(interface, POINTER(IAudioEndpointVolume))
        except Exception as exc:
            logger.debug("Falha ao obter endpoint de volume: %s", exc)
            return None

    def obter_volume(self) -> int | None:
        endpoint = self._endpoint()
        if endpoint is None:
            return None
        try:
            return round(endpoint.GetMasterVolumeLevelScalar() * 100)
        except Exception as exc:
            logger.debug("Falha ao ler volume: %s", exc)
            return None

    def definir_volume(self, percentual: int) -> int | None:
        """Retorna o volume resultante se conhecido (pycaw), senao None."""
        percentual = max(0, min(100, percentual))
        endpoint = self._endpoint()
        if endpoint is not None:
            try:
                endpoint.SetMasterVolumeLevelScalar(percentual / 100.0, None)
                return percentual
            except Exception as exc:
                logger.debug("pycaw falhou ao definir volume: %s", exc)

        # Fallback: zera com 50 toques para baixo e sobe (percentual / 2) toques.
        self._tecla(_VK_VOLUME_DOWN, 50)
        if percentual > 0:
            self._tecla(_VK_VOLUME_UP, round(percentual / 2))
        return None

    def ajustar_volume(self, delta: int) -> int | None:
        """Soma delta (positivo ou negativo) ao volume. Retorna valor final se conhecido."""
        atual = self.obter_volume()
        if atual is not None:
            return self.definir_volume(atual + delta)

        vezes = max(1, round(abs(delta) / 2))
        self._tecla(_VK_VOLUME_UP if delta > 0 else _VK_VOLUME_DOWN, vezes)
        return None

    def mutar(self, silenciar: bool) -> bool:
        """
        Retorna True se o estado foi definido de forma explicita (pycaw).
        Sem pycaw, apenas alterna o mudo (retorna False).
        """
        endpoint = self._endpoint()
        if endpoint is not None:
            try:
                endpoint.SetMute(1 if silenciar else 0, None)
                return True
            except Exception as exc:
                logger.debug("pycaw falhou ao alterar mudo: %s", exc)
        self._tecla(_VK_VOLUME_MUTE)
        return False


# ==============================================================
#  CONTROLE DE SISTEMA (print e bloqueio)
# ==============================================================

_VK_LWIN     = 0x5B
_VK_SHIFT    = 0x10
_VK_CONTROL  = 0x11
_VK_ALT      = 0x12
_VK_TAB      = 0x09
_VK_F4       = 0x73
_VK_S        = 0x53
_VK_D        = 0x44
_VK_RETURN   = 0x0D
_VK_BACK     = 0x08
_VK_SNAPSHOT = 0x2C
_VK_LEFT     = 0x25
_VK_UP       = 0x26
_VK_RIGHT    = 0x27
_VK_DOWN     = 0x28

_KEYEVENTF_EXTENDEDKEY = 0x0001
_KEYEVENTF_UNICODE     = 0x0004
_TECLAS_ESTENDIDAS = frozenset([_VK_LEFT, _VK_UP, _VK_RIGHT, _VK_DOWN])

_ES_CONTINUOUS       = 0x80000000
_ES_SYSTEM_REQUIRED  = 0x00000001
_ES_DISPLAY_REQUIRED = 0x00000002


class ControleSistema:
    """
    Teclado, janelas, tela e energia do Windows.

    - Captura (area): Win+Shift+S. Captura (tela inteira): Win+PrtSc salva um
      arquivo; PrtSc sozinho copia a tela para a area de transferencia.
    - Bloqueio: LockWorkStation() em vez de simular Win+L, que o Windows
      ignora quando gerado por software.
    - Janelas e desktops: Win+D, Alt+Tab, Alt+F4, Win+setas, Win+Shift+setas
      (monitores), Win+Ctrl+D/setas/F4 (desktops virtuais), Win+Tab.
    - Tela: SC_MONITORPOWER; lixeira: SHQueryRecycleBin/SHEmptyRecycleBin;
      exibicao: DisplaySwitch.exe; manter acordado: SetThreadExecutionState.
    - Digitacao: SendInput com KEYEVENTF_UNICODE (acentos sem mexer na area
      de transferencia).

    simulado=True (modo texto): nada e executado; cada acao e registrada em
    self.registro e no log. Chamado somente pela thread principal (exceto
    suspender(), executado pelo timer de suspensao).
    """

    def __init__(self, simulado: bool = False) -> None:
        self._simulado = simulado
        self._user32 = None
        self._ctypes = None
        self._estruturas = None
        self.registro: list[str] = []
        self._sequencia_sim = 0
        self._imagem_sim = False
        if sys.platform == "win32" and not simulado:
            import ctypes
            self._ctypes = ctypes
            self._user32 = ctypes.windll.user32

    # --- infraestrutura ---

    def _registrar(self, acao: str) -> bool:
        self.registro.append(acao)
        logger.info("[simulado] %s", acao)
        return True

    @staticmethod
    def _flags(vk: int) -> int:
        return _KEYEVENTF_EXTENDEDKEY if vk in _TECLAS_ESTENDIDAS else 0

    def _combo(self, *teclas: int, pausa: float = 0.01) -> bool:
        if self._simulado:
            return self._registrar("teclas " + "+".join(f"{vk:#x}" for vk in teclas))
        if self._user32 is None:
            return False
        for vk in teclas:
            self._user32.keybd_event(vk, 0, self._flags(vk), 0)
            time.sleep(pausa)
        for vk in reversed(teclas):
            self._user32.keybd_event(vk, 0, self._flags(vk) | _KEYEVENTF_KEYUP, 0)
            time.sleep(pausa)
        return True

    # --- captura e bloqueio ---

    def captura_tela(self) -> bool:
        """Win+Shift+S: recorte; a imagem vai para a area de transferencia."""
        if self._simulado:
            self._sequencia_sim += 1
            self._imagem_sim = True
            return self._registrar("captura de tela (area)")
        return self._combo(_VK_LWIN, _VK_SHIFT, _VK_S)

    def captura_tela_cheia(self) -> bool:
        """Win+PrtSc: salva a tela inteira em Imagens\\Capturas de Tela."""
        if self._simulado:
            return self._registrar("captura de tela inteira (arquivo)")
        return self._combo(_VK_LWIN, _VK_SNAPSHOT)

    def copiar_tela_inteira(self) -> bool:
        """PrtSc: copia a tela inteira para a area de transferencia."""
        if self._simulado:
            self._sequencia_sim += 1
            self._imagem_sim = True
            return self._registrar("PrtSc (tela inteira para a area de transferencia)")
        return self._combo(_VK_SNAPSHOT)

    def bloquear(self) -> bool:
        if self._simulado:
            return self._registrar("bloquear sessao")
        if self._user32 is None:
            return False
        return bool(self._user32.LockWorkStation())

    # --- janelas, monitores e desktops virtuais ---

    def mostrar_area_trabalho(self) -> bool:
        return self._combo(_VK_LWIN, _VK_D)

    def trocar_janela(self) -> bool:
        return self._combo(_VK_ALT, _VK_TAB, pausa=0.03)

    def fechar_janela(self) -> bool:
        return self._combo(_VK_ALT, _VK_F4)

    def maximizar_janela(self) -> bool:
        return self._combo(_VK_LWIN, _VK_UP)

    def minimizar_janela(self) -> bool:
        return self._combo(_VK_LWIN, _VK_DOWN)

    def janela_esquerda(self) -> bool:
        return self._combo(_VK_LWIN, _VK_LEFT)

    def janela_direita(self) -> bool:
        return self._combo(_VK_LWIN, _VK_RIGHT)

    def mover_para_monitor(self, lado: str) -> bool:
        """Win+Shift+Seta: move a janela em foco para o monitor ao lado."""
        seta = _VK_LEFT if lado == "esquerda" else _VK_RIGHT
        return self._combo(_VK_LWIN, _VK_SHIFT, seta)

    def visao_tarefas(self) -> bool:
        return self._combo(_VK_LWIN, _VK_TAB)

    def desktop_novo(self) -> bool:
        return self._combo(_VK_LWIN, _VK_CONTROL, _VK_D)

    def desktop_proximo(self) -> bool:
        return self._combo(_VK_LWIN, _VK_CONTROL, _VK_RIGHT)

    def desktop_anterior(self) -> bool:
        return self._combo(_VK_LWIN, _VK_CONTROL, _VK_LEFT)

    def desktop_fechar(self) -> bool:
        return self._combo(_VK_LWIN, _VK_CONTROL, _VK_F4)

    # --- tela, energia e exibicao ---

    def desligar_tela(self) -> bool:
        """Apaga o monitor (qualquer movimento do mouse o reacende)."""
        if self._simulado:
            return self._registrar("desligar tela")
        if self._user32 is None:
            return False
        # HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, 2 = desligar
        self._user32.PostMessageW(0xFFFF, 0x0112, 0xF170, 2)
        return True

    def suspender(self) -> bool:
        if self._simulado:
            return self._registrar("suspender")
        if self._ctypes is None:
            return False
        try:
            return bool(self._ctypes.windll.powrprof.SetSuspendState(0, 0, 0))
        except (AttributeError, OSError) as exc:
            logger.error("Falha ao suspender: %s", exc)
            return False

    def itens_lixeira(self) -> int | None:
        """
        Quantidade de itens na lixeira (todas as unidades), ou None se nao for
        possivel consultar (nesse caso a confirmacao e pedida sem a contagem).
        """
        if self._simulado:
            return 3
        if self._ctypes is None:
            return None
        ctypes = self._ctypes
        from ctypes import wintypes

        class SHQUERYRBINFO(ctypes.Structure):
            _pack_ = 1
            _fields_ = [
                ("cbSize", wintypes.DWORD),
                ("i64Size", ctypes.c_longlong),
                ("i64NumItems", ctypes.c_longlong),
            ]

        info = SHQUERYRBINFO()
        info.cbSize = ctypes.sizeof(SHQUERYRBINFO)
        try:
            resultado = ctypes.windll.shell32.SHQueryRecycleBinW(None, ctypes.byref(info))
        except (AttributeError, OSError) as exc:
            logger.error("Falha ao consultar a lixeira: %s", exc)
            return None
        if resultado != 0:
            logger.debug("SHQueryRecycleBin retornou %#x", resultado & 0xFFFFFFFF)
            return None
        return int(info.i64NumItems)

    def esvaziar_lixeira(self) -> str:
        """Retorna 'ok', 'vazia' ou 'erro'."""
        if self._simulado:
            self._registrar("esvaziar lixeira")
            return "ok"
        if self._ctypes is None:
            return "erro"
        try:
            from ctypes import wintypes
            funcao = self._ctypes.windll.shell32.SHEmptyRecycleBinW
            funcao.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.DWORD]
            funcao.restype = self._ctypes.c_long
            # SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND
            resultado = funcao(None, None, 0x7) & 0xFFFFFFFF
        except (AttributeError, OSError) as exc:
            logger.error("Falha ao esvaziar a lixeira: %s", exc)
            return "erro"
        if resultado == 0:
            return "ok"
        if resultado == 0x8000FFFF:  # E_UNEXPECTED: a lixeira ja estava vazia
            return "vazia"
        logger.error("SHEmptyRecycleBin retornou %#x", resultado)
        return "erro"

    def modo_exibicao(self, modo: str) -> bool:
        """DisplaySwitch.exe: clone, extend, internal ou external."""
        if modo not in ("clone", "extend", "internal", "external"):
            return False
        if self._simulado:
            return self._registrar(f"modo de exibicao {modo}")
        executavel = (
            Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "DisplaySwitch.exe"
        )
        try:
            subprocess.Popen([str(executavel), f"/{modo}"], shell=False)
            return True
        except OSError as exc:
            logger.error("Falha ao executar DisplaySwitch: %s", exc)
            return False

    def menu_projecao(self) -> bool:
        """Win+P: abre o menu de projecao do Windows."""
        return self._combo(_VK_LWIN, 0x50)

    def manter_acordado(self, ativo: bool) -> bool:
        """Impede (ou volta a permitir) que o PC durma e que a tela apague."""
        if self._simulado:
            return self._registrar(f"manter acordado = {ativo}")
        if self._ctypes is None:
            return False
        flags = _ES_CONTINUOUS
        if ativo:
            flags |= _ES_SYSTEM_REQUIRED | _ES_DISPLAY_REQUIRED
        funcao = self._ctypes.windll.kernel32.SetThreadExecutionState
        funcao.argtypes = [self._ctypes.c_uint]
        return bool(funcao(flags))

    # --- area de transferencia ---

    def area_tem_imagem(self) -> bool:
        if self._simulado:
            return self._imagem_sim
        if self._user32 is None:
            return False
        # CF_BITMAP, CF_DIB, CF_DIBV5
        return any(self._user32.IsClipboardFormatAvailable(f) for f in (2, 8, 17))

    def sequencia_area(self) -> int:
        """Numero que muda a cada alteracao da area de transferencia."""
        if self._simulado:
            return self._sequencia_sim
        if self._user32 is None:
            return 0
        return int(self._user32.GetClipboardSequenceNumber())

    # --- digitacao ---

    def pressionar_enter(self) -> bool:
        return self._combo(_VK_RETURN)

    def apagar(self) -> bool:
        return self._combo(_VK_BACK)

    def apagar_palavra(self) -> bool:
        return self._combo(_VK_CONTROL, _VK_BACK)

    def _montar_estruturas(self):
        """Estruturas do SendInput (somente Windows, criadas sob demanda)."""
        if self._estruturas is not None:
            return self._estruturas
        ctypes = self._ctypes
        from ctypes import wintypes

        class KEYBDINPUT(ctypes.Structure):
            _fields_ = [
                ("wVk", wintypes.WORD),
                ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD),
                ("dwExtraInfo", ctypes.c_size_t),
            ]

        class MOUSEINPUT(ctypes.Structure):
            _fields_ = [
                ("dx", wintypes.LONG),
                ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD),
                ("dwExtraInfo", ctypes.c_size_t),
            ]

        class HARDWAREINPUT(ctypes.Structure):
            _fields_ = [
                ("uMsg", wintypes.DWORD),
                ("wParamL", wintypes.WORD),
                ("wParamH", wintypes.WORD),
            ]

        class _Uniao(ctypes.Union):
            _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

        class INPUT(ctypes.Structure):
            _anonymous_ = ("u",)
            _fields_ = [("type", wintypes.DWORD), ("u", _Uniao)]

        self._estruturas = (INPUT, KEYBDINPUT)
        return self._estruturas

    def digitar(self, texto: str) -> bool:
        """Digita o texto na janela em foco (Unicode; quebra de linha vira Enter)."""
        if self._simulado:
            return self._registrar(f"digitar {texto!r}")
        if self._user32 is None or self._ctypes is None:
            return False

        eventos: list[tuple[int, int, int]] = []
        for caractere in texto:
            if caractere == "\r":
                continue
            if caractere == "\n":
                eventos.append((_VK_RETURN, 0, 0))
                eventos.append((_VK_RETURN, 0, _KEYEVENTF_KEYUP))
                continue
            dados = caractere.encode("utf-16-le")
            for i in range(0, len(dados), 2):
                unidade = int.from_bytes(dados[i:i + 2], "little")
                eventos.append((0, unidade, _KEYEVENTF_UNICODE))
                eventos.append((0, unidade, _KEYEVENTF_UNICODE | _KEYEVENTF_KEYUP))

        INPUT, KEYBDINPUT = self._montar_estruturas()
        for inicio in range(0, len(eventos), 200):
            bloco = eventos[inicio:inicio + 200]
            entradas = (INPUT * len(bloco))()
            for indice, (vk, scan, flags) in enumerate(bloco):
                entradas[indice].type = 1  # INPUT_KEYBOARD
                entradas[indice].ki = KEYBDINPUT(vk, scan, flags, 0, 0)
            enviados = self._user32.SendInput(
                len(bloco), entradas, self._ctypes.sizeof(INPUT)
            )
            if enviados != len(bloco):
                logger.warning("SendInput enviou %d de %d eventos.", enviados, len(bloco))
                return False
            time.sleep(0.005)
        return True


# ==============================================================
#  LANCADOR DE APLICATIVOS
# ==============================================================

class AppLauncher:
    """Abre aplicativos locais sem shell=True."""

    _APPS: dict[str, list[str]] = {}

    def __init__(self, simulado: bool = False) -> None:
        self._simulado = simulado
        local_app = os.environ.get("LOCALAPPDATA", "")
        app_data  = os.environ.get("APPDATA", "")

        self._APPS = {
            "vs code":                ["code"],
            "visual studio":          ["code"],
            "discord":                [
                os.path.join(local_app, "Discord", "Update.exe"),
                "--processStart", "Discord.exe",
            ],
            "spotify":                [os.path.join(app_data, "Spotify", "Spotify.exe")],
            "chrome":                 [
                r"C:\Program Files\Google\Chrome\Application\chrome.exe"
            ],
            "brave":                  [str(CFG.caminho_brave)],
            "jogo":                   [r"C:\Program Files\HoYoPlay\launcher.exe"],
            "explorer":               ["explorer.exe"],
            "bloco de notas":         ["notepad.exe"],
            "calculadora":            ["calc.exe"],
            "terminal":               ["wt.exe"],
            "gerenciador de tarefas": ["taskmgr.exe"],
            "configuracoes":          ["explorer.exe", "ms-settings:"],
            "downloads":              ["explorer.exe", "shell:Downloads"],
            "projetos":               ["explorer.exe", str(CFG.caminho_projeto)],
        }

    def abrir(self, chave: str) -> bool:
        cmd = self._APPS.get(chave)
        if not cmd:
            return False
        if self._simulado:
            logger.info("[simulado] abrir %s: %s", chave, cmd)
            return True
        try:
            subprocess.Popen(cmd, shell=False)
            return True
        except FileNotFoundError:
            logger.error("Executavel nao encontrado: %s -> %s", chave, cmd)
            return False
        except OSError as exc:
            logger.exception("Erro ao abrir %s: %s", chave, exc)
            return False

    @property
    def chaves(self) -> list[str]:
        return list(self._APPS.keys())


# ==============================================================
#  PROCESSADOR DE COMANDOS
# ==============================================================

# Padroes de midia/volume aplicados sobre o comando sem acentos.
_RE_VOL_SUBIR = re.compile(
    r"\b(?:aument|sub|sob|elev)\w*\s+(?:o\s+)?(?:volume|som)(?:\s+(?:em\s+)?(\d{1,2}))?\b"
    r"|\bvolume\s+mais\s+alto\b"
)
_RE_VOL_DESCER = re.compile(
    r"\b(?:diminu|abaix|baix|reduz)\w*\s+(?:o\s+)?(?:volume|som)(?:\s+(?:em\s+)?(\d{1,2}))?\b"
    r"|\bvolume\s+mais\s+baixo\b"
)
_RE_VOL_ABS = re.compile(
    r"\bvolume\s+(?:para\s+|em\s+|no\s+)?(\d{1,3})\s*(?:%|por\s*cento)?"
)
_RE_VOL_CONSULTA = re.compile(r"\bqual\s+(?:e\s+)?(?:o\s+)?volume\b")
_RE_DESMUTAR = re.compile(
    r"\b(?:desmutar|tirar\s+do\s+mudo|voltar\s+o\s+som|restaurar\s+o\s+som|ativar\s+o\s+som)\b"
)
_RE_MUTAR = re.compile(r"\b(?:mutar|mudo|tirar\s+o\s+som)\b")
_RE_PROXIMA = re.compile(
    r"\b(?:proxima|proximo)\s+(?:musica|faixa)\b"
    r"|\b(?:pular|passar)\s+(?:a\s+)?(?:musica|faixa)\b"
)
_RE_ANTERIOR = re.compile(
    r"\b(?:musica|faixa)\s+anterior\b"
    r"|\bvoltar\s+(?:a\s+)?(?:musica|faixa)\b"
)
_CMDS_PLAY_PAUSE = frozenset([
    "pausar", "pausa", "pause", "play", "continuar", "retomar",
    "pausar musica", "parar musica", "continuar musica", "tocar musica",
    "dar play", "da play",
])
_CMDS_PROXIMA = frozenset(["proxima", "proximo", "pular"])
_CMDS_ANTERIOR = frozenset(["anterior"])

# Captura de tela, bloqueio e janelas.
_RE_PRINT = re.compile(
    r"\b(?:print\w*|screenshot|captur\w+\s+(?:de\s+|da\s+)?tela|recort\w+\s+(?:de\s+|da\s+)?tela)\b"
)
_RE_PRINT_CHEIA = re.compile(r"\b(?:inteira|cheia|salvar|salva|direto|rapido|arquivo)\b")
_RE_BLOQUEAR = re.compile(
    r"\b(?:bloque\w+|trav\w+)\s+(?:o\s+|a\s+)?(?:computador|pc|tela|notebook|maquina)\b"
)
_RE_AREA_TRABALHO = re.compile(
    r"\b(?:mostrar|ver)\s+(?:a\s+)?(?:area\s+de\s+trabalho|desktop)\b|\bminimizar\s+tudo\b"
)
_RE_TROCAR_JANELA = re.compile(
    r"\b(?:trocar|alternar|mudar)\s+(?:de\s+|a\s+)?janela\b|\bproxima\s+janela\b"
)
_RE_FECHAR_JANELA = re.compile(r"\bfechar\s+(?:a\s+)?janela\b")
_RE_MAXIMIZAR = re.compile(r"\bmaximizar\s+(?:a\s+)?janela\b")
_RE_MINIMIZAR = re.compile(r"\bminimizar\s+(?:a\s+)?janela\b")
_RE_JANELA_LADO = re.compile(r"\bjanela\b.*\b(esquerda|direita)\b")

# Timers (em memoria; nao sobrevivem a reinicializacao do Jairo).
_PALAVRAS_NUM = {
    "um": 1, "uma": 1, "dois": 2, "duas": 2, "tres": 3, "quatro": 4,
    "cinco": 5, "seis": 6, "sete": 7, "oito": 8, "nove": 9, "dez": 10,
    "quinze": 15, "vinte": 20, "trinta": 30,
}
_RE_DURACAO = re.compile(
    r"\b(\d+|" + "|".join(_PALAVRAS_NUM) + r")\s*(segundos?|minutos?|horas?)\b"
)
_RE_TIMER = re.compile(
    r"\b(?:timer|temporizador|me\s+avis\w*|me\s+lembr\w*|avisa\s+em)\b"
)
_RE_CANCELAR_TIMERS = re.compile(
    r"\bcancel\w*\s+(?:o\s+|os\s+)?(?:timers?|temporizadores?|lembretes?)\b"
)
_RE_QUANTO_FALTA = re.compile(
    r"\b(?:quanto\s+(?:tempo\s+)?falta|meus\s+timers|ver\s+timers|listar\s+timers)\b"
)

# Informacoes.
_RE_DATA = re.compile(r"\b(?:que\s+dia|qual\s+(?:e\s+)?a\s+data|data\s+de\s+hoje)\b")
_CMDS_REPETIR = frozenset([
    "repetir", "repete", "repita", "fala de novo", "fale de novo", "como assim",
])
_CMDS_AJUDA = frozenset(["ajuda", "me ajuda", "socorro", "quais comandos", "o que voce faz"])
_DIAS_SEMANA = [
    "segunda-feira", "terça-feira", "quarta-feira", "quinta-feira",
    "sexta-feira", "sábado", "domingo",
]
_MESES = [
    "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
]

_AJUDA_COMPLETA = """
Comandos (sempre comecando com 'Jairo'):
  Captura:   tirar print | print da tela inteira (salva arquivo) |
             enviar print para NOME | enviar print da tela inteira para NOME
  Sistema:   bloquear o computador | desligar/reiniciar/suspender o computador |
             cancelar desligamento / reinicializacao / suspensao |
             desligar a tela | esvaziar a lixeira (pede confirmacao)
  Confirmar: diga 'confirmar' (com ou sem 'Jairo') ou 'cancelar' depois do pedido
  Janelas:   minimizar tudo | trocar de janela | fechar janela | maximizar janela |
             minimizar janela | janela para a esquerda/direita |
             mover janela para o outro monitor | novo desktop | proximo desktop |
             desktop anterior | fechar desktop | visao de tarefas
  Tela:      modo apresentacao | sair do modo apresentacao | estender tela |
             somente a tela do pc | somente a segunda tela
  Ditado:    digitar TEXTO (virgula, ponto final, nova linha...) | iniciar ditado |
             parar ditado | enter | apagar | apagar palavra
  Midia:     pausar/play | proxima musica | musica anterior
  Volume:    aumentar/diminuir volume [em N] | volume N | mutar/desmutar | qual o volume
  Timers:    timer de 5 minutos | me lembra em 10 minutos de X | quanto falta |
             cancelar timers
  WhatsApp:  ler mensagens | ler a ultima mensagem da X | o que a X mandou |
             enviar mensagem para X dizendo Y | ... para X as 18h dizendo Y (agenda) |
             responder para X dizendo Y | responder dizendo Y |
             mensagens agendadas | cancelar mensagens agendadas |
             verificar mensagens | diagnosticar whatsapp
  Apps:      abre [vs code, discord, spotify, chrome, brave, projetos, downloads,
             configuracoes, ...] | preparar ambiente
  Web:       pesquisar X | youtube X
  Contas:    quanto e 15 + 14 | 20 por cento de 150 | raiz quadrada de 144
  Contatos:  buscar contato gustavo (lista os cadastrados na agenda) |
             chame NOME de APELIDO (grava o apelido no contatos.txt, com backup)
  Info:      que horas sao | que dia e hoje | repetir | ajuda
  Microfone: recalibrar microfone
  Modo:      modo silencioso (so bipes) | modo falante | silenciar (standby)
  Windows:   iniciar com o windows | nao iniciar com o windows
"""

_AJUDA_FALADA = (
    "Posso tirar print, bloquear o computador, controlar janelas, música e volume, "
    "fazer contas, criar timers, ler e agendar mensagens do WhatsApp, digitar o que você ditar, "
    "abrir aplicativos, pesquisar, aprender apelidos dos contatos, "
    "e dizer a hora e a data. Diga modo silencioso para eu responder só com bipes."
)


# Ditado: pontuacao falada, formatacao e comandos de edicao.
_SUBST_DITADO: list[tuple[str, str]] = [
    (r"\bponto\s+e\s+v[ií]rgula\b", ";"),
    (r"\bponto\s+de\s+interroga[cç][aã]o\b", "?"),
    (r"\bponto\s+de\s+exclama[cç][aã]o\b", "!"),
    (r"\bponto\s+final\b", "."),
    (r"\bdois\s+pontos\b", ":"),
    (r"\bretic[eê]ncias\b", "..."),
    (r"\bv[ií]rgula\b", ","),
    (r"\bnova\s+linha\b", "\n"),
    (r"\b(?:novo\s+)?par[aá]grafo\b", "\n\n"),
    (r"\babre\s+par[eê]nteses\b", "("),
    (r"\bfecha\s+par[eê]nteses\b", ")"),
]


def _formatar_ditado(texto: str) -> str:
    """
    Converte a fala em texto: pontuacao falada vira simbolo ("virgula" -> ","),
    espacos antes da pontuacao somem e a primeira letra de cada frase vira
    maiuscula. Ex.: "ola tudo bem virgula como vai ponto de interrogacao"
    -> "Ola tudo bem, como vai?".
    """
    t = " " + texto.strip() + " "
    for padrao, simbolo in _SUBST_DITADO:
        t = re.sub(padrao, " " + simbolo + " ", t, flags=re.IGNORECASE)
    t = re.sub(r"[ \t]+([,.;:!?)])", r"\1", t)
    t = re.sub(r"\([ \t]+", "(", t)
    t = re.sub(r"[ \t]*\n[ \t]*", "\n", t)
    t = re.sub(r"[ \t]{2,}", " ", t).strip(" \t")
    return re.sub(
        r"(^|[.!?]\s+|\n)([a-zà-ú])",
        lambda m: m.group(1) + m.group(2).upper(),
        t,
    )


class HorarioInvalido(ValueError):
    """Horario falado invalido ou ja passado (a mensagem e falada ao usuario)."""


_NUMS_EXTENSO = "|".join(sorted(_PALAVRAS_NUM, key=len, reverse=True))
_RE_REL = re.compile(
    r"\b(?:daqui\s+a|em)\s+(?:(\d+|" + _NUMS_EXTENSO + r")\s*(segundos?|minutos?|horas?)"
    r"|meia\s+hora)\b"
)
_RE_DIA = re.compile(r"\b(hoje|amanha|depois\s+de\s+amanha)\b")
_RE_MEIO_DIA = re.compile(r"\bmeio[\s-]?dia\b")
_RE_MEIA_NOITE = re.compile(r"\bmeia[\s-]?noite\b")
_RE_RELOGIO = re.compile(
    r"\b(?P<pre>(?:para\s+)?(?:as|a)\s+)?(?P<h>\d{1,2})"
    r"(?:(?P<sep>\s*(?::|h(?:oras?)?))\s*(?:e\s+)?(?P<m1>\d{1,2})?|\s+e\s+(?P<m2>\d{1,2}))?"
    r"(?:\s+da\s+(?P<per>manha|tarde|noite|madrugada))?\b"
)


def _limpar_resto(texto: str) -> str:
    """Tira conectores soltos que sobram ao remover a expressao de horario."""
    t = " ".join(texto.split())
    for _ in range(3):
        t = re.sub(r"^(?:para|pra|as|a|em|de|do|da|daqui)\s+", "", t)
        t = re.sub(r"\s+(?:para|pra|as|a|em|de|daqui)$", "", t)
    return t.strip()


def _parse_quando(texto: str, agora: datetime) -> tuple[datetime, str] | None:
    """
    Procura um horario em um texto SEM acentos e em minusculas.
    Retorna (instante, texto_sem_o_horario) ou None se nao houver horario.
    Levanta HorarioInvalido se o horario for invalido ou ja tiver passado.

    Formas aceitas: "em 30 minutos", "daqui a 2 horas", "em meia hora",
    "as 18h", "as 18:30", "as 18 horas e 30", "as 6 da tarde", "meio dia",
    "meia noite", e os prefixos "hoje", "amanha", "depois de amanha".
    Sem periodo (manha/tarde/noite) e com hora de 1 a 11, vale o proximo
    horario futuro entre as duas leituras (ex.: "as 6" as 14h -> 18h).
    """
    # --- relativo ---
    rel = _RE_REL.search(texto)
    if rel:
        if rel.group(1) is None:
            segundos = 1800
        else:
            valor = rel.group(1)
            quantidade = int(valor) if valor.isdigit() else _PALAVRAS_NUM[valor]
            unidade = rel.group(2)
            if unidade.startswith("seg"):
                segundos = quantidade
            elif unidade.startswith("min"):
                segundos = quantidade * 60
            else:
                segundos = quantidade * 3600
        if not 1 <= segundos <= 7 * 86400:
            raise HorarioInvalido("O prazo deve ficar entre 1 segundo e 7 dias.")
        quando = (agora + timedelta(seconds=segundos)).replace(microsecond=0)
        return quando, _limpar_resto(texto[:rel.start()] + " " + texto[rel.end():])

    # --- dia e relogio ---
    dia = _RE_DIA.search(texto)
    deslocamento = None
    if dia:
        deslocamento = {"hoje": 0, "amanha": 1}.get(dia.group(1), 2)

    hora = minuto = None
    ambiguo = False
    span = None

    meio_dia = _RE_MEIO_DIA.search(texto)
    meia_noite = _RE_MEIA_NOITE.search(texto)
    if meio_dia:
        hora, minuto, span = 12, 0, meio_dia.span()
    elif meia_noite:
        hora, minuto, span = 0, 0, meia_noite.span()
    else:
        for m in _RE_RELOGIO.finditer(texto):
            if not (m.group("pre") or m.group("sep") or m.group("per")):
                continue  # numero solto: nao e horario
            h = int(m.group("h"))
            mi = int(m.group("m1") or m.group("m2") or 0)
            if mi > 59 or h > 24 or (h == 24 and mi > 0):
                continue
            periodo = m.group("per")
            ambiguo = periodo is None and 1 <= h <= 11
            if periodo in ("tarde", "noite") and h < 12:
                h += 12
            elif periodo in ("manha", "madrugada") and h == 12:
                h = 0
            hora, minuto, span = h % 24, mi, m.span()
            break

    if hora is None:
        if dia:
            raise HorarioInvalido(
                "Diga também a hora, por exemplo: amanhã às 9 horas."
            )
        return None

    horas_possiveis = [hora]
    if ambiguo:
        horas_possiveis.append((hora + 12) % 24)

    def instante(data: datetime, hh: int) -> datetime:
        return data.replace(hour=hh, minute=minuto, second=0, microsecond=0)

    if deslocamento is None:
        candidatos = [
            instante(agora + timedelta(days=d), hh)
            for d in (0, 1) for hh in horas_possiveis
        ]
        quando = min(c for c in candidatos if c > agora)
    elif deslocamento == 0:
        futuros = [c for c in (instante(agora, hh) for hh in horas_possiveis) if c > agora]
        if not futuros:
            raise HorarioInvalido("Esse horário já passou hoje.")
        quando = min(futuros)
    else:
        quando = instante(agora + timedelta(days=deslocamento), horas_possiveis[0])

    cortes = sorted([span] + ([dia.span()] if dia else []), reverse=True)
    resto = texto
    for inicio, fim in cortes:
        resto = resto[:inicio] + " " + resto[fim:]
    return quando, _limpar_resto(resto)


def _descrever_quando(quando: datetime, agora: datetime | None = None) -> str:
    """Texto falado: "hoje às 18 horas e 30 minutos", "amanhã às 9 horas"."""
    agora = agora or datetime.now()
    dias = (quando.date() - agora.date()).days
    if dias == 0:
        dia = "hoje"
    elif dias == 1:
        dia = "amanhã"
    else:
        dia = f"dia {quando.day} de {_MESES[quando.month - 1]}"
    hora = f"às {quando.hour} horas"
    if quando.minute:
        hora += f" e {quando.minute} minutos"
    return f"{dia} {hora}"


# WhatsApp: enviar/agendar, responder, ler conversa, enviar print.
_RE_ENVIAR_MSG = re.compile(
    r"\b(?:enviar|mandar|mande|envie|agendar|agende|programar|programe)\s+"
    r"(?:uma\s+|a\s+)?(?:mensagem|msg|zap)\s+(?:para|pra)\b"
)
_RE_PREFIXO_ENVIO = re.compile(
    r"^\s*(?:jairo\s+)?(?:enviar|mandar|mande|envie|agendar|agende|programar|programe)\s+"
    r"(?:uma\s+|a\s+)?(?:mensagem|msg|zap)\s+(?:para|pra)\s+"
)
_RE_RESPONDER = re.compile(r"^(?:responder|responde|responda)\b")
_RE_PREFIXO_RESPONDER = re.compile(
    r"^\s*(?:responder|responde|responda)\s*(?:(?:para|pra|a|ao)\s+)*"
)
_NOMES_ULTIMA = frozenset([
    "ultima mensagem", "ultima", "mensagem", "ultimo contato", "ultima conversa",
    "conversa",
])
_QTD = r"(\d+|uma|duas|tres|quatro|cinco)"
_RE_LER_CHAT = re.compile(
    r"^(?:ler|leia|le)\s+(?:(?:a|as|o|os)\s+)?(?:" + _QTD + r"\s+)?(?:ultim[ao]s?\s+)?"
    r"(?:" + _QTD + r"\s+)?mensage(?:m|ns)\s+(?:da|do|de)\s+(.+)$"
)
_RE_LER_CHAT2 = re.compile(
    r"^o\s+que\s+(?:o\s+|a\s+)?(.+?)\s+(?:mandou|disse|falou|escreveu)\b"
)
_RE_ENVIAR_PRINT = re.compile(
    r"^(?:enviar|mandar|mande|envie|manda)\s+(?:o\s+|um\s+|uma\s+)?"
    r"(?:print|captura|screenshot)\b(.*?)\b(?:para|pra)\s+(.+)$"
)
_RE_LISTAR_AGENDADAS = re.compile(r"\bmensagens\s+agendadas\b|\bagendamentos\b")
_RE_CANCELAR_AGENDADAS = re.compile(
    r"\bcancel\w*\s+(?:todas\s+)?(?:as\s+|a\s+|os\s+)?"
    r"(?:mensage(?:m|ns)\s+agendad[ao]s?|agendamentos?|envios?\s+agendad[ao]s?)"
    r"(?:\s+(?:para|do|da|de)\s+(.+))?$"
)

# Ditado e edicao de texto.
_RE_DIGITAR = re.compile(
    r"^\s*(?:digitar|digite|escrever|escreva|ditar|dite)\s+(.+)$",
    re.IGNORECASE | re.DOTALL,
)
_CMDS_ENTER = frozenset(["enter", "dar enter", "da enter", "apertar enter", "pressionar enter"])
_CMDS_APAGAR = frozenset(["apagar", "apaga", "backspace"])
_CMDS_APAGAR_PALAVRA = frozenset([
    "apagar palavra", "apaga palavra", "apagar a palavra", "apagar ultima palavra",
])
_CMDS_INICIAR_DITADO = frozenset([
    "iniciar ditado", "iniciar o ditado", "modo ditado", "comecar ditado", "ativar ditado",
])
_CMDS_PARAR_DITADO = frozenset([
    "parar ditado", "parar o ditado", "fim do ditado", "encerrar ditado",
    "sair do ditado", "terminar ditado", "finalizar ditado",
])

# Energia, monitores, desktops virtuais, tela e apresentacao.
_GATILHOS_REINICIAR = frozenset([
    "reiniciar o computador", "reiniciar computador", "reiniciar o pc", "reiniciar pc",
    "reiniciar o windows", "reiniciar windows",
])
_GATILHOS_SUSPENDER = frozenset([
    "suspender", "suspender o computador", "suspender computador", "suspender o pc",
    "suspender pc", "colocar o computador para dormir", "colocar o pc para dormir",
])
_GATILHOS_CANCELAR_SUSPENSAO = (
    "cancelar suspensao", "cancelar a suspensao", "cancela suspensao",
    "abortar suspensao", "cancelar suspender",
)
_RE_MOVER_MONITOR = re.compile(
    r"\b(?:mover|mandar|levar|passar|enviar|jogar)\b.*"
    r"\b(?:monitor|segunda\s+tela|outra\s+tela|outro\s+display)\b"
)
_RE_LADO = re.compile(r"\b(esquerda|direita)\b")
_RE_DESKTOP_NOVO = re.compile(
    r"\b(?:novo|nova|criar)\s+(?:um\s+|uma\s+)?(?:desktop|area\s+de\s+trabalho)"
    r"(?:\s+virtual)?\b"
)
_RE_DESKTOP_PROX = re.compile(
    r"\b(?:proximo|proxima)\s+(?:desktop|area\s+de\s+trabalho)\b"
    r"|\b(?:desktop|area\s+de\s+trabalho)\s+(?:da\s+)?direita\b"
)
_RE_DESKTOP_ANT = re.compile(
    r"\b(?:desktop|area\s+de\s+trabalho)\s+anterior\b"
    r"|\b(?:desktop|area\s+de\s+trabalho)\s+(?:da\s+)?esquerda\b"
)
_RE_DESKTOP_FECHAR = re.compile(
    r"\bfechar\s+(?:o\s+|este\s+|esse\s+)?(?:desktop|area\s+de\s+trabalho)\b"
)
_RE_VISAO_TAREFAS = re.compile(r"\bvisao\s+de\s+tarefas\b|\btask\s*view\b")
_RE_DESLIGAR_TELA = re.compile(
    r"\b(?:desligar|apagar)\s+(?:a\s+|o\s+)?(?:tela|monitor|display)\b"
)
# esvaziar/esvazie/esvazia e limpar/limpe/limpa a lixeira
_RE_LIXEIRA = re.compile(r"\b(?:esvazi\w*|limp\w*)\s+(?:a\s+|minha\s+)?lixeira\b")
_RE_SAIR_APRESENTACAO = re.compile(
    r"\b(?:sair|desativar|encerrar|fechar)\s+(?:do\s+|o\s+)?modo\s+apresentacao\b"
)
_RE_APRESENTACAO = re.compile(
    r"\bmodo\s+apresentacao\b|\bespelhar\s+(?:a\s+)?tela\b|\bduplicar\s+(?:a\s+)?tela\b"
)
_RE_ESTENDER = re.compile(r"\bestender\s+(?:a\s+)?tela\b")
_RE_SO_PC = re.compile(
    r"\b(?:somente|so|apenas)\s+(?:a\s+)?(?:tela\s+do\s+)?(?:pc|notebook|computador)\b"
)
_RE_SO_SEGUNDA = re.compile(
    r"\b(?:somente|so|apenas)\s+(?:a\s+)?(?:segunda\s+tela|projetor|tv|monitor\s+externo)\b"
)
_RE_PROJETAR = re.compile(r"\b(?:abrir\s+)?projecao\b|\bprojetar\s+tela\b")

# Inicializacao com o Windows.
_RE_INICIO_OFF = re.compile(
    r"\b(?:nao\s+iniciar|parar\s+de\s+iniciar|desativar|remover|tirar|cancelar)\b.{0,40}"
    r"\b(?:com\s+(?:o\s+)?windows|inicializacao)\b"
)
_RE_INICIO_ON = re.compile(
    r"\b(?:iniciar|abrir|ligar|ativar|comecar|executar)\b.{0,40}"
    r"\b(?:com\s+(?:o\s+)?windows|inicializacao\s+automatica)\b"
    r"|\binicializacao\s+automatica\b"
)

# Confirmacao por voz de acoes irreversiveis.
_CMDS_CONFIRMAR = frozenset([
    "confirmar", "confirma", "confirmo", "confirmado", "sim", "pode",
    "pode confirmar", "pode esvaziar", "pode enviar", "isso",
])
# Sem a palavra de ativacao so vale o comando explicito (evita um "sim"
# captado de uma TV ou conversa confirmar uma acao irreversivel).
_CMDS_CONFIRMAR_SEM_WAKE = frozenset([
    "confirmar", "confirma", "confirmo", "pode confirmar",
])
_CMDS_NEGAR = frozenset([
    "nao", "cancelar", "cancela", "deixa", "esquece", "deixa pra la",
    "nao confirmar", "nao confirma",
])


@dataclass
class _Confirmacao:
    """Pedido de confirmacao pendente. O prazo so conta depois da fala do pedido."""
    descricao: str
    acao: Callable[[], None]
    validade: float
    criado: float
    expira: float | None = None


def _limpar_resposta(cn: str) -> str:
    """Tira pontuacao e espacos extras: 'Confirmar.' -> 'confirmar'."""
    return " ".join(re.sub(r"[^\w\s]", " ", cn).split())


# Apelidos por voz: "chame Joao Silva de Joaozinho".
_VERBOS_APELIDO = frozenset(["chame", "chama", "chamar", "apelide", "apelida", "apelidar"])


def _candidatos_apelido(cmd: str) -> list[tuple[str, str]] | None:
    """
    Separa "chame NOME de APELIDO" em (nome_falado, apelido), preservando os
    acentos de `cmd`. O conector pode ser "de", "como" ou "pelo apelido".
    Como nomes tambem tem "de" ("Maria de Souza"), devolve todas as divisoes
    possiveis, da mais a direita para a mais a esquerda:

        "chame Maria de Souza de Mari"
        -> [("Maria de Souza", "Mari"), ("Maria", "Souza de Mari")]

    None se o comando nao comeca com um verbo de apelido; [] se faltar o conector.
    """
    palavras = cmd.split()
    if not palavras:
        return None
    normal = [_sem_acentos(p) for p in palavras]
    if normal[0] not in _VERBOS_APELIDO:
        return None

    inicio_nome = 2 if len(palavras) > 2 and normal[1] in ("o", "a") else 1
    candidatos: list[tuple[str, str]] = []
    for i in range(len(palavras) - 2, inicio_nome, -1):
        if normal[i] in ("de", "como"):
            inicio_apelido = i + 1
        elif normal[i] == "pelo" and normal[i + 1] == "apelido":
            inicio_apelido = i + 2
        else:
            continue
        if inicio_apelido >= len(palavras):
            continue
        candidatos.append((
            " ".join(palavras[inicio_nome:i]),
            " ".join(palavras[inicio_apelido:]),
        ))
    return candidatos


class Retorno(Enum):
    OK                = "ok"           # acao executada: bip curto de confirmacao
    SEM_SINAL         = "sem_sinal"    # ja houve feedback (fala/bip) ou nao deve haver bip
    DESCONHECIDO      = "desconhecido" # comando nao reconhecido: bip de erro


def _parse_duracao(cn: str) -> tuple[int, int] | None:
    """Retorna (segundos, indice_do_fim_do_trecho) ou None."""
    if "meia hora" in cn:
        return 1800, cn.index("meia hora") + len("meia hora")
    achado = _RE_DURACAO.search(cn)
    if not achado:
        return None
    valor = achado.group(1)
    quantidade = int(valor) if valor.isdigit() else _PALAVRAS_NUM[valor]
    unidade = achado.group(2)
    if unidade.startswith("seg"):
        mult = 1
    elif unidade.startswith("min"):
        mult = 60
    else:
        mult = 3600
    return quantidade * mult, achado.end()


def _formatar_duracao(segundos: int) -> str:
    horas, resto = divmod(segundos, 3600)
    minutos, segs = divmod(resto, 60)
    partes: list[str] = []
    if horas:
        partes.append(_plural(horas, "hora", "horas"))
    if minutos:
        partes.append(_plural(minutos, "minuto", "minutos"))
    if segs and not horas:
        partes.append(_plural(segs, "segundo", "segundos"))
    return " e ".join(partes) or "0 segundos"


# Calculadora por voz.
_NUMEROS_EXTENSO = {
    "zero": 0, "um": 1, "uma": 1, "dois": 2, "duas": 2, "tres": 3, "quatro": 4,
    "cinco": 5, "seis": 6, "sete": 7, "oito": 8, "nove": 9, "dez": 10,
    "onze": 11, "doze": 12, "treze": 13, "catorze": 14, "quatorze": 14,
    "quinze": 15, "dezesseis": 16, "dezessete": 17, "dezoito": 18,
    "dezenove": 19, "vinte": 20, "trinta": 30, "quarenta": 40,
    "cinquenta": 50, "sessenta": 60, "setenta": 70, "oitenta": 80,
    "noventa": 90, "cem": 100,  # "cento" fica de fora: conflita com "por cento"
}
_RE_NUM_EXTENSO = re.compile(
    r"\b(" + "|".join(sorted(_NUMEROS_EXTENSO, key=len, reverse=True)) + r")\b"
)
_RE_DEZENA_UNIDADE = re.compile(
    r"\b(vinte|trinta|quarenta|cinquenta|sessenta|setenta|oitenta|noventa)\s+e\s+"
    r"(um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove)\b"
)
_RE_PREFIXO_CALCULO = re.compile(
    r"^(?:(?:me\s+)?(?:diga|fale|fala)\s+)?"
    r"(?:quanto\s+(?:e|da|fica|vale|sera)|calcul\w+|conta|"
    r"qual\s+(?:e\s+)?(?:o\s+)?resultado\s+d[ea]|resultado\s+d[ea])\b\s*(?:de\s+)?"
)
_RE_SO_MATEMATICA = re.compile(r"^[\d\s.+\-*/()]+$")
_NUM = r"(\d+(?:\.\d+)?)"


def _normalizar_expressao(texto: str) -> str:
    """Converte uma conta falada em portugues para uma expressao aritmetica."""
    t = texto.strip().rstrip("?!.").strip()
    t = t.replace("×", " * ").replace("÷", " / ").replace("−", " - ")

    t = _RE_DEZENA_UNIDADE.sub(
        lambda m: str(_NUMEROS_EXTENSO[m.group(1)] + _NUMEROS_EXTENSO[m.group(2)]), t
    )
    t = _RE_NUM_EXTENSO.sub(lambda m: str(_NUMEROS_EXTENSO[m.group(1)]), t)

    # Formato brasileiro: 1.500,25 -> 1500.25
    t = re.sub(
        r"\b([1-9]\d{0,2})((?:\.\d{3})+)\b",
        lambda m: m.group(1) + m.group(2).replace(".", ""),
        t,
    )
    t = re.sub(r"(?<=\d),(?=\d)", ".", t)

    t = re.sub(_NUM + r"\s*(?:%|por\s*cento)\s*de\s*" + _NUM, r"(\1 * \2 / 100)", t)
    t = re.sub(r"raiz\s+quadrada\s+d[eo]\s+" + _NUM, r"(\1 ** 0.5)", t)
    t = re.sub(r"raiz\s+cubica\s+d[eo]\s+" + _NUM, r"(\1 ** (1 / 3))", t)
    t = re.sub(_NUM + r"\s+ao\s+quadrado\b", r"(\1 ** 2)", t)
    t = re.sub(_NUM + r"\s+ao\s+cubo\b", r"(\1 ** 3)", t)
    t = re.sub(r"\belevado\s+(?:a|na|ao)\s+(?:potencia\s+)?", " ** ", t)

    t = re.sub(r"\bmais\b", " + ", t)
    t = re.sub(r"\bmenos\b", " - ", t)
    t = re.sub(r"\b(?:vezes|multiplicado\s+por|multiplicar\s+por)\b", " * ", t)
    t = re.sub(r"(?<=[\d)])\s*\bx\b\s*(?=[\d(])", " * ", t)
    t = re.sub(r"\b(?:dividido\s+por|dividido\s+pelo|dividir\s+por)\b", " / ", t)

    t = re.sub(r"\b0+(\d)", r"\1", t)  # 007 -> 7 (literais com zero a esquerda nao compilam)
    return " ".join(t.split())


def _avaliar(no: ast.AST) -> int | float:
    """Avalia a arvore aritmetica sem usar eval (apenas + - * / ** e sinais)."""
    if isinstance(no, ast.Expression):
        return _avaliar(no.body)
    if isinstance(no, ast.Constant) and type(no.value) in (int, float):
        return no.value
    if isinstance(no, ast.UnaryOp) and isinstance(no.op, (ast.UAdd, ast.USub)):
        valor = _avaliar(no.operand)
        return +valor if isinstance(no.op, ast.UAdd) else -valor
    if isinstance(no, ast.BinOp):
        a = _avaliar(no.left)
        b = _avaliar(no.right)
        if isinstance(no.op, ast.Add):
            return a + b
        if isinstance(no.op, ast.Sub):
            return a - b
        if isinstance(no.op, ast.Mult):
            return a * b
        if isinstance(no.op, ast.Div):
            return a / b  # ZeroDivisionError sobe para quem chamou
        if isinstance(no.op, ast.Pow):
            if abs(b) > 1000 or abs(a) > 1e9:
                raise ValueError("potencia grande demais")
            resultado = a ** b
            if isinstance(resultado, complex):
                raise ValueError("resultado complexo")
            return resultado
    raise ValueError("expressao nao permitida")


def _formatar_resultado(valor: int | float) -> str:
    """Formata o numero para fala: so o numero, virgula decimal, 'menos' para negativos."""
    if isinstance(valor, float):
        if math.isnan(valor) or math.isinf(valor):
            raise ValueError("resultado invalido")
        if abs(valor - round(valor)) < 1e-9:
            valor = int(round(valor))
    if abs(valor) >= 10 ** 15:
        return "Resultado muito grande."
    if isinstance(valor, int):
        texto = str(abs(valor))
    else:
        texto = f"{abs(valor):.4f}".rstrip("0").rstrip(".").replace(".", ",")
    if texto in ("", "0"):
        return "0"
    return f"menos {texto}" if valor < 0 else texto


def _calcular(cn: str) -> str | None:
    """
    Retorna o resultado pronto para fala, ou None se o comando nao for uma conta.
    Aceita "quanto e 15 + 14", "calcule 15 mais 14", "20 por cento de 150",
    "raiz quadrada de 144" e contas soltas como "15 mais 14".
    Levanta ZeroDivisionError em divisoes por zero.
    """
    prefixo = _RE_PREFIXO_CALCULO.match(cn)
    corpo = cn[prefixo.end():] if prefixo else cn
    expr = _normalizar_expressao(corpo)

    if not _RE_SO_MATEMATICA.fullmatch(expr) or not re.search(r"\d", expr):
        return None
    # Sem prefixo, exige um operador: numero solto nao e conta.
    if not prefixo and not re.search(r"[+\-*/]", expr):
        return None

    try:
        valor = _avaliar(ast.parse(expr, mode="eval"))
        return _formatar_resultado(valor)
    except (SyntaxError, ValueError, OverflowError, RecursionError):
        return None


# Contatos e microfone.
_RE_BUSCAR_CONTATO = re.compile(
    r"\b(?:buscar|procurar|achar|listar|quais|ver)\s+(?:o\s+|os\s+|meus\s+)?contatos?"
    r"\s+(?:de\s+|do\s+|da\s+|chamados?\s+)?(.+)$"
)
_RE_RECALIBRAR = re.compile(
    r"\b(?:recalibr\w+|calibrar)\s+(?:o\s+)?(?:microfone|mic|audio)\b"
)


class ProcessadorComandos:
    """
    Interpreta comandos de texto e despacha para os servicos corretos.
    Nao possui estado proprio alem dos timers: os servicos sao injetados.

    Recebe o comando SEM a palavra de ativacao (removida em main()).

    Regras de latencia:
      - Acoes instantaneas (print, bloqueio, janelas, midia, volume) NUNCA
        esperam fala: executam primeiro; o feedback e um bip curto.
      - Fala so quando ha informacao a transmitir (confirmar() vira bip no
        modo silencioso).
    """

    _GATILHOS_ABRIR = frozenset(["abrir", "abre", "abra", "iniciar", "liga"])
    _GATILHOS_GOOGLE = frozenset(["pesquisar", "pesquisa", "buscar"])
    _GATILHOS_AMBIENTE = frozenset(["preparar ambiente", "modo trabalho", "vou trabalhar"])
    _GATILHOS_AUTO_RESP = frozenset([
        "verificar mensagens", "varrer whatsapp",
        "responda todo mundo", "forcar responder",
    ])
    _GATILHOS_LER_MENSAGENS = frozenset([
        "ler mensagens", "leia as mensagens", "leia mensagens",
        "mensagens nao lidas", "quais mensagens",
        "tenho mensagem", "tenho mensagens",
    ])
    _GATILHOS_DESLIGAR_PC = frozenset([
        "sono eterno", "desligar computador", "desligar o computador",
    ])
    _GATILHOS_CANCELAR_DESLIGAMENTO = frozenset([
        "cancelar desligamento", "cancelar o desligamento",
        "cancela desligamento", "cancela o desligamento",
        "abortar desligamento", "cancelar shutdown",
        "cancelar reinicio", "cancelar o reinicio", "cancela reinicio",
        "cancelar reinicializacao", "cancelar a reinicializacao", "abortar reinicio",
    ])
    _GATILHOS_DESLIGAR_JAIRO = frozenset([
        "desligar jairo", "desligar", "fechar sistema",
        "encerrar sistema", "desligar sistema",
    ])
    _GATILHOS_DIAG_WPP = frozenset([
        "diagnosticar whatsapp", "diagnostico do whatsapp", "diagnostico whatsapp",
    ])

    def __init__(
        self,
        wpp:      WhatsAppService,
        voz:      VozService,
        launcher: AppLauncher,
        midia:    ControleMidia,
        sistema:  ControleSistema,
        audio:    AudioPipeline,
        inicializacao: "InicializacaoWindows",
        evento_saida: threading.Event,
        simulado: bool = False,
    ) -> None:
        self._wpp          = wpp
        self._voz          = voz
        self._launcher     = launcher
        self._midia        = midia
        self._sistema      = sistema
        self._audio        = audio
        self._inicializacao = inicializacao
        self._evento_saida = evento_saida
        self._simulado     = simulado  # modo texto: comandos externos so sao registrados

        self.ditado_ativo = False
        self._pendente: _Confirmacao | None = None
        self._expirada: float | None = None  # quando o ultimo pedido expirou
        self._timer_suspensao: threading.Timer | None = None
        self._print_ref: tuple[float, int] | None = None

        self._lock_timers = threading.Lock()
        self._timers: dict[int, tuple[float, str, threading.Timer]] = {}
        self._seq_timer = 0

    def encerrar(self) -> None:
        """Cancela timers e a suspensao pendentes (chamado no encerramento)."""
        self._cancelar_timer_suspensao()
        with self._lock_timers:
            for _, _, timer in self._timers.values():
                timer.cancel()
            self._timers.clear()

    # ----------------------------------------------------------
    #  ROTEAMENTO
    # ----------------------------------------------------------

    def processar(self, comando: str) -> Retorno:
        cmd = comando.strip()           # preserva acentos (nomes, termos de busca)
        cn  = _sem_acentos(cmd)         # usado apenas para casar gatilhos

        # --- SO A PALAVRA DE ATIVACAO ---
        if not cn:
            self._voz.confirmar("Estou aqui!")
            return Retorno.SEM_SINAL

        # --- RESPOSTA A UMA CONFIRMACAO PENDENTE ("Jairo, confirmar") ---
        # Se for outro comando, o pedido pendente e descartado.
        if self.responder_confirmacao(cn, com_wake=True):
            return Retorno.SEM_SINAL

        # --- DESLIGAMENTO DO PC / DO JAIRO ---
        if any(g in cn for g in _GATILHOS_CANCELAR_SUSPENSAO):
            self._cancelar_suspensao()
            return Retorno.SEM_SINAL

        if any(g in cn for g in self._GATILHOS_CANCELAR_DESLIGAMENTO):
            self._cancelar_desligamento(cn)
            return Retorno.SEM_SINAL

        if cn in self._GATILHOS_DESLIGAR_PC:
            self._agendar_desligamento()
            return Retorno.SEM_SINAL

        if cn in self._GATILHOS_DESLIGAR_JAIRO:
            self._voz.falar("Desligando os sistemas. Ate mais!")
            self._evento_saida.set()
            raise SystemExit

        if cn in _GATILHOS_REINICIAR:
            self._agendar_reinicio()
            return Retorno.SEM_SINAL

        if cn in _GATILHOS_SUSPENDER:
            self._agendar_suspensao()
            return Retorno.SEM_SINAL

        # --- COMANDOS COM TEXTO LIVRE (antes dos gatilhos de sistema, para que o
        #     conteudo digitado ou enviado nao dispare outros comandos) ---
        achado_digitar = _RE_DIGITAR.match(cmd)
        if achado_digitar:
            return self._cmd_digitar(achado_digitar.group(1))

        candidatos_apelido = _candidatos_apelido(cmd)
        if candidatos_apelido is not None:
            self._cmd_apelido(candidatos_apelido)
            return Retorno.SEM_SINAL

        if "dizendo" in cn:
            if _RE_RESPONDER.match(cn):
                self._cmd_responder(cmd)
                return Retorno.SEM_SINAL
            if _RE_ENVIAR_MSG.search(cn):
                self._cmd_enviar_wpp(cmd)
                return Retorno.SEM_SINAL

        # "enviar print para X" antes de "print" (captura de tela)
        achado_print = _RE_ENVIAR_PRINT.match(cn)
        if achado_print:
            self._cmd_enviar_print(
                achado_print.group(2).strip(),
                bool(re.search(r"\b(?:inteira|cheia)\b", achado_print.group(1))),
            )
            return Retorno.SEM_SINAL

        # --- DITADO CONTINUO E EDICAO ---
        if cn in _CMDS_INICIAR_DITADO:
            self.iniciar_ditado()
            return Retorno.SEM_SINAL
        if cn in _CMDS_PARAR_DITADO:
            self.parar_ditado()
            return Retorno.SEM_SINAL
        if cn in _CMDS_ENTER:
            self._sistema.pressionar_enter()
            return Retorno.OK
        if cn in _CMDS_APAGAR_PALAVRA:
            self._sistema.apagar_palavra()
            return Retorno.OK
        if cn in _CMDS_APAGAR:
            self._sistema.apagar()
            return Retorno.OK

        # --- INICIALIZACAO COM O WINDOWS ---
        if _RE_INICIO_OFF.search(cn):
            self._cmd_inicio_windows(False)
            return Retorno.SEM_SINAL
        if _RE_INICIO_ON.search(cn):
            self._cmd_inicio_windows(True)
            return Retorno.SEM_SINAL

        # --- ACOES INSTANTANEAS (sem fala) ---
        if _RE_PRINT.search(cn):
            return self._cmd_print(cn)

        if _RE_BLOQUEAR.search(cn) or cn in {"bloquear", "travar"}:
            if not self._sistema.bloquear():
                self._voz.falar("Nao consegui bloquear o computador.")
            return Retorno.SEM_SINAL  # sem bip: a sessao esta bloqueando

        if self._tentar_tela(cn):
            return Retorno.SEM_SINAL

        if self._tentar_janelas(cn) or self._tentar_midia(cn):
            return Retorno.OK

        # --- CALCULADORA ---
        if self._tentar_calculo(cn):
            return Retorno.SEM_SINAL

        # --- TIMERS ---
        if self._tentar_timers(cn):
            return Retorno.SEM_SINAL

        # --- INFORMACOES E MODOS ---
        if self._tentar_info(cn):
            return Retorno.SEM_SINAL

        # --- WHATSAPP ---
        if _RE_CANCELAR_AGENDADAS.search(cn):
            self._cmd_cancelar_agendadas(_RE_CANCELAR_AGENDADAS.search(cn).group(1))
            return Retorno.SEM_SINAL

        if _RE_LISTAR_AGENDADAS.search(cn):
            self._cmd_listar_agendadas()
            return Retorno.SEM_SINAL

        achado_ler = _RE_LER_CHAT.match(cn)
        if achado_ler:
            valor = achado_ler.group(1) or achado_ler.group(2) or "1"
            quantidade = int(valor) if valor.isdigit() else _PALAVRAS_NUM.get(valor, 1)
            self._cmd_ler_chat(achado_ler.group(3).strip(), quantidade)
            return Retorno.SEM_SINAL

        achado_ler = _RE_LER_CHAT2.match(cn)
        if achado_ler:
            self._cmd_ler_chat(achado_ler.group(1).strip(), 1)
            return Retorno.SEM_SINAL

        achado = _RE_BUSCAR_CONTATO.search(cn)
        if achado:
            self._cmd_buscar_contato(achado.group(1).strip())
            return Retorno.SEM_SINAL

        if any(g in cn for g in self._GATILHOS_DIAG_WPP):
            self._cmd_diagnosticar_wpp()
            return Retorno.SEM_SINAL

        if any(g in cn for g in self._GATILHOS_LER_MENSAGENS):
            self._cmd_ler_mensagens()
            return Retorno.SEM_SINAL

        if any(g in cn for g in self._GATILHOS_AUTO_RESP):
            self._cmd_varrer_mensagens()
            return Retorno.SEM_SINAL

        if _RE_ENVIAR_MSG.search(cn):
            self._cmd_enviar_wpp(cmd)
            return Retorno.SEM_SINAL

        # --- ABRIR APLICATIVOS ---
        if any(g in cn for g in self._GATILHOS_ABRIR):
            for chave in self._launcher.chaves:
                if chave in cn:
                    self._voz.confirmar(f"Abrindo {chave}.")
                    if not self._launcher.abrir(chave):
                        self._voz.falar(
                            f"Nao encontrei o {chave}. Verifique o caminho."
                        )
                    return Retorno.SEM_SINAL

        # --- PREPARAR AMBIENTE ---
        if any(g in cn for g in self._GATILHOS_AMBIENTE):
            self._voz.confirmar("Preparando seu ambiente.")
            self._launcher.abrir("vs code")
            self._launcher.abrir("discord")
            return Retorno.SEM_SINAL

        # --- PESQUISA GOOGLE ---
        if any(g in cn for g in self._GATILHOS_GOOGLE):
            termo = self._extrair_termo(
                cmd, "jairo", "pesquisar", "pesquisa", "buscar", "no google"
            )
            if termo:
                self._voz.confirmar(f"Pesquisando {termo} no Google.")
                self._abrir_url(f"https://www.google.com/search?q={termo.replace(' ', '+')}")
            else:
                self._voz.falar("O que voce quer pesquisar?")
            return Retorno.SEM_SINAL

        # --- YOUTUBE ---
        if "youtube" in cn:
            termo = self._extrair_termo(
                cmd, "jairo", "youtube", "no youtube", "colocar", "tocar", "abrir"
            )
            if termo:
                self._voz.confirmar(f"Abrindo {termo} no YouTube.")
                self._abrir_url(
                    f"https://www.youtube.com/results?search_query={termo.replace(' ', '+')}"
                )
            else:
                self._voz.falar("O que voce quer no YouTube?")
            return Retorno.SEM_SINAL

        logger.debug("Comando nao mapeado: %r", cmd)
        return Retorno.DESCONHECIDO

    # ----------------------------------------------------------
    #  DESLIGAMENTO DO PC
    # ----------------------------------------------------------

    def _executar(self, argv: list[str], timeout: float = 10) -> subprocess.CompletedProcess:
        """Executa um programa externo (sem shell); no modo simulado so registra."""
        if self._simulado:
            logger.info("[simulado] %s", " ".join(argv))
            return subprocess.CompletedProcess(argv, 0, b"", b"")
        return subprocess.run(argv, capture_output=True, check=False, timeout=timeout)

    def _abrir_url(self, url: str) -> None:
        if self._simulado:
            logger.info("[simulado] abrir URL %s", url)
            return
        webbrowser.open(url)

    def _agendar_desligamento(self) -> None:
        self._voz.falar(
            "Desligando o computador em 1 minuto. "
            "Diga: Jairo, cancelar desligamento, para abortar."
        )
        try:
            self._executar(["shutdown", "/s", "/t", "60"])
        except (OSError, subprocess.SubprocessError) as exc:
            logger.error("Falha ao agendar desligamento: %s", exc)
            self._voz.falar("Nao consegui agendar o desligamento.")

    def _agendar_reinicio(self) -> None:
        self._voz.falar(
            "Reiniciando o computador em 1 minuto. "
            "Diga: Jairo, cancelar reinicialização, para abortar."
        )
        try:
            self._executar(["shutdown", "/r", "/t", "60"])
        except (OSError, subprocess.SubprocessError) as exc:
            logger.error("Falha ao agendar reinicializacao: %s", exc)
            self._voz.falar("Nao consegui agendar a reinicializacao.")

    def _cancelar_desligamento(self, cn: str = "") -> None:
        """shutdown /a cancela tanto o desligamento quanto a reinicializacao agendados."""
        reinicio = "reinic" in cn
        try:
            resultado = self._executar(["shutdown", "/a"])
        except (OSError, subprocess.SubprocessError) as exc:
            logger.error("Falha ao cancelar desligamento: %s", exc)
            self._voz.falar("Nao consegui cancelar a operacao.")
            return

        if resultado.returncode == 0:
            logger.info("Desligamento/reinicializacao cancelado.")
            self._voz.falar("Reinicialização cancelada." if reinicio else "Desligamento cancelado.")
        else:
            # 1116: nao havia operacao em andamento.
            logger.info("shutdown /a retornou %d.", resultado.returncode)
            self._voz.falar("Nao ha nenhum desligamento ou reinicializacao agendado.")

    def _agendar_suspensao(self) -> None:
        """Suspende apos um prazo cancelavel (shutdown /a nao cancela suspensao)."""
        atraso = CFG.atraso_suspensao
        self._cancelar_timer_suspensao()
        self._voz.falar(
            f"Suspendendo o computador em {atraso} segundos. "
            "Diga: Jairo, cancelar suspensão, para abortar."
        )
        timer = threading.Timer(atraso, self._executar_suspensao)
        timer.daemon = True
        timer.name = "Suspensao"
        timer.start()
        self._timer_suspensao = timer

    def _cancelar_timer_suspensao(self) -> bool:
        timer = self._timer_suspensao
        if timer is None:
            return False
        timer.cancel()
        self._timer_suspensao = None
        return True

    def _cancelar_suspensao(self) -> None:
        if self._cancelar_timer_suspensao():
            self._voz.falar("Suspensão cancelada.")
        else:
            self._voz.falar("Não há suspensão agendada.")

    def _executar_suspensao(self) -> None:
        self._timer_suspensao = None
        logger.info("Suspendendo o computador.")
        if not self._sistema.suspender():
            self._voz.falar("Não consegui suspender o computador.")

    # ----------------------------------------------------------
    #  CONFIRMACAO POR VOZ (acoes irreversiveis)
    # ----------------------------------------------------------

    def _pedir_confirmacao(
        self, descricao: str, acao: Callable[[], None], validade: float = 15.0
    ) -> None:
        """
        Guarda a acao e fala o pedido. O prazo (validade) so comeca a contar
        quando a fala do pedido termina; ver _pendente_valido().
        """
        self._pendente = _Confirmacao(descricao, acao, validade, monotonic())
        self._expirada = None
        self._voz.falar(f"{descricao} Diga: Jairo, confirmar. Ou diga cancelar.")

    def _pendente_valido(self) -> _Confirmacao | None:
        """Devolve o pedido pendente ainda dentro do prazo (ou None)."""
        p = self._pendente
        if p is None:
            return None
        if p.expira is None:
            if self._voz.ocupada():
                return p  # ainda falando o pedido: o prazo nao comecou
            p.expira = max(p.criado, self._voz.fim_fala) + p.validade
        if monotonic() > p.expira:
            logger.info("Confirmacao expirada: %s", p.descricao)
            self._pendente = None
            self._expirada = monotonic()
            return None
        return p

    def aguardando_confirmacao(self) -> bool:
        return self._pendente_valido() is not None

    def responder_confirmacao(self, texto: str, com_wake: bool = True) -> bool:
        """
        True se o texto respondeu a um pedido de confirmacao (aceitando, negando
        ou avisando que o pedido expirou).

        com_wake=True: o comando veio depois da palavra de ativacao; aceita
        confirmar/sim/pode/isso e qualquer outro comando descarta o pedido.
        com_wake=False: fala solta, sem "Jairo"; so aceita confirmacao explicita
        (confirmar, confirmo...) ou negacao, e nunca descarta o pedido.
        """
        cn = _limpar_resposta(_sem_acentos(texto))
        p = self._pendente_valido()

        if p is None:
            recente = self._expirada is not None and monotonic() - self._expirada < 30
            if recente and cn in _CMDS_CONFIRMAR_SEM_WAKE:
                self._expirada = None
                self._voz.falar("A confirmação expirou. Repita o comando.")
                return True
            return False

        if cn in (_CMDS_CONFIRMAR if com_wake else _CMDS_CONFIRMAR_SEM_WAKE):
            self._pendente = None
            try:
                p.acao()
            except Exception:
                logger.exception("Falha ao executar a acao confirmada: %s", p.descricao)
                self._voz.falar("Não consegui concluir a ação.")
            return True

        if cn in _CMDS_NEGAR:
            self._pendente = None
            self._voz.falar("Cancelado.")
            return True

        if com_wake:
            # Outro comando com a palavra de ativacao: descarta o pedido pendente.
            logger.info("Confirmacao descartada por novo comando: %s", p.descricao)
            self._pendente = None
        return False

    # ----------------------------------------------------------
    #  CAPTURA DE TELA E JANELAS
    # ----------------------------------------------------------

    def _cmd_print(self, cn: str) -> Retorno:
        """Executa a captura imediatamente; sem fala (so o bip final em main)."""
        if _RE_PRINT_CHEIA.search(cn):
            executou = self._sistema.captura_tela_cheia()   # Win+PrtSc: salva arquivo
        else:
            self._print_ref = (monotonic(), self._sistema.sequencia_area())
            executou = self._sistema.captura_tela()         # Win+Shift+S: recorte
        if not executou:
            self._voz.falar("Nao consegui acionar a captura de tela.")
            return Retorno.SEM_SINAL
        return Retorno.OK

    def _tentar_janelas(self, cn: str) -> bool:
        """Retorna True se o comando era de janelas, monitores ou desktops virtuais."""
        if _RE_MOVER_MONITOR.search(cn):
            lado = _RE_LADO.search(cn)
            return self._sistema.mover_para_monitor(
                "esquerda" if lado and lado.group(1) == "esquerda" else "direita"
            )
        if _RE_VISAO_TAREFAS.search(cn):
            return self._sistema.visao_tarefas()
        if _RE_DESKTOP_NOVO.search(cn):
            return self._sistema.desktop_novo()
        if _RE_DESKTOP_PROX.search(cn):
            return self._sistema.desktop_proximo()
        if _RE_DESKTOP_ANT.search(cn):
            return self._sistema.desktop_anterior()
        if _RE_DESKTOP_FECHAR.search(cn):
            return self._sistema.desktop_fechar()
        if _RE_DESLIGAR_TELA.search(cn):
            return self._sistema.desligar_tela()
        if _RE_AREA_TRABALHO.search(cn):
            return self._sistema.mostrar_area_trabalho()
        if _RE_TROCAR_JANELA.search(cn):
            return self._sistema.trocar_janela()
        if _RE_FECHAR_JANELA.search(cn):
            return self._sistema.fechar_janela()
        if _RE_MAXIMIZAR.search(cn):
            return self._sistema.maximizar_janela()
        if _RE_MINIMIZAR.search(cn):
            return self._sistema.minimizar_janela()
        lado = _RE_JANELA_LADO.search(cn)
        if lado:
            if lado.group(1) == "esquerda":
                return self._sistema.janela_esquerda()
            return self._sistema.janela_direita()
        return False

    # ----------------------------------------------------------
    #  TELA, APRESENTACAO E LIXEIRA
    # ----------------------------------------------------------

    def _tentar_tela(self, cn: str) -> bool:
        """Comandos de exibicao e lixeira (com fala/confirmacao). True se tratou."""
        if _RE_SAIR_APRESENTACAO.search(cn):
            self._sistema.manter_acordado(False)
            self._sistema.modo_exibicao("extend")
            self._voz.confirmar("Modo apresentação encerrado.")
            return True
        if _RE_APRESENTACAO.search(cn):
            self._sistema.modo_exibicao("clone")
            self._sistema.manter_acordado(True)
            self._voz.confirmar("Modo apresentação: telas duplicadas e o computador não vai dormir.")
            return True
        if _RE_ESTENDER.search(cn):
            self._sistema.modo_exibicao("extend")
            self._voz.confirmar("Telas estendidas.")
            return True
        if _RE_SO_PC.search(cn):
            self._sistema.modo_exibicao("internal")
            self._voz.confirmar("Somente a tela do computador.")
            return True
        if _RE_SO_SEGUNDA.search(cn):
            self._sistema.modo_exibicao("external")
            self._voz.confirmar("Somente a segunda tela.")
            return True
        if _RE_PROJETAR.search(cn):
            self._sistema.menu_projecao()
            self._voz.confirmar("Abrindo a projeção.")
            return True
        if _RE_LIXEIRA.search(cn):
            itens = self._sistema.itens_lixeira()
            if itens == 0:
                self._voz.falar("A lixeira já está vazia.")
                return True
            detalhe = _plural(itens, "item", "itens") if itens else "tudo o que está nela"
            self._pedir_confirmacao(
                f"Isso apaga definitivamente {detalhe} da lixeira.",
                self._esvaziar_lixeira,
            )
            return True
        return False

    def _esvaziar_lixeira(self) -> None:
        resultado = self._sistema.esvaziar_lixeira()
        if resultado == "ok":
            self._voz.falar("Lixeira esvaziada.")
        elif resultado == "vazia":
            self._voz.falar("A lixeira já estava vazia.")
        else:
            self._voz.falar("Não consegui esvaziar a lixeira.")

    # ----------------------------------------------------------
    #  DITADO
    # ----------------------------------------------------------

    def _cmd_digitar(self, texto: str) -> Retorno:
        formatado = _formatar_ditado(texto)
        if not formatado:
            self._voz.falar("O que devo digitar?")
            return Retorno.SEM_SINAL
        if not self._sistema.digitar(formatado):
            self._voz.falar("Não consegui digitar nesta janela.")
            return Retorno.SEM_SINAL
        return Retorno.OK

    def iniciar_ditado(self) -> None:
        self.ditado_ativo = True
        logger.info("Ditado continuo ativado.")
        self._voz.confirmar("Ditado ativado. Diga: parar ditado, para encerrar.")

    def parar_ditado(self) -> None:
        self.ditado_ativo = False
        logger.info("Ditado continuo encerrado.")
        self._voz.confirmar("Ditado encerrado.")

    def processar_ditado(self, texto: str) -> None:
        """
        No modo ditado toda frase e digitada, sem palavra de ativacao. So os
        comandos de controle (parar, enter, apagar) sao interpretados.
        """
        bruto = texto.strip()
        achado = _WAKE_RE.match(bruto)
        cn = _sem_acentos(achado.group(1) if achado else bruto)

        if cn in _CMDS_PARAR_DITADO:
            self.parar_ditado()
        elif cn in _CMDS_ENTER:
            self._sistema.pressionar_enter()
        elif cn in _CMDS_APAGAR_PALAVRA:
            self._sistema.apagar_palavra()
        elif cn in _CMDS_APAGAR:
            self._sistema.apagar()
        else:
            formatado = _formatar_ditado(bruto)
            if formatado:
                self._sistema.digitar(formatado + " ")

    # ----------------------------------------------------------
    #  INICIALIZACAO COM O WINDOWS
    # ----------------------------------------------------------

    def _cmd_inicio_windows(self, ativar: bool) -> None:
        sucesso = self._inicializacao.ativar() if ativar else self._inicializacao.desativar()
        if not sucesso:
            self._voz.falar("Não consegui alterar a inicialização com o Windows.")
        elif ativar:
            self._voz.falar("Pronto. O Jairo vai iniciar junto com o Windows.")
        else:
            self._voz.falar("Pronto. O Jairo não vai mais iniciar com o Windows.")

    # ----------------------------------------------------------
    #  MIDIA E VOLUME (sem fala: execucao imediata + bip)
    # ----------------------------------------------------------

    def _tentar_midia(self, cn: str) -> bool:
        """Retorna True se o comando era de midia/volume (e foi tratado)."""
        m = _RE_VOL_SUBIR.search(cn)
        if m:
            self._midia.ajustar_volume(int(m.group(1)) if m.group(1) else 10)
            return True

        m = _RE_VOL_DESCER.search(cn)
        if m:
            self._midia.ajustar_volume(-(int(m.group(1)) if m.group(1) else 10))
            return True

        if _RE_VOL_CONSULTA.search(cn):
            atual = self._midia.obter_volume()
            if atual is None:
                self._voz.falar(
                    "Nao consigo ler o volume sem a biblioteca pycaw instalada."
                )
            else:
                self._voz.falar(f"O volume esta em {atual} por cento.")
            return True

        m = _RE_VOL_ABS.search(cn)
        if m:
            self._midia.definir_volume(int(m.group(1)))
            return True

        if _RE_DESMUTAR.search(cn):
            self._midia.mutar(False)
            return True

        if _RE_MUTAR.search(cn):
            self._midia.mutar(True)
            return True

        if _RE_PROXIMA.search(cn) or cn in _CMDS_PROXIMA:
            self._midia.proxima()
            return True

        if _RE_ANTERIOR.search(cn) or cn in _CMDS_ANTERIOR:
            self._midia.anterior()
            return True

        if cn in _CMDS_PLAY_PAUSE:
            self._midia.play_pause()
            return True

        return False

    # ----------------------------------------------------------
    #  TIMERS
    # ----------------------------------------------------------

    def _tentar_timers(self, cn: str) -> bool:
        if _RE_CANCELAR_TIMERS.search(cn):
            quantidade = self._cancelar_timers()
            if quantidade:
                self._voz.falar(
                    f"{_plural(quantidade, 'timer cancelado', 'timers cancelados')}."
                )
            else:
                self._voz.falar("Nao ha timers ativos.")
            return True

        if _RE_QUANTO_FALTA.search(cn):
            self._listar_timers()
            return True

        if _RE_TIMER.search(cn):
            duracao = _parse_duracao(cn)
            if duracao is None:
                self._voz.falar("Diga o tempo. Por exemplo: timer de 5 minutos.")
                return True
            segundos, fim = duracao
            if not 1 <= segundos <= 86400:
                self._voz.falar("Tempo invalido. Use entre 1 segundo e 24 horas.")
                return True
            rotulo = re.sub(r"^(?:de|do|da|para|pra|que)\s+", "", cn[fim:].strip())
            self._criar_timer(segundos, rotulo)
            self._voz.confirmar(f"Timer de {_formatar_duracao(segundos)} iniciado.")
            return True

        return False

    def _criar_timer(self, segundos: int, rotulo: str) -> None:
        with self._lock_timers:
            self._seq_timer += 1
            tid = self._seq_timer
            timer = threading.Timer(segundos, self._disparar_timer, args=(tid,))
            timer.daemon = True
            timer.name = f"Timer-{tid}"
            self._timers[tid] = (monotonic() + segundos, rotulo, timer)
        timer.start()
        logger.info("Timer %d criado: %ds (%s).", tid, segundos, rotulo or "sem rotulo")

    def _disparar_timer(self, tid: int) -> None:
        with self._lock_timers:
            item = self._timers.pop(tid, None)
        if item is None:
            return
        _, rotulo, _ = item
        Sinal.alerta()
        self._voz.falar(f"Tempo esgotado. {rotulo}".strip())

    def _cancelar_timers(self) -> int:
        with self._lock_timers:
            quantidade = len(self._timers)
            for _, _, timer in self._timers.values():
                timer.cancel()
            self._timers.clear()
        return quantidade

    def _listar_timers(self) -> None:
        with self._lock_timers:
            itens = sorted(self._timers.values(), key=lambda i: i[0])
        if not itens:
            self._voz.falar("Nao ha timers ativos.")
            return
        partes = []
        for fim, rotulo, _ in itens:
            restante = max(1, round(fim - monotonic()))
            texto = f"Faltam {_formatar_duracao(restante)}"
            if rotulo:
                texto += f" para {rotulo}"
            partes.append(texto + ".")
        self._voz.falar(" ".join(partes))

    # ----------------------------------------------------------
    #  INFORMACOES E MODOS
    # ----------------------------------------------------------

    def _tentar_calculo(self, cn: str) -> bool:
        """Responde so o resultado ("29"). False se o comando nao for uma conta."""
        try:
            resultado = _calcular(cn)
        except ZeroDivisionError:
            self._voz.falar("Não é possível dividir por zero.")
            return True
        if resultado is None:
            return False
        logger.info("Calculo: %r -> %s", cn, resultado)
        self._voz.falar(resultado)
        return True

    def _tentar_info(self, cn: str) -> bool:
        if _RE_RECALIBRAR.search(cn):
            self._voz.confirmar("Calibrando o microfone. Fique em silencio.")
            self._audio.solicitar_recalibracao()
            return True

        if any(g in cn for g in ("que horas", "horas sao")):
            self._voz.falar(f"São {time.strftime('%H horas e %M minutos')}.")
            return True

        if _RE_DATA.search(cn):
            agora = datetime.now()
            self._voz.falar(
                f"Hoje é {_DIAS_SEMANA[agora.weekday()]}, {agora.day} de "
                f"{_MESES[agora.month - 1]} de {agora.year}."
            )
            return True

        if cn in _CMDS_REPETIR:
            self._voz.falar(self._voz.ultima_fala or "Ainda não falei nada.")
            return True

        if cn in _CMDS_AJUDA or "quais comandos" in cn or "o que voce faz" in cn:
            logger.info(_AJUDA_COMPLETA)
            self._voz.falar(_AJUDA_FALADA)
            return True

        if "modo silencioso" in cn or cn in {"so bip", "so bipe", "so bipes"}:
            self._voz.falar("Modo silencioso ativado. Vou responder com bipes.")
            self._voz.silencioso = True
            return True

        if "modo falante" in cn or cn in {"pode falar", "voltar a falar"}:
            self._voz.silencioso = False
            self._voz.falar("Modo falante ativado.")
            return True

        return False

    # ----------------------------------------------------------
    #  DIAGNOSTICO DO WHATSAPP
    # ----------------------------------------------------------

    def _cmd_diagnosticar_wpp(self) -> None:
        self._voz.confirmar("Gerando diagnostico do WhatsApp.")
        future = self._wpp.diagnosticar_whatsapp()
        future.add_done_callback(self._ao_diagnosticar)

    def _ao_diagnosticar(self, f: Future) -> None:
        erro = f.exception()
        if erro is not None:
            logger.error("Diagnostico falhou: %s", erro)
            self._voz.falar("Nao consegui gerar o diagnostico do WhatsApp.")
            return
        logger.info("Diagnostico salvo em %s", f.result())
        self._voz.falar("Diagnostico salvo na pasta do projeto.")

    # ----------------------------------------------------------
    #  WHATSAPP
    # ----------------------------------------------------------

    def _cmd_ler_mensagens(self) -> None:
        self._voz.confirmar("Verificando suas conversas.")
        future = self._wpp.listar_nao_lidos()
        future.add_done_callback(self._ao_listar_nao_lidos)

    def _ao_listar_nao_lidos(self, f: Future) -> None:
        # Executa na thread do worker: so enfileira fala, nunca fala direto.
        erro = f.exception()
        if erro is not None:
            logger.error("Leitura de nao lidas falhou: %s", erro)
            self._voz.falar("Nao consegui acessar o WhatsApp agora.")
            return

        chats: list[ChatNaoLido] = f.result()
        if not chats:
            self._voz.falar("Voce nao tem mensagens nao lidas.")
            return

        total = sum(c.quantidade for c in chats)
        partes = [
            f"Voce tem {_plural(total, 'mensagem nao lida', 'mensagens nao lidas')} "
            f"em {_plural(len(chats), 'conversa', 'conversas')}."
        ]

        limite = max(1, CFG.max_chats_leitura)
        for chat in chats[:limite]:
            nome = _limpar_para_fala(chat.nome, 40)
            previa = _limpar_para_fala(chat.previa)
            if previa:
                partes.append(f"{nome}: {previa}.")
            else:
                partes.append(
                    f"{nome}, {_plural(chat.quantidade, 'mensagem', 'mensagens')}."
                )

        restantes = len(chats) - limite
        if restantes > 0:
            partes.append(f"E mais {_plural(restantes, 'conversa', 'conversas')}.")

        self._voz.falar(" ".join(partes))

    def _cmd_varrer_mensagens(self) -> None:
        self._voz.confirmar("Verificando mensagens nao lidas agora.")
        logger.info("Varredura manual do auto-responder solicitada.")
        future = self._wpp.varrer_agora()
        future.add_done_callback(self._ao_concluir_varredura)

    def _ao_concluir_varredura(self, f: Future) -> None:
        erro = f.exception()
        if erro is not None:
            logger.error("Varredura manual falhou: %s", erro)
            self._voz.falar("Nao consegui varrer o WhatsApp agora.")
            return

        r: ResultadoVarredura = f.result()
        avisos = {
            "driver_inativo": "O WhatsApp nao esta conectado.",
            "sem_permitidos": "Sua lista de contatos permitidos esta vazia.",
            "erro_varredura": "Houve um erro ao ler a lista de conversas.",
        }
        if r.detalhe in avisos:
            self._voz.falar(avisos[r.detalhe])
        elif r.respondidos > 0:
            self._voz.falar(
                f"Varredura concluida. Respondi {_plural(r.respondidos, 'conversa', 'conversas')}."
            )
        elif r.nao_lidos > 0:
            self._voz.falar(
                "Ha conversas nao lidas, mas nenhuma pendente de contato permitido."
            )
        else:
            self._voz.falar("Nenhuma conversa nao lida.")

    def _cmd_apelido(self, candidatos: list[tuple[str, str]]) -> None:
        """
        "chame NOME de APELIDO": grava o apelido no contatos.txt (com backup .bak)
        e ja passa a valer. Sem pedir confirmacao: e reversivel (backup e painel).
        """
        if not candidatos:
            self._voz.falar("Diga: chame [nome] de [apelido].")
            return

        escolhido: tuple[str, str, list[Contato]] | None = None
        for nome_falado, apelido in candidatos:
            achados = self._wpp.buscar_contatos(nome_falado)
            if achados:
                escolhido = (nome_falado, apelido, achados)
                break
        if escolhido is None:
            self._voz.falar(f"Não encontrei {candidatos[0][0]} na agenda.")
            return

        nome_falado, apelido, achados = escolhido
        if len(achados) > 1:
            nomes = " ou ".join(c.nome for c in achados)
            self._voz.falar(f"Encontrei {nomes}. Diga o nome completo.")
            return

        contato = achados[0]
        apelido = " ".join(p[:1].upper() + p[1:] for p in apelido.split())
        try:
            gravado = self._wpp.adicionar_apelido(contato, apelido)
        except ValueError as exc:
            logger.info("Apelido recusado (%s): %s", contato.nome, exc)
            self._voz.falar(str(exc))
            return
        except OSError as exc:
            logger.error("Falha ao gravar o apelido: %s", exc)
            self._voz.falar(
                "Não consegui gravar no contatos.txt. Ele pode estar aberto em outro programa."
            )
            return
        self._voz.falar(f"Pronto. Agora {gravado} é apelido de {contato.nome}.")

    def _cmd_buscar_contato(self, nome: str) -> None:
        """Lista os contatos ativos que casam com o nome (util para achar entradas antigas)."""
        achados = self._wpp.buscar_contatos(nome)
        if not achados:
            self._voz.falar(f"Não encontrei contato com o nome {nome}.")
            return
        partes = [f"{c.nome}, final {' '.join(c.numero[-4:])}" for c in achados]
        self._voz.falar(
            f"Encontrei {_plural(len(achados), 'contato', 'contatos')}: "
            + "; ".join(partes) + "."
        )

    def _resolver_contato_falado(self, nome: str) -> Contato | None:
        """Resolve o nome na agenda. Em caso de erro ou ambiguidade, fala e devolve None."""
        try:
            return self._wpp.resolver_contato(nome)
        except ContatoAmbiguo as exc:
            nomes = " ou ".join(c.nome for c in exc.candidatos)
            logger.warning("Contato ambiguo para %r: %s", nome, nomes)
            self._voz.falar(
                f"Encontrei {_plural(len(exc.candidatos), 'contato', 'contatos')} "
                f"para {nome}: {nomes}. Diga o nome completo."
            )
        except LookupError:
            self._voz.falar(f"Não encontrei {nome} na agenda.")
        return None

    def _ao_envio_concluido(self, f: Future, rotulo: str = "", objeto: str = "Mensagem") -> None:
        erro = f.exception()
        if erro is not None:
            logger.error("Envio falhou: %s", erro)
            self._voz.falar(str(erro) if isinstance(erro, ConnectionError)
                            else "Não consegui concluir o envio.")
            return
        resultado: ResultadoEnvio = f.result()
        nome = resultado.destinatario or rotulo
        if resultado.estado == EstadoEnvio.CONFIRMADO_NA_CONVERSA:
            self._voz.confirmar(f"{objeto} confirmada para {nome}.")
        elif resultado.estado == EstadoEnvio.INSERIDO_NA_INTERFACE:
            self._voz.confirmar(f"{objeto} enviada para {nome}, aguardando confirmacao.")
        else:
            self._voz.falar(
                (f"Nao consegui enviar para {nome}. " if nome else "") + resultado.detalhe
            )
            logger.error("Envio falhou para %s: %s", nome, resultado.detalhe)

    def _cmd_enviar_wpp(self, cmd: str) -> None:
        """"enviar/agendar mensagem para NOME [horario] dizendo TEXTO"."""
        partes = cmd.split("dizendo", 1)
        if len(partes) < 2:
            self._voz.falar(
                "Diga: enviar mensagem para [nome] dizendo [texto]. "
                "Para agendar, inclua o horário."
            )
            return

        mensagem = partes[1].strip()
        resto = _RE_PREFIXO_ENVIO.sub("", _sem_acentos(partes[0]), count=1).strip()

        try:
            agendado = _parse_quando(resto, datetime.now())
        except HorarioInvalido as exc:
            self._voz.falar(str(exc))
            return
        quando = None
        if agendado is not None:
            quando, resto = agendado
        nome = resto

        if not nome or not mensagem:
            self._voz.falar("Nao consegui identificar o destinatario ou a mensagem.")
            return

        contato = self._resolver_contato_falado(nome)
        if contato is None:
            return

        if quando is not None:
            try:
                self._wpp.agendar_envio(contato, mensagem, quando)
            except (ConnectionError, RuntimeError) as exc:
                self._voz.falar(str(exc))
                return
            self._voz.falar(
                f"Agendado. Mensagem para {contato.nome} {_descrever_quando(quando)}."
            )
            return

        self._voz.confirmar(f"Enviando mensagem para {contato.nome}.")
        future = self._wpp.enviar_para(contato, mensagem)
        future.add_done_callback(lambda f: self._ao_envio_concluido(f, contato.nome))

    def _cmd_responder(self, cmd: str) -> None:
        """"responder [para NOME] dizendo TEXTO". Sem nome: unica conversa nao lida."""
        partes = cmd.split("dizendo", 1)
        mensagem = partes[1].strip() if len(partes) > 1 else ""
        nome = _RE_PREFIXO_RESPONDER.sub("", _sem_acentos(partes[0]), count=1).strip()
        if nome in _NOMES_ULTIMA:
            nome = ""
        if not mensagem:
            self._voz.falar("Diga: responder para [nome] dizendo [texto].")
            return

        if nome:
            try:
                contato = self._wpp.resolver_contato(nome)
            except ContatoAmbiguo as exc:
                nomes = " ou ".join(c.nome for c in exc.candidatos)
                self._voz.falar(f"Encontrei {nomes}. Diga o nome completo.")
                return
            except LookupError:
                contato = None
            if contato is not None:
                self._voz.confirmar(f"Respondendo para {contato.nome}.")
                future = self._wpp.enviar_para(contato, mensagem)
                future.add_done_callback(lambda f: self._ao_envio_concluido(f, contato.nome))
                return

        # Fora da agenda: usa a lista de conversas do WhatsApp (nome unico e visivel).
        self._voz.confirmar("Respondendo.")
        future = self._wpp.responder(nome or None, mensagem)
        future.add_done_callback(lambda f: self._ao_envio_concluido(f, nome))

    def _cmd_ler_chat(self, nome: str, quantidade: int) -> None:
        try:
            contato = self._wpp.resolver_contato(nome)
        except ContatoAmbiguo as exc:
            nomes = " ou ".join(c.nome for c in exc.candidatos)
            self._voz.falar(f"Encontrei {nomes}. Diga o nome completo.")
            return
        except LookupError:
            contato = None  # tenta pela lista de conversas do WhatsApp

        self._voz.confirmar(f"Lendo as mensagens de {contato.nome if contato else nome}.")
        future = self._wpp.ler_chat(contato, nome, quantidade)
        future.add_done_callback(self._ao_ler_chat)

    def _ao_ler_chat(self, f: Future) -> None:
        erro = f.exception()
        if erro is not None:
            if isinstance(erro, ConversaAmbigua):
                self._voz.falar("Encontrei " + " ou ".join(erro.nomes) + ". Diga o nome completo.")
            elif isinstance(erro, (LookupError, ConnectionError)):
                self._voz.falar(str(erro))
            else:
                logger.error("Leitura de conversa falhou: %s", erro)
                self._voz.falar("Não consegui ler a conversa agora.")
            return

        leitura: ResultadoLeitura = f.result()
        if not leitura.mensagens:
            self._voz.falar(f"Não encontrei mensagens recebidas de {leitura.chat}.")
            return

        if len(leitura.mensagens) == 1:
            m = leitura.mensagens[0]
            quando = f", às {m.horario}," if m.horario else ""
            self._voz.falar(f"{leitura.chat}{quando} disse: {_limpar_para_fala(m.texto, 300)}")
            return

        partes = [f"Últimas {len(leitura.mensagens)} mensagens de {leitura.chat}."]
        for indice, m in enumerate(leitura.mensagens, start=1):
            partes.append(f"{indice}: {_limpar_para_fala(m.texto, 200)}.")
        self._voz.falar(" ".join(partes))

    def _aguardar_area_mudar(self, antes: int, timeout: float = 2.0) -> bool:
        limite = monotonic() + timeout
        while monotonic() < limite:
            if self._sistema.sequencia_area() != antes:
                return True
            time.sleep(0.1)
        return False

    def _cmd_enviar_print(self, nome: str, tela_inteira: bool) -> None:
        nome = re.sub(r"^(?:a|o)\s+", "", nome)
        contato = self._resolver_contato_falado(nome)
        if contato is None:
            return

        if tela_inteira:
            antes = self._sistema.sequencia_area()
            if not self._sistema.copiar_tela_inteira() or not self._aguardar_area_mudar(antes):
                self._voz.falar("Não consegui capturar a tela inteira.")
                return
            self._enviar_imagem_para(contato)
            return

        if not self._sistema.area_tem_imagem():
            self._voz.falar(
                "Não há imagem na área de transferência. Diga: Jairo, tirar print, "
                "selecione a área e depois peça para enviar."
            )
            return

        # So envia direto se a imagem veio de um print tirado pelo Jairo ha pouco;
        # senao pode ser uma imagem antiga copiada por outro motivo.
        ref = self._print_ref
        recente = (
            ref is not None
            and monotonic() - ref[0] < 300
            and self._sistema.sequencia_area() != ref[1]
        )
        if recente:
            self._enviar_imagem_para(contato)
        else:
            self._pedir_confirmacao(
                f"A imagem da área de transferência não veio de um print recente. "
                f"Enviar para {contato.nome}?",
                lambda: self._enviar_imagem_para(contato),
            )

    def _enviar_imagem_para(self, contato: Contato) -> None:
        self._voz.confirmar(f"Enviando a imagem para {contato.nome}.")
        future = self._wpp.enviar_imagem(contato)
        future.add_done_callback(
            lambda f: self._ao_envio_concluido(f, contato.nome, "Imagem")
        )

    def _cmd_listar_agendadas(self) -> None:
        itens = self._wpp.listar_agendados()
        if not itens:
            self._voz.falar("Você não tem mensagens agendadas.")
            return
        partes = [
            f"para {e.contato}, {_descrever_quando(datetime.fromtimestamp(e.quando))}"
            for e in itens[:5]
        ]
        if len(itens) > 5:
            partes.append(f"e mais {len(itens) - 5}")
        self._voz.falar(
            f"Você tem {_plural(len(itens), 'mensagem agendada', 'mensagens agendadas')}: "
            + "; ".join(partes) + "."
        )

    def _cmd_cancelar_agendadas(self, nome: str | None) -> None:
        cancelados = self._wpp.cancelar_agendados((nome or "").strip() or None)
        if cancelados:
            self._voz.falar(
                f"{_plural(cancelados, 'mensagem agendada cancelada', 'mensagens agendadas canceladas')}."
            )
        else:
            self._voz.falar("Não há mensagens agendadas para cancelar.")

    @staticmethod
    def _extrair_termo(texto: str, *remover: str) -> str:
        for p in remover:
            texto = texto.replace(p, "")
        return texto.strip()


# ==============================================================
#  INICIALIZACAO COM O WINDOWS
# ==============================================================

class InicializacaoWindows:
    """
    Registra o Jairo para iniciar com o Windows (HKCU\\...\\Run, sem privilegios
    de administrador). Com a bandeja disponivel usa pythonw.exe (sem janela de
    console); sem ela usa python.exe, para que voce veja o programa.
    O parametro --autostart faz o Jairo esperar JAIRO_ATRASO_INICIO segundos
    (audio e rede costumam nao estar prontos logo apos o login).
    """

    _CHAVE = r"Software\Microsoft\Windows\CurrentVersion\Run"
    _VALOR = "Jairo"

    def __init__(self, simulado: bool = False) -> None:
        self._simulado = simulado
        self._ativo_sim = False

    @staticmethod
    def comando() -> str:
        script = Path(__file__).resolve()
        python = Path(sys.executable)
        if CFG.bandeja and pystray is not None:
            pythonw = python.with_name("pythonw.exe")
            if pythonw.exists():
                python = pythonw
        return f'"{python}" "{script}" --autostart'

    def ativo(self) -> bool:
        if self._simulado:
            return self._ativo_sim
        try:
            import winreg
        except ImportError:
            return False
        try:
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, self._CHAVE, 0, winreg.KEY_QUERY_VALUE
            ) as chave:
                valor, _ = winreg.QueryValueEx(chave, self._VALOR)
            return bool(valor)
        except OSError:
            return False

    def ativar(self) -> bool:
        if self._simulado:
            self._ativo_sim = True
            logger.info("[simulado] iniciar com o Windows: ativado.")
            return True
        try:
            import winreg
        except ImportError:
            logger.error("winreg indisponivel: so funciona no Windows.")
            return False
        try:
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, self._CHAVE, 0, winreg.KEY_SET_VALUE
            ) as chave:
                winreg.SetValueEx(chave, self._VALOR, 0, winreg.REG_SZ, self.comando())
            logger.info("Inicializacao com o Windows ativada: %s", self.comando())
            return True
        except OSError as exc:
            logger.error("Falha ao ativar a inicializacao: %s", exc)
            return False

    def desativar(self) -> bool:
        if self._simulado:
            self._ativo_sim = False
            logger.info("[simulado] iniciar com o Windows: desativado.")
            return True
        try:
            import winreg
        except ImportError:
            return False
        try:
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, self._CHAVE, 0, winreg.KEY_SET_VALUE
            ) as chave:
                winreg.DeleteValue(chave, self._VALOR)
            logger.info("Inicializacao com o Windows desativada.")
            return True
        except FileNotFoundError:
            return True  # ja nao estava registrado
        except OSError as exc:
            logger.error("Falha ao desativar a inicializacao: %s", exc)
            return False


# ==============================================================
#  ICONE NA BANDEJA DO SISTEMA
# ==============================================================

class Bandeja:
    """
    Icone na bandeja com o estado do Jairo (ouvindo, standby, silencioso,
    ditado). Requer pystray e Pillow (opcionais). Os cliques do menu viram
    acoes em self.acoes, consumidas pelo loop principal: o menu roda em uma
    thread propria da biblioteca e nao toca nos servicos do Jairo.
    """

    _CORES = {
        "ouvindo":    (46, 160, 67),
        "standby":    (128, 128, 128),
        "silencioso": (217, 164, 6),
        "ditado":     (30, 110, 220),
    }
    _TITULOS = {
        "ouvindo":    "Jairo - ouvindo",
        "standby":    "Jairo - standby",
        "silencioso": "Jairo - modo silencioso",
        "ditado":     "Jairo - ditado",
    }

    def __init__(self, com_painel: bool = False) -> None:
        self._com_painel = com_painel
        self.acoes: queue.Queue[str] = queue.Queue()
        self.silencioso = False
        self.inicio_ativo = False
        self._estado = "ouvindo"
        self._icone = None
        self._imagens: dict[str, object] = {}

    @property
    def disponivel(self) -> bool:
        return pystray is not None and Image is not None

    def _imagem(self, estado: str):
        if estado in self._imagens:
            return self._imagens[estado]
        imagem = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        desenho = ImageDraw.Draw(imagem)
        desenho.ellipse((4, 4, 60, 60), fill=self._CORES[estado] + (255,))
        fonte = None
        for nome in ("segoeui.ttf", "arial.ttf"):
            try:
                fonte = ImageFont.truetype(nome, 38)
                break
            except Exception:
                continue
        try:
            if fonte is not None:
                desenho.text((32, 33), "J", fill=(255, 255, 255, 255), font=fonte, anchor="mm")
            else:
                desenho.text((26, 24), "J", fill=(255, 255, 255, 255))
        except Exception:
            pass
        self._imagens[estado] = imagem
        return imagem

    def iniciar(self) -> bool:
        if not self.disponivel:
            logger.info("Icone de bandeja indisponivel (instale pystray e Pillow).")
            return False

        def acao(nome: str):
            return lambda icone, item: self.acoes.put(nome)

        abrir_painel = (
            [pystray.MenuItem("Abrir painel", acao("abrir_painel"), default=True)]
            if self._com_painel
            else []
        )
        menu = pystray.Menu(
            *abrir_painel,
            pystray.MenuItem(
                lambda item: (
                    "Ativar escuta" if self._estado == "standby" else "Pausar escuta (standby)"
                ),
                acao("alternar_standby"),
            ),
            pystray.MenuItem(
                "Modo silencioso", acao("alternar_silencioso"),
                checked=lambda item: self.silencioso,
            ),
            pystray.MenuItem(
                "Iniciar com o Windows", acao("alternar_inicio"),
                checked=lambda item: self.inicio_ativo,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Abrir pasta do projeto", acao("abrir_pasta")),
            pystray.MenuItem("Abrir log", acao("abrir_log")),
            pystray.MenuItem("Sair", acao("sair")),
        )
        try:
            self._icone = pystray.Icon(
                "jairo", self._imagem("ouvindo"), self._TITULOS["ouvindo"], menu
            )
            self._icone.run_detached()
        except Exception as exc:
            logger.warning("Nao foi possivel criar o icone na bandeja: %s", exc)
            self._icone = None
            return False
        logger.info("Icone na bandeja ativo.")
        return True

    def definir_estado(self, estado: str, silencioso: bool) -> None:
        self.silencioso = silencioso
        if estado == self._estado or self._icone is None:
            return
        self._estado = estado
        try:
            self._icone.icon = self._imagem(estado)
            self._icone.title = self._TITULOS[estado]
            self._icone.update_menu()
        except Exception:
            logger.debug("Falha ao atualizar o icone da bandeja.", exc_info=True)

    def encerrar(self) -> None:
        if self._icone is not None:
            try:
                self._icone.stop()
            except Exception:
                pass
            self._icone = None


# ==============================================================
#  ENTRADA POR TEXTO (modo --texto)
# ==============================================================

class EntradaTexto:
    """
    Substitui o AudioPipeline no modo texto: cada linha digitada vira um
    comando, como se tivesse sido falada. Tem a mesma interface minima
    (cmd_queue, configurar, calibrar, iniciar, encerrar).
    """

    def __init__(self, evento_saida: threading.Event) -> None:
        self._evento_saida = evento_saida
        self.cmd_queue: queue.Queue[str] = queue.Queue()
        self.fim = False  # stdin acabou (entrada redirecionada)

    def configurar(self) -> None:
        pass

    def calibrar(self) -> None:
        pass

    def solicitar_recalibracao(self) -> None:
        print("  [texto] sem microfone: nada a recalibrar.", flush=True)

    def iniciar(self) -> None:
        # Daemon: input() nao pode ser interrompido; nao deve impedir a saida.
        threading.Thread(target=self._ler, name="EntradaTexto", daemon=True).start()

    def encerrar(self) -> None:
        pass

    def _ler(self) -> None:
        while not self._evento_saida.is_set():
            try:
                linha = input("voce> ")
            except EOFError:
                self.fim = True
                return
            except Exception:
                return
            linha = linha.strip()
            if linha.lower() in ("sair", "exit", "quit"):
                self._evento_saida.set()
                return
            if linha:
                self.cmd_queue.put(linha.lower())


# ==============================================================
#  DIAGNOSTICO DE VOZ
# ==============================================================

def _testar_voz() -> None:
    """python jairo.py --testar-voz : testa os dois backends de TTS isoladamente."""
    estado = EstadoFala()
    voz = VozService(estado)
    voz.iniciar()
    voz.diagnostico()


def _testar_mic() -> None:
    """
    python jairo.py --testar-mic : mede o nivel do ambiente e da sua fala e
    sugere um valor de JAIRO_ENERGY. Usa RMS int16, a mesma escala do
    energy_threshold do speech_recognition.
    """
    def medir(mic, segundos: float) -> list[float]:
        niveis: list[float] = []
        fim = monotonic() + segundos
        while monotonic() < fim:
            bloco = array("h")
            bloco.frombytes(mic.stream.read(mic.CHUNK))
            if bloco:
                niveis.append(math.sqrt(sum(a * a for a in bloco) / len(bloco)))
        return niveis

    def percentil(valores: list[float], p: float) -> float:
        ordenados = sorted(valores)
        return ordenados[min(len(ordenados) - 1, int(len(ordenados) * p))]

    try:
        with sr.Microphone() as mic:
            if mic.SAMPLE_WIDTH != 2:
                print("Formato de audio inesperado; teste indisponivel.")
                return
            print("Fique em SILENCIO por 3 segundos...")
            silencio = medir(mic, 3.0)
            print("Agora diga, no volume e na distancia normais: "
                  "'Jairo, que horas sao' (4 segundos)...")
            fala = medir(mic, 4.0)
    except OSError as exc:
        print(f"Microfone nao encontrado: {exc}")
        return

    ruido = percentil(silencio, 0.95)
    voz_media = percentil(fala, 0.75)
    voz_pico = max(fala)
    sugestao = int(max(ruido * 1.3, math.sqrt(max(ruido, 1.0) * max(voz_media, 1.0))))

    print(f"\nRuido de fundo (p95): {ruido:.0f}")
    print(f"Sua fala (p75):       {voz_media:.0f}   pico: {voz_pico:.0f}")
    print(f"\nSugestao: JAIRO_ENERGY={sugestao}  (coloque no .env)")
    if voz_media < ruido * 2:
        print("Sinal fraco em relacao ao ruido. Aumente o ganho de entrada em "
              "Configuracoes > Sistema > Som > Entrada, desative 'Melhorias de audio' "
              "do microfone ou aproxime-o da boca.")
    elif voz_pico < 800:
        print("Sua fala chega baixa ao PC. O ganho automatico do Jairo ajuda; "
              "aumentar o volume de entrada no Windows ajuda mais.")


# ==============================================================
#  PAINEL GRAFICO
# ==============================================================

class PainelJairo:
    """
    Liga o Jairo ao painel grafico (pacote painel/ + pasta ui/): sobe o servidor
    HTTP local, publica eventos no Hub e recebe comandos e acoes da interface.

    Regras:
      - A thread principal so publica no Hub (custo ~zero com a janela fechada).
      - Comandos e acoes vindos da interface (threads HTTP) so entram em filas;
        quem os executa e o loop principal, como acontece com a bandeja.
      - O Jairo nunca depende do painel: se algo aqui falhar, ele segue sem janela.
    """

    def __init__(
        self,
        agenda: Agenda,
        estado_fala: EstadoFala,
        voz: VozService,
        audio,
        simulado: bool = False,
    ) -> None:
        self.hub = Hub()
        self.comandos: queue.Queue[str] = queue.Queue(maxsize=20)
        self.acoes: queue.Queue[str] = queue.Queue(maxsize=20)
        self._agenda = agenda
        self._estado_fala = estado_fala
        self._voz = voz
        self._audio = audio
        self._simulado = simulado
        self._servidor = None
        self._log_stream = None
        self._ultima_voz = -1e9
        self._ultimo_calculo_nivel = 0.0

    # ----------------------------------------------------------
    #  CICLO DE VIDA
    # ----------------------------------------------------------

    def iniciar(self) -> bool:
        pasta_ui = _PASTA_SCRIPT / "ui"
        if not (pasta_ui / "index.html").is_file():
            logger.warning("Pasta ui/ nao encontrada ao lado do jairo.py: painel desativado.")
            return False

        contexto = Contexto(
            nome="Jairo",
            versao="2.0",
            dir_ui=pasta_ui,
            caminho_log=CAMINHO_LOG,
            editor_contatos=EditorContatos(CFG.caminho_contatos, Agenda.analisar_texto),
            editor_permitidos=EditorPermitidos(
                CFG.caminho_permitidos,
                lambda: [c.nome for c in self._agenda.contatos_ativos()],
            ),
            lista_apps=ListaApps(),
            explicar_nome=self._explicar_nome,
            ao_salvar_contatos=self._agenda.recarregar,
            ao_salvar_permitidos=self._agenda.invalidar_permitidos,
            injetar_comando=self._injetar_comando,
            executar_acao=self._executar_acao,
            abrir_arquivo=self._abrir_arquivo,
        )
        try:
            self._servidor = ServidorPainel(contexto, self.hub, porta=0)
            self._servidor.iniciar()
            _descoberta.gravar(self._servidor.dados_descoberta())
        except Exception as exc:
            logger.error("Nao foi possivel iniciar o painel: %s", exc)
            self._servidor = None
            return False

        self._log_stream = LogStream(self.hub)
        self._log_stream.ligar_ao(logger)
        logger.info("Painel pronto. Abra a janela com: python jairo.py")
        return True

    def encerrar(self) -> None:
        try:
            self.hub.definir_estado(pronto=False, atividade="nenhuma")
        except Exception:
            pass
        try:
            _descoberta.remover(pid=os.getpid())
        except Exception:
            logger.debug("Falha ao remover o arquivo de descoberta.", exc_info=True)
        if self._servidor is not None:
            try:
                self._servidor.encerrar()
            except Exception:
                logger.debug("Falha ao encerrar o servidor do painel.", exc_info=True)
            self._servidor = None

    # ----------------------------------------------------------
    #  CHAMADAS DA INTERFACE (threads HTTP: so filas e leituras)
    # ----------------------------------------------------------

    def _injetar_comando(self, texto: str) -> None:
        try:
            self.comandos.put_nowait(texto)
        except queue.Full:
            logger.warning("Fila de comandos do painel cheia; comando descartado.")

    def _executar_acao(self, acao: str, dados: dict) -> dict:
        if acao in ("standby", "silencioso"):
            try:
                self.acoes.put_nowait(acao)
            except queue.Full:
                logger.warning("Fila de acoes do painel cheia; acao descartada.")
            return {}
        if acao == "recarregar":
            self._agenda.recarregar()  # ValueError vira erro 400 com a mensagem
            self._agenda.invalidar_permitidos()
            return {}
        if acao == "testar":
            self._voz.falar("Teste de voz. Estou funcionando.")
            return {}
        raise ValueError("Ação desconhecida.")

    def _abrir_arquivo(self, chave: str) -> bool:
        alvo = {
            "log": CAMINHO_LOG,
            "contatos": CFG.caminho_contatos,
            "permitidos": CFG.caminho_permitidos,
            "pasta": CFG.caminho_projeto,
        }.get(chave)
        if alvo is None:
            return False
        if self._simulado:
            logger.info("[simulado] abrir %s", alvo)
            return True
        try:
            os.startfile(str(alvo))  # somente Windows
            return True
        except (AttributeError, OSError) as exc:
            logger.warning("Nao foi possivel abrir %s: %s", alvo, exc)
            return False

    def _explicar_nome(self, nome: str, texto: "str | None") -> dict:
        """Quem responderia por `nome` falado (na agenda atual ou num texto ainda nao salvo)."""
        agenda = self._agenda
        if texto is not None:
            try:
                agenda = Agenda.de_texto(texto)
            except ValueError as exc:
                return {"nome": nome, "resultado": "invalido", "erro": str(exc), "candidatos": []}
        achados = agenda.buscar_todos(nome)
        via = "apelido" if agenda.dono_do_apelido(nome) is not None else "nome"
        return {
            "nome": nome,
            "resultado": "nenhum" if not achados else "unico" if len(achados) == 1 else "ambiguo",
            "candidatos": [
                {"nome": c.nome, "final": c.numero[-4:], "via": via} for c in achados
            ],
        }

    # ----------------------------------------------------------
    #  EVENTOS PUBLICADOS (loop principal, voz e captura)
    # ----------------------------------------------------------

    def ao_falar(self, texto: str, muda: bool) -> None:
        self.hub.publicar("fala", {
            "texto": texto,
            "duracao_estimada_ms": max(900, len(texto) * 62),
            "muda": muda,
        })
        if not muda:
            self.hub.definir_estado(atividade="falando")

    def ao_fim_fala(self) -> None:
        self.hub.publicar("fala_fim")
        self.hub.definir_estado(atividade="nenhuma")

    def nivel_audio(self, dados: bytes, largura: int) -> None:
        """Chamado pela thread de captura a cada bloco de audio (~64 ms)."""
        hub = self.hub
        if not hub.ativo:
            return
        agora = monotonic()
        if agora - self._ultimo_calculo_nivel < 0.05:
            return
        self._ultimo_calculo_nivel = agora

        limiar_atual = getattr(self._audio, "limiar_energia", None)
        limiar = max(float(limiar_atual()) if callable(limiar_atual) else float(CFG.energy_min), 1.0)
        rms = _rms_pcm(dados, largura)
        eco = self._estado_fala.falando.is_set() or (agora - self._estado_fala.fim) < 1.0
        voz = rms > limiar and not eco
        if voz:
            self._ultima_voz = agora
        hub.nivel(0.0 if eco else min(1.0, rms / (limiar * 4.0)), voz)

    def sincronizar(self, jairo_ativo: bool, ditado: bool, silencioso: bool) -> None:
        """Estado mostrado na janela. Chamado a cada volta do loop principal."""
        atividade = "voz" if monotonic() - self._ultima_voz < 0.7 else "nenhuma"
        modo = "standby" if not jairo_ativo else "ditado" if ditado else "ouvindo"
        self.hub.definir_estado(modo=modo, silencioso=silencioso, atividade=atividade)

    def iniciar_comando(self, texto: str, origem: str) -> None:
        self.hub.publicar("transcricao", {"texto": texto, "origem": origem})
        self.hub.definir_estado(atividade="processando")

    def concluir_comando(self, texto: str, retorno: Retorno, origem: str) -> None:
        resultado = "nao_reconhecido" if retorno is Retorno.DESCONHECIDO else "ok"
        self.hub.registrar_comando(texto, resultado, origem)

    def transcricao(self, texto: str, origem: str) -> None:
        self.hub.publicar("transcricao", {"texto": texto, "origem": origem})


# ==============================================================
#  MAIN
# ==============================================================

_COMANDOS_STANDBY = frozenset([
    "silenciar", "modo espera", "descansar", "dormir", "dormi",
])
_COMANDOS_ACORDAR = frozenset([
    "", "ativar", "acordar", "voltar", "volta",
])


def _garantir_instancia_unica() -> bool:
    """
    Impede duas instancias do motor (ex.: uma iniciada com o Windows e outra
    manual), que brigariam pelo microfone e pelo perfil do navegador.
    """
    return _mutex_unico("Local\\JairoAssistente")


def _estado_bandeja(jairo_ativo: bool, ditado: bool, silencioso: bool) -> str:
    if not jairo_ativo:
        return "standby"
    if ditado:
        return "ditado"
    if silencioso:
        return "silencioso"
    return "ouvindo"


def _tratar_cli_inicio(args: list[str]) -> bool:
    """--instalar-inicio, --remover-inicio e --status-inicio. True se tratou."""
    if "--instalar-inicio" in args:
        gerenciador = InicializacaoWindows()
        ok = gerenciador.ativar()
        print("Inicializacao com o Windows ativada." if ok else "Falha ao ativar.")
        print(f"Comando registrado: {gerenciador.comando()}")
        return True
    if "--remover-inicio" in args:
        ok = InicializacaoWindows().desativar()
        print("Inicializacao com o Windows removida." if ok else "Falha ao remover.")
        return True
    if "--status-inicio" in args:
        print("Inicializacao com o Windows: "
              + ("ATIVA" if InicializacaoWindows().ativo() else "inativa"))
        return True
    return False


def main() -> None:
    global _EXIGIR_WAKE
    args = sys.argv[1:]

    if "--testar-voz" in args:
        _testar_voz()
        return
    if "--testar-mic" in args:
        _testar_mic()
        return
    if _tratar_cli_inicio(args):
        return

    modo_texto = "--texto" in args
    simulado = modo_texto and "--real" not in args
    usar_painel = (
        PAINEL_DISPONIVEL
        and CFG.painel_habilitado
        and "--sem-painel" not in args
        and (not modo_texto or "--com-painel" in args)
    )

    if not modo_texto and not _garantir_instancia_unica():
        logger.error("Ja existe um Jairo em execucao. Encerrando esta instancia.")
        return

    if "--autostart" in args and CFG.atraso_inicio > 0:
        logger.info("Iniciado com o Windows: aguardando %d s.", CFG.atraso_inicio)
        time.sleep(CFG.atraso_inicio)

    logger.info("=" * 52)
    logger.info("         J A I R O  v 2 . 0")
    logger.info("=" * 52)
    if CFG.modo_debug:
        logger.warning("MODO_DEBUG ativo. Brave sera aberto visivelmente.")
    if not PAINEL_DISPONIVEL:
        logger.warning("Pasta painel/ nao encontrada ao lado do jairo.py: rodando sem interface.")

    if modo_texto:
        _EXIGIR_WAKE = False
        Sinal.console = True
        print("Modo texto: digite comandos (a palavra de ativacao e opcional); 'sair' encerra.")
        print(
            "Acoes do sistema sao SIMULADAS. Opcoes: --real executa de verdade, "
            "--com-whatsapp liga o WhatsApp, --com-painel liga o painel, "
            "--falar tambem fala em voz alta."
        )
    elif _EXIGIR_WAKE:
        logger.info("Palavra de ativacao obrigatoria: %s", ", ".join(CFG.wake_aliases))
    else:
        logger.warning("Palavra de ativacao DESATIVADA: todo audio vira comando.")

    evento_saida = threading.Event()
    estado_fala  = EstadoFala()

    # Inicializa servicos.
    voz      = VozService(estado_fala, console=modo_texto, falar_tambem="--falar" in args)
    voz.iniciar()

    try:
        agenda = Agenda(CFG.caminho_contatos)
    except ValueError as exc:
        logger.critical("Erro na agenda de contatos: %s. Encerrando.", exc)
        sys.exit(1)

    wpp_ativo = CFG.wpp_habilitado and (not modo_texto or "--com-whatsapp" in args)
    agendador = Agendador(CFG.caminho_db) if wpp_ativo else None
    perdidas: list[EnvioAgendado] = []
    if agendador is not None:
        perdidas = agendador.expirar_perdidas(
            time.time(), CFG.agenda_tolerancia_min * 60
        )

    wpp = WhatsAppService(agenda, evento_saida, agendador, wpp_ativo)
    wpp.notificar = lambda texto, essencial: (
        voz.falar(texto) if essencial else voz.confirmar(texto)
    )
    launcher      = AppLauncher(simulado=simulado)
    midia         = ControleMidia(simulado=simulado)
    sistema       = ControleSistema(simulado=simulado)
    inicializacao = InicializacaoWindows(simulado=simulado)
    audio = (
        EntradaTexto(evento_saida)
        if modo_texto
        else AudioPipeline(evento_saida, estado_fala)
    )
    proc = ProcessadorComandos(
        wpp, voz, launcher, midia, sistema, audio, inicializacao, evento_saida, simulado
    )

    # Painel grafico: sobe cedo, para a janela encontrar o motor em ~2 s.
    painel: PainelJairo | None = None
    if usar_painel:
        painel = PainelJairo(agenda, estado_fala, voz, audio, simulado)
        if painel.iniciar():
            voz.ao_falar = painel.ao_falar
            voz.ao_fim_fala = painel.ao_fim_fala
            if isinstance(audio, AudioPipeline):
                audio.ao_nivel = painel.nivel_audio
        else:
            painel = None

    audio.configurar()

    # O Brave/WhatsApp sobe em paralelo com a calibracao do microfone.
    wpp.iniciar()
    audio.calibrar()
    audio.iniciar()

    bandeja: Bandeja | None = None
    if CFG.bandeja and not modo_texto:
        bandeja = Bandeja(com_painel=painel is not None)
        if bandeja.iniciar():
            bandeja.inicio_ativo = inicializacao.ativo()
        else:
            bandeja = None

    voz.confirmar("Jairo pronto. Pode chamar.")
    if perdidas:
        voz.falar(
            f"{_plural(len(perdidas), 'mensagem agendada foi perdida', 'mensagens agendadas foram perdidas')} "
            "porque o Jairo estava desligado no horário."
        )
    logger.info("Diga 'Jairo, ajuda' para ouvir o que posso fazer.")

    if painel is not None:
        painel.hub.definir_estado(pronto=True)
        if "--autostart" in args and CFG.janela_no_inicio:
            _lancar_destacado(["--janela"])

    jairo_ativo   = True
    ultimo_status: str | None = None
    mostrar_status = not modo_texto and sys.stdout is not None

    def despachar(alvo: str, origem: str, texto_exibido: str) -> None:
        """Executa um comando (ja sem a palavra de ativacao), de voz ou do painel."""
        nonlocal jairo_ativo
        if painel is not None:
            painel.iniciar_comando(texto_exibido, origem)

        if _sem_acentos(alvo) in _COMANDOS_STANDBY:
            voz.confirmar("Entrando em modo de espera.")
            jairo_ativo = False
            logger.info("STANDBY ativo.")
            retorno = Retorno.SEM_SINAL
        else:
            retorno = proc.processar(alvo)
            if retorno is Retorno.OK:
                Sinal.ok()
            elif retorno is Retorno.DESCONHECIDO:
                logger.info("Comando nao reconhecido: %r", alvo)
                Sinal.erro()

        if painel is not None:
            painel.concluir_comando(texto_exibido, retorno, origem)

    try:
        while not evento_saida.is_set() and not (
            getattr(audio, "fim", False) and audio.cmd_queue.empty()
        ):
            # --- Consume fila de voz na main thread (Windows COM safe) ---
            voz.consumir_fila()

            # --- Acoes da bandeja e dos botoes do painel ---
            acao = None
            if bandeja is not None:
                try:
                    acao = bandeja.acoes.get_nowait()
                except queue.Empty:
                    acao = None
            if acao is None and painel is not None:
                try:
                    acao = {
                        "standby": "alternar_standby",
                        "silencioso": "alternar_silencioso",
                    }.get(painel.acoes.get_nowait())
                except queue.Empty:
                    acao = None

            if acao == "sair":
                evento_saida.set()
                continue
            if acao == "alternar_standby":
                jairo_ativo = not jairo_ativo
                ultimo_status = None
                voz.confirmar("Estou de volta!" if jairo_ativo else "Entrando em modo de espera.")
            elif acao == "alternar_silencioso":
                voz.silencioso = not voz.silencioso
            elif acao == "alternar_inicio":
                if inicializacao.ativo():
                    inicializacao.desativar()
                else:
                    inicializacao.ativar()
                if bandeja is not None:
                    bandeja.inicio_ativo = inicializacao.ativo()
            elif acao == "abrir_painel":
                _lancar_destacado(["--janela"])
            elif acao in ("abrir_pasta", "abrir_log"):
                alvo_arquivo = CFG.caminho_projeto if acao == "abrir_pasta" else CAMINHO_LOG
                try:
                    os.startfile(str(alvo_arquivo))  # somente Windows
                except (AttributeError, OSError) as exc:
                    logger.warning("Nao foi possivel abrir %s: %s", alvo_arquivo, exc)

            # --- Estado e comandos digitados na janela ---
            if painel is not None:
                painel.sincronizar(jairo_ativo, proc.ditado_ativo, voz.silencioso)
                try:
                    texto_ui = painel.comandos.get_nowait()
                except queue.Empty:
                    texto_ui = None
                if texto_ui is not None:
                    achado_ui = _WAKE_RE.match(texto_ui)
                    alvo_ui = achado_ui.group(1).strip() if achado_ui else texto_ui.strip()
                    logger.info("Comando recebido do painel: %r", alvo_ui)
                    despachar(alvo_ui, "texto", texto_ui)
                    continue

            if jairo_ativo:
                if mostrar_status and ultimo_status != "ouvindo":
                    print(
                        f"\r[{time.strftime('%H:%M:%S')}] >> Ouvindo...                    ",
                        end="",
                        flush=True,
                    )
                    ultimo_status = "ouvindo"
                try:
                    comando = audio.cmd_queue.get(timeout=0.2)
                    if mostrar_status:
                        print("\r" + " " * 60 + "\r", end="", flush=True)
                    ultimo_status = None

                    # Ditado continuo: tudo e digitado, sem palavra de ativacao.
                    if proc.ditado_ativo:
                        if painel is not None:
                            painel.transcricao(comando, "voz")
                        proc.processar_ditado(comando)
                        continue

                    # Resposta curta a um pedido de confirmacao pendente: dispensa a
                    # palavra de ativacao (so "confirmar" explicito ou negacao).
                    if _WAKE_RE.match(comando) is None and proc.responder_confirmacao(
                        comando, com_wake=False
                    ):
                        if painel is not None:
                            painel.transcricao(comando, "voz")
                            painel.concluir_comando(comando, Retorno.SEM_SINAL, "voz")
                        continue

                    alvo = _extrair_comando(comando)
                    if alvo is None:
                        logger.debug("Ignorado (sem palavra de ativacao): %r", comando)
                        continue

                    logger.info("Comando recebido: %r", alvo or comando)
                    despachar(alvo, "voz", alvo or comando)

                except queue.Empty:
                    pass

            else:
                if mostrar_status and ultimo_status != "standby":
                    print(
                        f"\r[{time.strftime('%H:%M:%S')}] >> Standby...                    ",
                        end="",
                        flush=True,
                    )
                    ultimo_status = "standby"
                try:
                    fala = audio.cmd_queue.get(timeout=0.5)
                    alvo = _extrair_comando(fala)
                    if alvo is not None and _sem_acentos(alvo) in _COMANDOS_ACORDAR:
                        jairo_ativo = True
                        ultimo_status = None
                        voz.confirmar("Estou de volta!")
                        logger.info("Modo ATIVO retomado.")
                except queue.Empty:
                    pass

            # Mantem o icone da bandeja em dia mesmo sem acao do menu.
            if bandeja is not None:
                bandeja.definir_estado(
                    _estado_bandeja(jairo_ativo, proc.ditado_ativo, voz.silencioso),
                    voz.silencioso,
                )

    except SystemExit:
        logger.info("SystemExit recebido. Encerrando com seguranca.")
    except KeyboardInterrupt:
        print()
        logger.info("Interrompido pelo usuario.")
        evento_saida.set()
    except Exception:
        logger.exception("Excecao nao tratada no loop principal.")
    finally:
        evento_saida.set()
        proc.encerrar()
        sistema.manter_acordado(False)
        voz.consumir_fila()  # fala a despedida pendente antes de encerrar
        logger.info("Aguardando encerramento dos servicos...")
        if painel is not None:
            painel.encerrar()
        wpp.encerrar()
        audio.encerrar()
        if bandeja is not None:
            bandeja.encerrar()
        logger.info("Jairo encerrado.")


if __name__ == "__main__":
    main()
