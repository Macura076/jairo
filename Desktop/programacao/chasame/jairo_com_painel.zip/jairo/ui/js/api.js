// O token chega no fragmento da URL, e o fragmento nunca vai ao servidor. Fica so na aba (sessionStorage).
let token = null;
try {
  const achado = location.hash.match(/t=([\w-]+)/);
  if (achado) {
    token = achado[1];
    sessionStorage.setItem("chasame-token", token);
    history.replaceState(null, "", location.pathname);
  } else {
    token = sessionStorage.getItem("chasame-token");
  }
} catch { /* sessionStorage indisponivel: o token fica so em memoria */ }

export async function api(metodo, caminho, corpo, cabecalhos = {}) {
  const resposta = await fetch(caminho, {
    method: metodo,
    headers: {
      "X-Chasame-Token": token || "",
      ...(corpo !== undefined ? { "Content-Type": "application/json" } : {}),
      ...cabecalhos,
    },
    body: corpo !== undefined ? JSON.stringify(corpo) : undefined,
  });
  const dados = await resposta.json().catch(() => ({}));
  if (!resposta.ok) throw Object.assign(new Error(dados.erro || `Erro ${resposta.status}`), { status: resposta.status, dados });
  return dados;
}

// EventSource nao envia cabecalhos; por isso o SSE e lido por fetch + stream.
export function conectar(aoEvento, aoConexao) {
  let parar = false;
  (async () => {
    let espera = 500;
    while (!parar) {
      try {
        const r = await fetch("/events", { headers: { "X-Chasame-Token": token || "" } });
        if (r.status === 401 || r.status === 403) { aoConexao("token"); return; }
        if (!r.ok) throw new Error(String(r.status));
        aoConexao(true);
        espera = 500;
        const leitor = r.body.getReader();
        const decoder = new TextDecoder();
        let pendente = "";
        for (;;) {
          const { done, value } = await leitor.read();
          if (done) break;
          pendente += decoder.decode(value, { stream: true });
          let fim;
          while ((fim = pendente.indexOf("\n\n")) >= 0) {
            const bloco = pendente.slice(0, fim);
            pendente = pendente.slice(fim + 2);
            let tipo = "message", dados = "";
            for (const linha of bloco.split("\n")) {
              if (linha.startsWith("event: ")) tipo = linha.slice(7);
              else if (linha.startsWith("data: ")) dados += linha.slice(6);
            }
            if (dados) { try { aoEvento(tipo, JSON.parse(dados)); } catch { /* evento malformado */ } }
          }
        }
      } catch { /* servidor caiu ou rede local falhou */ }
      if (parar) return;
      aoConexao(false);
      await new Promise((ok) => setTimeout(ok, espera));
      espera = Math.min(espera * 2, 5000);
    }
  })();
  return () => { parar = true; };
}
