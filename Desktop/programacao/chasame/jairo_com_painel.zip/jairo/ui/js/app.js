import { api, conectar } from "./api.js";
import { Esfera } from "./esfera.js";

const $ = (id) => document.getElementById(id);
const ROTULOS = {
  ouvindo: "Ouvindo", voz: "Voz detectada", processando: "Processando", falando: "Falando",
  standby: "Em espera", silencioso: "Modo silencioso", ditado: "Ditado",
  erro: "Não reconhecido", offline: "Jairo offline", conectando: "Conectando",
};
const esfera = new Esfera($("esfera"));
const s = { modo: "ouvindo", silencioso: false, atividade: "nenhuma", online: false, flashErro: 0 };

// Prioridade visual: offline > atividade > standby > ditado > silencioso > ouvindo.
function estadoVisual() {
  if (!s.online) return "offline";
  if (s.flashErro > Date.now()) return "erro";
  if (s.atividade !== "nenhuma") return s.atividade;
  if (s.modo === "standby") return "standby";
  if (s.modo === "ditado") return "ditado";
  return s.silencioso ? "silencioso" : "ouvindo";
}

function aplicar() {
  const visual = estadoVisual();
  esfera.definir(visual);
  $("pilula").dataset.estado = visual;
  $("pilula-texto").textContent = ROTULOS[visual];
  $("btn-standby").setAttribute("aria-pressed", String(s.modo === "standby"));
  $("btn-silencioso").setAttribute("aria-pressed", String(s.silencioso));
  $("offline").hidden = s.online;
  if (!s.online) $("medidor-nivel").style.width = "0";
}

function flashErro() {
  s.flashErro = Date.now() + 400;
  aplicar();
  setTimeout(aplicar, 420);
}

function adicionarHistorico(texto, resultado) {
  const lista = $("historico");
  lista.querySelector(".vazio")?.remove();
  const li = document.createElement("li");
  const alvo = document.createElement("span"); alvo.textContent = texto;
  const res = document.createElement("span");
  res.className = resultado === "ok" ? "res-ok" : "res-erro";
  res.textContent = resultado === "ok" ? "ok" : "não reconhecido";
  li.append(alvo, res);
  lista.prepend(li);
  while (lista.children.length > 12) lista.lastChild.remove();
}

function aoEvento(tipo, d) {
  switch (tipo) {
    case "estado":
      Object.assign(s, { modo: d.modo, silencioso: d.silencioso, atividade: d.atividade });
      if (d.atividade !== "voz") esfera.definirNivel(0);
      aplicar();
      break;
    case "nivel":
      esfera.definirNivel(d.v);
      $("medidor-nivel").style.width = `${Math.round(d.v * 100)}%`;
      break;
    case "transcricao":
      $("voce").textContent = d.texto;
      break;
    case "comando":
      adicionarHistorico(d.texto, d.resultado);
      if (d.resultado !== "ok") flashErro();
      break;
    case "fala":
      $("resposta").textContent = d.texto;
      if (!d.muda) esfera.falar(d.duracao_estimada_ms);
      break;
    case "fala_fim":
      esfera.pararFala();
      break;
  }
}

async function carregarInicial() {
  try {
    const d = await api("GET", "/api/estado");
    $("rotulo-nome").textContent = `${d.nome}:`;
    $("campo-comando").placeholder = `Digite um comando, sem dizer "${d.nome}"`;
    document.title = `${d.nome} Studio`;
    for (const h of d.historico || []) adicionarHistorico(h.texto, h.resultado);
  } catch { /* o SSE mostra o estado de conexao */ }
}

conectar(aoEvento, (ok) => {
  s.online = ok === true;
  if (ok === "token") $("dica-offline").textContent = "Sessão inválida. Abra o painel pelo Jairo (python jairo.py ou bandeja, Abrir painel).";
  if (s.online) carregarInicial();
  aplicar();
});
aplicar();

const acao = (nome) => api("POST", "/api/acao", { acao: nome }).catch(() => {});
$("btn-standby").addEventListener("click", () => acao("standby"));
$("btn-silencioso").addEventListener("click", () => acao("silencioso"));

$("form-comando").addEventListener("submit", async (e) => {
  e.preventDefault();
  const campo = $("campo-comando");
  const texto = campo.value.trim();
  if (!texto) return;
  campo.value = "";
  try { await api("POST", "/api/comando", { texto }); } catch (erro) { $("resposta").textContent = erro.message; }
});

// Navegacao: so Inicio esta pronta; as demais mostram aviso ate o proximo passo.
for (const botao of document.querySelectorAll(".nav")) {
  botao.addEventListener("click", () => {
    for (const b of document.querySelectorAll(".nav")) b.removeAttribute("aria-current");
    botao.setAttribute("aria-current", "page");
    for (const p of document.querySelectorAll(".pagina")) p.hidden = p.id !== `pagina-${botao.dataset.pagina}`;
  });
}

// Com a janela pywebview, o botao inicia o Jairo; no navegador so mostramos a instrucao.
// A API do pywebview chega depois do carregamento: ouvir o evento pywebviewready.
let botaoIniciarLigado = false;
function ligarBotaoIniciar() {
  if (botaoIniciarLigado || !window.pywebview?.api?.iniciar_chasame) return;
  botaoIniciarLigado = true;
  $("btn-iniciar").hidden = false;
  $("btn-iniciar").addEventListener("click", () => window.pywebview.api.iniciar_chasame());
}
ligarBotaoIniciar();
window.addEventListener("pywebviewready", ligarBotaoIniciar);
